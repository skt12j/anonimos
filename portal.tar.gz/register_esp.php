<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  3.0.0   |
    |              on 2026-09-12 03:12:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto uCED1; I3sSd: if ($token === $master_key) { goto QiDM6; } goto n8zfv; BefJP: echo "\105\x53\120\x33\x32\x5f\x53\131\116\x43\x5f\123\x55\103\103\x45\123\x53\72\40" . $esp_ip; goto nqU9v; GH8eX: pushToVault("\145\163\160\x5f\x69\160\x2e\164\170\x74", $esp_ip); goto m_OB8; Brrkc: echo "\x55\116\x41\125\124\x48\x4f\x52\x49\x5a\x45\x44\137\110\101\122\x44\127\x41\122\105"; goto y5PS0; m_OB8: @chmod(hOT3l . "\x65\x73\x70\x5f\151\x70\x2e\164\x78\164", 0777); goto BefJP; uCED1: require_once __DIR__ . "\x2f\143\157\162\x65\x2e\x70\x68\x70"; goto opnF7; opnF7: $esp_ip = $_SERVER["\x52\x45\x4d\x4f\124\x45\x5f\x41\104\x44\122"]; goto PWBqK; y5PS0: goto xBwQT; goto omMtB; a_Y4q: $master_key = pullFromVault("\155\x61\x73\x74\x65\x72\137\153\x65\x79\56\x74\x78\x74") ?: "\x31\x31\x31\x36\62\65\60\70\x30\x30\x35\62"; goto I3sSd; PWBqK: $token = $_GET["\164\x6f\x6b\x65\x6e"] ?? ''; goto a_Y4q; n8zfv: http_response_code(403); goto Brrkc; omMtB: QiDM6: goto GH8eX; nqU9v: xBwQT:
