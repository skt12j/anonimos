<?php
// admin/rates.php - OPENWRT RAM-DISK EDITION (Time Rates Only)
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php"); exit;
}

$rates_raw = json_decode(pullFromVault('rates.json'), true) ?: [];
$rates = [
    'Time' => [
        'Regular' => $rates_raw['Time']['Regular'] ?? ($rates_raw['Regular'] ?? []), 
        'Gaming'  => $rates_raw['Time']['Gaming'] ?? ($rates_raw['Gaming'] ?? [])
    ]
];

if (isset($_GET['print'])) {
    header("Location: A4_print.php");
    exit;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $tier = $_POST['tier'] ?? 'Regular';
    $pesos = (int)($_POST['pesos'] ?? 0);
    
    if ($action === 'add' && $pesos > 0) {
        $d = (int)($_POST['days'] ?? 0);
        $h = (int)($_POST['hours'] ?? 0);
        $m = (int)($_POST['mins'] ?? 0);
        $s = (int)($_POST['secs'] ?? 0);
        $value = ($d * 1440) + ($h * 60) + $m + ($s / 60); 
        
        if ($value > 0) {
            $rates['Time'][$tier][(string)$pesos] = round($value, 2);
            krsort($rates['Time'][$tier], SORT_NUMERIC);
            
            // 83.33% VIP Auto-Calculator
            if ($tier === 'Regular' && isset($_POST['auto_gaming'])) {
                $gaming_value = $value * 0.833333333333; 
                $rates['Time']['Gaming'][(string)$pesos] = round($gaming_value, 2);
                krsort($rates['Time']['Gaming'], SORT_NUMERIC);
            }

            pushToVault('rates.json', json_encode($rates));
            $message = "<div style='color: var(--success); margin-bottom: 20px; font-weight: bold;'>RATE ADDED SUCCESSFULLY.</div>";
        } else {
            $message = "<div style='color: var(--danger); margin-bottom: 20px; font-weight: bold;'>ERROR: Value must be greater than 0.</div>";
        }
    } 
    elseif ($action === 'delete') {
        if (isset($rates['Time'][$tier][$pesos])) {
            unset($rates['Time'][$tier][$pesos]);
            pushToVault('rates.json', json_encode($rates));
            $message = "<div style='color: var(--danger); margin-bottom: 20px; font-weight: bold;'>RATE DELETED.</div>";
        }
    }

    if (isset($_POST['ajax'])) {
        header('Content-Type: application/json');
        echo json_encode(['status' => 'success', 'message' => $message]);
        exit;
    }
}

require_once 'header.php';
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
    <div>
        <h1 style="color: var(--success); text-shadow: 0 0 10px var(--success); margin: 0;">RATES CONFIGURATION <span id="sync-pulse" style="font-size:0.5em; color:var(--success);">●</span></h1>
        <p style="color: #888; margin: 5px 0 0 0;">Define Time limits per coin inserted.</p>
    </div>
    <a href="A4_print.php" target="_blank" class="btn btn-warning" style="margin: 0; padding: 10px 20px; font-size: 0.9rem; text-decoration: none;">🖨️ PRINT A4 POSTER</a>
</div>

<div id="message-container"><?php echo $message; ?></div>

<div class="card" style="margin-bottom: 30px; border-color: var(--success);">
    <h3 style="color: var(--success);">ADD NEW TARIFF</h3>
    <form id="addRateForm" onsubmit="submitFormAjax(event)" style="display: flex; gap: 15px; flex-wrap: wrap; align-items: flex-end;">
        <input type="hidden" name="action" value="add">

        <div style="flex: 1; min-width: 120px;">
            <label style="color: var(--info); font-size: 0.9rem; margin-bottom: 5px; display: block;">TIER:</label>
            <select name="tier" id="tierSelect" onchange="updateTierUI()" style="width: 100%; padding: 10px; background: #000; border: 1px solid var(--info); color: #fff;">
                <option value="Regular">Regular</option>
                <option value="Gaming">VIP Gaming</option>
            </select>
        </div>
        
        <div style="flex: 1; min-width: 80px;">
            <label style="color: var(--info); font-size: 0.9rem; margin-bottom: 5px; display: block;">COIN (₱):</label>
            <input type="number" name="pesos" min="1" required placeholder="5" style="width: 100%; padding: 10px; background: #000; border: 1px solid var(--info); color: #fff;">
        </div>

        <div id="time-inputs" style="flex: 3; min-width: 250px; display: flex; gap: 5px;">
            <div style="flex: 1;">
                <label style="color: var(--info); font-size: 0.8rem; margin-bottom: 5px; display: block;">DAYS:</label>
                <input type="number" name="days" id="daysInput" min="0" placeholder="0" oninput="updateTimePreview()" style="width: 100%; padding: 10px; background: #000; border: 1px solid var(--info); color: #fff;">
            </div>
            <div style="flex: 1;">
                <label style="color: var(--info); font-size: 0.8rem; margin-bottom: 5px; display: block;">HRS:</label>
                <input type="number" name="hours" id="hoursInput" min="0" placeholder="0" oninput="updateTimePreview()" style="width: 100%; padding: 10px; background: #000; border: 1px solid var(--info); color: #fff;">
            </div>
            <div style="flex: 1;">
                <label style="color: var(--info); font-size: 0.8rem; margin-bottom: 5px; display: block;">MINS:</label>
                <input type="number" name="mins" id="minsInput" min="0" placeholder="0" oninput="updateTimePreview()" style="width: 100%; padding: 10px; background: #000; border: 1px solid var(--info); color: #fff;">
            </div>
            <div style="flex: 1;">
                <label style="color: var(--info); font-size: 0.8rem; margin-bottom: 5px; display: block;">SECS:</label>
                <input type="number" name="secs" id="secsInput" min="0" placeholder="0" oninput="updateTimePreview()" style="width: 100%; padding: 10px; background: #000; border: 1px solid var(--info); color: #fff;">
            </div>
        </div>

        <div id="auto-gaming-container" style="flex: 100%; margin-top: 5px; display: flex; align-items: center; gap: 10px;">
            <input type="checkbox" name="auto_gaming" id="autoGamingCheck" checked onchange="updateTimePreview()" style="width: 18px; height: 18px; accent-color: var(--vip); cursor: pointer;">
            <label for="autoGamingCheck" style="color: var(--vip); font-size: 0.9rem; font-family: 'Orbitron'; font-weight: bold; cursor: pointer;">⚡ AUTO-CALCULATE VIP GAMING TIER (83.33%)</label>
        </div>

        <div style="flex: 100%; margin-top: -5px; text-align: left;">
            <span id="previewText" style="color: var(--success); font-family: 'Source Code Pro', monospace; font-size: 1rem; font-weight: bold; letter-spacing: 2px;"></span>
        </div>

        <button type="submit" class="btn btn-success" id="injectBtn" style="padding: 10px 20px; height: 42px;">INJECT RATE</button>
    </form>
</div>

<script>
    function submitFormAjax(e) {
        e.preventDefault(); 
        let form = e.target;
        let btn = document.getElementById('injectBtn');
        btn.disabled = true;
        btn.innerText = "INJECTING...";

        let formData = new FormData(form);
        formData.append('ajax', '1');

        fetch('', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                document.getElementById('message-container').innerHTML = data.message;
                fetchLiveRates(); 

                form.querySelector('input[name="pesos"]').value = '';
                document.getElementById('daysInput').value = '';
                document.getElementById('hoursInput').value = '';
                document.getElementById('minsInput').value = '';
                document.getElementById('secsInput').value = '';
                
                updateTimePreview();

                btn.disabled = false;
                btn.innerText = "INJECT RATE";
            })
            .catch(err => {
                console.error(err);
                btn.disabled = false;
                btn.innerText = "INJECT RATE";
            });
    }

    function submitDeleteAjax(e, form) {
        e.preventDefault(); 
        let formData = new FormData(form);
        formData.append('ajax', '1');

        fetch('', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                document.getElementById('message-container').innerHTML = data.message;
                fetchLiveRates(); 
            });
    }

    function updateTierUI() {
        let tier = document.getElementById('tierSelect').value;
        let autoContainer = document.getElementById('auto-gaming-container');
        autoContainer.style.display = (tier === 'Regular') ? 'flex' : 'none';
        updateTimePreview();
    }

    function updateTimePreview() {
        let d = parseInt(document.getElementById('daysInput').value) || 0;
        let h = parseInt(document.getElementById('hoursInput').value) || 0;
        let m = parseInt(document.getElementById('minsInput').value) || 0;
        let s = parseInt(document.getElementById('secsInput').value) || 0;
        
        let pad = n => n.toString().padStart(2, '0');
        let previewHTML = `PREVIEW: ${pad(d)}d:${pad(h)}h:${pad(m)}m:${pad(s)}s`;

        let tier = document.getElementById('tierSelect').value;
        let autoCheck = document.getElementById('autoGamingCheck').checked;
        
        if (tier === 'Regular' && autoCheck) {
            let total_mins = (d * 1440) + (h * 60) + m + (s / 60);
            let gam_mins = total_mins * 0.833333333333; 
            
            let total_sec = Math.round(gam_mins * 60);
            let gd = Math.floor(total_sec / 86400);
            let gh = Math.floor((total_sec % 86400) / 3600);
            let gm = Math.floor((total_sec % 3600) / 60);
            let gs = total_sec % 60;
            
            previewHTML += ` &nbsp;|&nbsp; <span style='color: var(--vip);'>VIP: ${pad(gd)}d:${pad(gh)}h:${pad(gm)}m:${pad(gs)}s</span>`;
        }

        document.getElementById('previewText').innerHTML = previewHTML;
    }

    window.onload = updateTierUI;
</script>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-bottom: 30px;">
    <div class="card" style="border-color: var(--info);">
        <h3 style="color: var(--info); margin-bottom: 15px;">REGULAR TIER</h3>
        <table>
            <thead><tr><th>COIN</th><th>TIME LIMIT</th><th>ACTION</th></tr></thead>
            <tbody id="ajax-time-reg"><tr><td colspan='3'>SCANNING...</td></tr></tbody>
        </table>
    </div>
    <div class="card" style="border-color: var(--vip);">
        <h3 style="color: var(--vip); margin-bottom: 15px;">GAMING TIER</h3>
        <table>
            <thead><tr><th>COIN</th><th>TIME LIMIT</th><th>ACTION</th></tr></thead>
            <tbody id="ajax-time-gam"><tr><td colspan='3'>SCANNING...</td></tr></tbody>
        </table>
    </div>
</div>

<script>
    function generateTableHTML(ratesObj, tier) {
        let html = '';
        if (!ratesObj || Object.keys(ratesObj).length === 0) return "<tr><td colspan='3' style='text-align: center; color: #555;'>No rates configured.</td></tr>";
        
        for (let pesos in ratesObj) {
            let val = ratesObj[pesos];
            let total_seconds = Math.round(val * 60);
            let d = Math.floor(total_seconds / 86400);
            let h = Math.floor((total_seconds % 86400) / 3600);
            let m = Math.floor((total_seconds % 3600) / 60);
            let s = total_seconds % 60;
            
            let pad = n => n.toString().padStart(2, '0');
            let display = `<span style="font-family: 'Source Code Pro', monospace;">${pad(d)}d:${pad(h)}h:${pad(m)}m:${pad(s)}s</span>`;

            html += `<tr>
                <td style='color: var(--success); font-weight: bold; font-size: 1.1rem;'>₱${pesos}</td>
                <td style='color: #fff; font-weight: bold; letter-spacing: 1px;'>${display}</td>
                <td>
                    <form onsubmit='submitDeleteAjax(event, this)' style='margin: 0;'>
                        <input type='hidden' name='action' value='delete'>
                        <input type='hidden' name='tier' value='${tier}'>
                        <input type='hidden' name='pesos' value='${pesos}'>
                        <button type='submit' class='btn btn-danger' style='padding: 2px 8px; font-size: 0.8rem;'>X</button>
                    </form>
                </td>
            </tr>`;
        }
        return html;
    }

    function fetchLiveRates() {
        if (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'SELECT') return;

        fetch('api_core.php?action=rates')
            .then(response => response.json())
            .then(data => {
                let timeReg = data.Time?.Regular || data.Regular || {};
                let timeGam = data.Time?.Gaming || data.Gaming || {};

                document.getElementById('ajax-time-reg').innerHTML = generateTableHTML(timeReg, 'Regular');
                document.getElementById('ajax-time-gam').innerHTML = generateTableHTML(timeGam, 'Gaming');

                let pulse = document.getElementById('sync-pulse');
                pulse.style.opacity = '1';
                setTimeout(() => pulse.style.opacity = '0.2', 500);
            }).catch(err => console.error("SYNC ERROR:", err));
    }

    fetchLiveRates();
    setInterval(fetchLiveRates, 3000); 
</script>
</body></html>