<?php
// admin/chat.php - OPENWRT RAM-DISK EDITION (No WebSockets / Time Mode Only)
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php"); exit;
}

// =====================================================================
// 📡 AJAX API: GET USER INTEL & LOGS
// =====================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'get_user_intel') {
    $mac = $_POST['mac'];
    $sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
    $logs = json_decode(pullFromVault('logs.json'), true) ?: [];

    $user_session = $sessions[$mac] ?? null;
    $user_logs = array_values(array_filter($logs, function($l) use ($mac) { return ($l['mac'] ?? '') === $mac; }));
    $user_logs = array_reverse($user_logs);

    echo json_encode(['status' => 'success', 'session' => $user_session, 'logs' => $user_logs]);
    exit;
}

// =====================================================================
// ⚙️ AJAX API: MASTER CONTROL OVERRIDE (Time Mode Only)
// =====================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'master_control') {
    $mac = $_POST['mac'];
    $cmd = $_POST['cmd'];
    $sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
    
    if (!isset($sessions[$mac])) {
        echo json_encode(['status' => 'error', 'msg' => 'User session not found in Vault.']); exit;
    }

    $ip = $sessions[$mac]['ip'] ?? '0.0.0.0';
    $active_tier = $sessions[$mac]['tier'] ?? 'Regular';
    $msg = "Command executed successfully.";

    // 🔥 TIME CONTROL (D:H:M:S)
    if ($cmd === 'add_time' || $cmd === 'sub_time') {
        $days = (int)($_POST['d'] ?? 0);
        $hours = (int)($_POST['h'] ?? 0);
        $mins = (int)($_POST['m'] ?? 0);
        $secs_in = (int)($_POST['s'] ?? 0);
        $total_secs = ($days * 86400) + ($hours * 3600) + ($mins * 60) + $secs_in;
        
        $target = $_POST['target_tier'];
        $bank_key = "bank_$target";

        if ($active_tier === $target && $sessions[$mac]['status'] === 'active') {
            $sessions[$mac]['expires'] += ($cmd === 'add_time') ? $total_secs : -$total_secs;
        } else {
            $sessions[$mac][$bank_key] = max(0, ($sessions[$mac][$bank_key] ?? 0) + (($cmd === 'add_time') ? $total_secs : -$total_secs));
        }
        $msg = ($cmd === 'add_time') ? "Added time to $target." : "Removed time from $target.";
    } 
    // 🔥 FORCE TIER JUMP
    elseif ($cmd === 'force_tier') {
        $target = $_POST['val'];
        if ($sessions[$mac]['status'] === 'active') {
            $sessions[$mac]["bank_$active_tier"] = max(0, $sessions[$mac]['expires'] - time());
        }
        $sessions[$mac]['tier'] = $target;
        
        $new_time = $sessions[$mac]["bank_$target"] ?? 0;
        
        $sessions[$mac]['status'] = 'active';
        $sessions[$mac]['expires'] = time() + $new_time;
        $sessions[$mac]["bank_$target"] = 0;
        
        fw_drop($mac, $ip);
        fw_allow($mac, $ip, $target);
        $msg = "Forced user to $target tier.";
    }
    // 🔥 STATUS CONTROLS
    elseif ($cmd === 'freeze') {
        if ($sessions[$mac]['status'] === 'active') {
            $sessions[$mac]['time_left'] = max(0, $sessions[$mac]['expires'] - time());
            $sessions[$mac]['status'] = 'paused';
            $sessions[$mac]['last_paused_at'] = time();
            fw_drop($mac, $ip);
            $msg = "Session completely frozen.";
        }
    }
    elseif ($cmd === 'resume') {
        if ($sessions[$mac]['status'] === 'paused') {
            $sessions[$mac]['expires'] = time() + ($sessions[$mac]['time_left'] ?? 0);
            $sessions[$mac]['time_left'] = 0;
            $sessions[$mac]['status'] = 'active';
            unset($sessions[$mac]['last_paused_at']);
            fw_allow($mac, $ip, $active_tier);
            $msg = "Session restored to active.";
        }
    }
    // 🔥 APPROVE PENDING COINS
    elseif ($cmd === 'approve_coins') {
        $coins = (int)($sessions[$mac]['pending_coins'] ?? 0);
        if ($coins > 0) {
            $target_tier = $_POST['tier_target'] ?? 'Regular';
            $rates_data = json_decode(pullFromVault('rates.json'), true) ?: [];
            $tier_rates = $rates_data['Time'][$target_tier] ?? []; 
            
            $val_added = 0; $remaining_coins = $coins;
            $available_denoms = array_keys($tier_rates); rsort($available_denoms, SORT_NUMERIC); 
            foreach ($available_denoms as $denom) {
                $denom_int = (int)$denom; if ($denom_int <= 0) continue;
                $count = floor($remaining_coins / $denom_int);
                if ($count > 0) { $val_added += ($count * (float)$tier_rates[$denom]); $remaining_coins -= ($count * $denom_int); }
            }

            if ($val_added > 0) {
                $sessions[$mac]['active_mode'] = 'Time';
                $sessions[$mac]['tier'] = $target_tier;
                $sessions[$mac]['status'] = 'active';

                $old_time = (($sessions[$mac]['expires'] ?? 0) > time()) ? ($sessions[$mac]['expires'] - time()) : (int)($sessions[$mac]['time_left'] ?? 0);
                $sessions[$mac]['expires'] = time() + ($val_added * 60) + $old_time;
                $sessions[$mac]['time_left'] = 0;

                unset($sessions[$mac]['pending_coins']);
                fw_allow($mac, $ip, $target_tier);
                
                $sales_raw = pullFromVault('sales.txt');
                pushToVault('sales.txt', (string)((is_numeric($sales_raw) ? (float)$sales_raw : 0.00) + $coins));
                $msg = "Approved ₱$coins to $target_tier (Time Mode).";
            }
        }
    }

    pushToVault('sessions.json', json_encode($sessions));
    echo json_encode(['status' => 'success', 'msg' => $msg]);
    exit;
}

require_once 'header.php';
?>

<style>
    /* MODAL UI STYLES */
    .c-modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.85); backdrop-filter: blur(5px); justify-content: center; align-items: center; }
    .c-modal-content { background-color: #050a15; padding: 25px; border: 1px solid var(--theme-color); width: 90%; max-width: 800px; border-radius: 5px; box-shadow: 0 0 30px rgba(0,243,255,0.2); max-height: 85vh; overflow-y: auto; }
    .c-modal-content::-webkit-scrollbar { width: 4px; }
    .c-modal-content::-webkit-scrollbar-thumb { background: var(--theme-color); }
    
    .mc-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px; }
    .mc-box { background: rgba(0,0,0,0.5); border: 1px dashed #444; padding: 15px; border-radius: 4px; text-align: center; position: relative; }
    .mc-box h4 { margin: 0 0 10px 0; color: #aaa; font-family: 'Orbitron'; font-size: 0.9rem; }
    .mc-val { font-size: 1.5rem; color: #fff; font-family: 'Source Code Pro'; font-weight: bold; }
    .mc-controls { display: flex; gap: 5px; justify-content: center; margin-top: 10px; }
    .mc-input { background: #000; border: 1px solid #555; color: #fff; text-align: center; border-radius: 3px; font-family: 'Orbitron'; }
    .mc-btn { background: #222; border: 1px solid #555; color: #fff; cursor: pointer; padding: 5px 10px; font-family: 'Orbitron'; font-size: 0.8rem; border-radius: 3px; }
    .mc-btn:hover { background: var(--theme-color); color: #000; border-color: var(--theme-color); }
    
    .log-table { width: 100%; border-collapse: collapse; font-family: 'Source Code Pro'; font-size: 0.85rem; }
    .log-table th { text-align: left; padding: 10px; border-bottom: 1px solid var(--theme-color); color: var(--theme-color); position: sticky; top: 0; background: #050a15; }
    .log-table td { padding: 10px; border-bottom: 1px solid #222; color: #ccc; }
    
    .close-btn { background: none; border: none; color: #fff; font-size: 2rem; position: absolute; right: 20px; top: 15px; cursor: pointer; opacity: 0.5; }
    .close-btn:hover { opacity: 1; color: var(--danger); }
</style>

<div style="margin-bottom: 20px; display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="color: var(--info); text-shadow: 0 0 10px var(--info); margin: 0;">(^-^) LIVE SUPPORT HUB</h1>
        <p style="color: #888; margin: 5px 0 0 0;">WebSockets disabled on OpenWrt Lite. User control decks only.</p>
    </div>
</div>

<!-- 🔥 MODAL 2: MASTER OVERRIDE DECK 🔥 -->
<div id="m-control" class="c-modal" style="display:flex;">
    <div class="c-modal-content" style="position: relative; border-color: var(--warning); box-shadow: 0 0 30px rgba(245, 158, 11, 0.2);">
        <div style="display:flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #333; padding-bottom: 15px; margin-bottom: 20px;">
            <div>
                <h2 style="color: var(--warning); font-family: 'Orbitron'; margin: 0;">⚙️ MASTER OVERRIDE DECK</h2>
                <span style="color: #aaa; font-family: 'Source Code Pro'; font-size:0.9rem;" id="mc-mac-display">ENTER MAC TO SEARCH</span>
            </div>
            <div id="mc-status-badge" style="padding: 5px 15px; border-radius: 20px; font-weight: bold; font-family: Orbitron; background: #222; border: 1px solid #555;">UNKNOWN</div>
        </div>

        <div style="display:flex; gap:10px; margin-bottom: 20px;">
            <input type="text" id="search-mac" placeholder="ENTER MAC (AA:BB:CC...)" class="mc-input" style="flex-grow:1; padding:10px; font-size:1.1rem; text-align:left;">
            <button class="btn btn-info" onclick="searchUser()" style="padding:10px 20px; margin:0;">SEARCH</button>
        </div>

        <div id="mc-dynamic-area">
            <!-- Dynamic Injection -->
        </div>
    </div>
</div>

<script>
    let activeMac = null;
    let currentUserSession = null;

    function formatTimeJS(seconds) {
        if (seconds <= 0) return "00:00:00";
        let d = Math.floor(seconds / 86400);
        let h = Math.floor((seconds % 86400) / 3600).toString().padStart(2, '0');
        let m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
        let s = Math.floor(seconds % 60).toString().padStart(2, '0');
        if (d > 0) return `${d}D : ${h}H : ${m}M : ${s}S`;
        return `${h}:${m}:${s}`;
    }

    async function searchUser() {
        let mac = document.getElementById('search-mac').value.trim();
        if(!mac) return;
        activeMac = mac;
        document.getElementById('mc-mac-display').innerText = "TARGET: " + activeMac;
        await refreshControlDeck();
    }

    async function refreshControlDeck() {
        let fd = new FormData(); fd.append('action', 'get_user_intel'); fd.append('mac', activeMac);
        try {
            let res = await fetch('chat.php', { method: 'POST', body: fd });
            let intel = await res.json();
            
            if (!intel || !intel.session) {
                document.getElementById('mc-status-badge').innerHTML = 'NO VAULT DATA';
                document.getElementById('mc-status-badge').style.borderColor = 'var(--danger)';
                document.getElementById('mc-status-badge').style.color = 'var(--danger)';
                document.getElementById('mc-dynamic-area').innerHTML = '<div style="text-align:center; color:#888; padding: 20px;">This MAC has no active Vault data.</div>';
                return;
            }
            
            currentUserSession = intel.session;
            let s = intel.session;
            let tier = s.tier || 'Regular';
            
            let badge = document.getElementById('mc-status-badge');
            if (s.status === 'active') { badge.innerHTML = "ACTIVE"; badge.style.color = "var(--success)"; badge.style.borderColor = "var(--success)"; }
            else if (s.status === 'paused') { badge.innerHTML = "FROZEN"; badge.style.color = "var(--warning)"; badge.style.borderColor = "var(--warning)"; }
            else { badge.innerHTML = "EXPIRED"; badge.style.color = "var(--danger)"; badge.style.borderColor = "var(--danger)"; }

            let tReg = s.bank_Regular || 0;
            let tGam = s.bank_Gaming || 0;
            if (tier === 'Regular' && s.status === 'active') tReg = Math.max(0, s.expires - Math.floor(Date.now()/1000));
            if (tier === 'Gaming' && s.status === 'active') tGam = Math.max(0, s.expires - Math.floor(Date.now()/1000));
            
            if (s.status === 'paused') {
                if (tier === 'Regular') tReg = s.time_left || 0;
                if (tier === 'Gaming') tGam = s.time_left || 0;
            }
            
            let otherTier = (tier === 'Regular') ? 'Gaming' : 'Regular';
            let stateStr = s.status === 'active' ? 'ACTIVE' : (s.status === 'paused' ? 'FROZEN' : 'INACTIVE');
            let stateColor = s.status === 'active' ? 'var(--success)' : 'var(--warning)';

            let html = `
                <div class="mc-grid" style="grid-template-columns: 1fr 1fr;">
                    <div class="mc-box">
                        <h4>CURRENT TIER</h4>
                        <div class="mc-val" style="color: ${tier==='Gaming'?'var(--vip)':'var(--info)'}">${tier.toUpperCase()}</div>
                        <button class="mc-btn" style="margin-top:10px; width:100%; border-color:var(--warning); color:var(--warning);" onclick="execMaster('force_tier', {val: '${otherTier}'})">JUMP TO ${otherTier.toUpperCase()}</button>
                    </div>
                    <div class="mc-box">
                        <h4>STATUS</h4>
                        <div class="mc-val" style="color: ${stateColor}">${stateStr}</div>
                        <button class="mc-btn" style="margin-top:10px; width:100%; border-color:var(--success); color:var(--success);" onclick="execMaster('${s.status==='active'?'freeze':'resume'}')">${s.status==='active'?'🧊 FREEZE SESSION':'▶️ RESUME SESSION'}</button>
                    </div>
                </div>
                
                <h3 style="color: var(--theme-color); font-family: 'Orbitron'; margin: 25px 0 15px 0; text-align: center;">⏱️ TIME MODE - DIRECT EDIT</h3>
                
                <div class="mc-grid">
                    <!-- REGULAR TIER -->
                    <div class="mc-box" style="border-color: var(--info);">
                        <h4 style="color: var(--info);">REGULAR TIER</h4>
                        <div class="mc-val">${formatTimeJS(tReg)}</div>
                        <div style="display:flex; gap:4px; justify-content:center; margin: 15px 0;">
                            <input type="number" id="reg-d" class="mc-input" placeholder="D" min="0" style="width:35px;">:
                            <input type="number" id="reg-h" class="mc-input" placeholder="H" min="0" style="width:35px;">:
                            <input type="number" id="reg-m" class="mc-input" placeholder="M" min="0" style="width:35px;">:
                            <input type="number" id="reg-s" class="mc-input" placeholder="S" min="0" style="width:35px;">
                        </div>
                        <div class="mc-controls">
                            <button class="mc-btn" onclick="submitTimeEdit('Regular', 'add')" style="border-color:var(--success); color:var(--success); width:48%;">+ ADD</button>
                            <button class="mc-btn" onclick="submitTimeEdit('Regular', 'sub')" style="border-color:var(--danger); color:var(--danger); width:48%;">- SUB</button>
                        </div>
                    </div>

                    <!-- GAMING TIER -->
                    <div class="mc-box" style="border-color: var(--vip);">
                        <h4 style="color: var(--vip);">GAMING TIER</h4>
                        <div class="mc-val">${formatTimeJS(tGam)}</div>
                        <div style="display:flex; gap:4px; justify-content:center; margin: 15px 0;">
                            <input type="number" id="gam-d" class="mc-input" placeholder="D" min="0" style="width:35px;">:
                            <input type="number" id="gam-h" class="mc-input" placeholder="H" min="0" style="width:35px;">:
                            <input type="number" id="gam-m" class="mc-input" placeholder="M" min="0" style="width:35px;">:
                            <input type="number" id="gam-s" class="mc-input" placeholder="S" min="0" style="width:35px;">
                        </div>
                        <div class="mc-controls">
                            <button class="mc-btn" onclick="submitTimeEdit('Gaming', 'add')" style="border-color:var(--success); color:var(--success); width:48%;">+ ADD</button>
                            <button class="mc-btn" onclick="submitTimeEdit('Gaming', 'sub')" style="border-color:var(--danger); color:var(--danger); width:48%;">- SUB</button>
                        </div>
                    </div>
                </div>
                
                ${s.pending_coins > 0 ? `
                    <div class="mc-box" style="margin-top:15px; border-color:var(--success);">
                        <h4 style="color:var(--success);">PENDING COINS</h4>
                        <div class="mc-val" style="color:var(--success);">₱${s.pending_coins}</div>
                        <div class="mc-controls" style="margin-top:10px;">
                            <button class="mc-btn" style="border-color:var(--success); color:var(--success); width:100%; font-size: 1.1rem; padding: 10px;" onclick="execMaster('approve_coins')">APPROVE PENDING COINS</button>
                        </div>
                    </div>
                ` : ''}
            `;
            
            document.getElementById('mc-dynamic-area').innerHTML = html;
        } catch(e) {}
    }

    window.submitTimeEdit = function(tier, action) {
        let prefix = tier === 'Regular' ? 'reg' : 'gam';
        let d = document.getElementById(prefix+'-d').value || 0;
        let h = document.getElementById(prefix+'-h').value || 0;
        let m = document.getElementById(prefix+'-m').value || 0;
        let s = document.getElementById(prefix+'-s').value || 0;
        let cmd = action === 'add' ? 'add_time' : 'sub_time';
        execMaster(cmd, { target_tier: tier, d: d, h: h, m: m, s: s });
    };

    async function execMaster(cmd, args = {}) {
        if (!activeMac) return;
        let fd = new FormData();
        fd.append('action', 'master_control'); fd.append('mac', activeMac); fd.append('cmd', cmd);
        
        for (let k in args) { fd.append(k, args[k]); }
        if (currentUserSession) fd.append('tier_target', currentUserSession.tier || 'Regular');
        
        try {
            let res = await fetch('chat.php', { method: 'POST', body: fd });
            let d = await res.json();
            if (d.status === 'success') {
                await refreshControlDeck();
                let badge = document.getElementById('mc-status-badge');
                badge.innerText = "SUCCESS"; badge.style.color = "var(--success)";
                setTimeout(() => { refreshControlDeck(); }, 1500);
            } else { alert("Error: " + d.msg); }
        } catch(e) { console.error(e); }
    }
</script>
</body>
</html>