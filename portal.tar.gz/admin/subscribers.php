<?php
// admin/subscribers.php - OPENWRT RAM-DISK EDITION (WISP Manager)
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php"); exit;
}

$subs_file = DB_DIR . 'subscriptions.json';
if (!file_exists($subs_file)) { pushToVault('subscriptions.json', json_encode([])); }
$subs = json_decode(pullFromVault('subscriptions.json'), true) ?: [];

$message = '';
$current_time = time();
$trigger_firewall_sync = false;

// ⚡ BACKEND ACTION HANDLER
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action === 'add_sub' || $action === 'edit_sub') {
        $sub_id = ($action === 'add_sub') ? "SUB-" . strtoupper(substr(uniqid(), -6)) : $_POST['sub_id'];
        
        $type = $_POST['sub_type'];
        $name = trim($_POST['sub_name']);
        $ttl = (int)$_POST['sub_ttl'];
        $gateway_ip = trim($_POST['gateway_ip']);
        $router_ip = trim($_POST['router_ip']);
        
        $raw_macs = $_POST['sub_macs'] ?? '';
        $mac_array = [];
        if (!empty($raw_macs)) {
            $split_macs = explode(',', $raw_macs);
            foreach ($split_macs as $m) {
                $clean_m = strtoupper(trim($m));
                if (preg_match('/^([0-9A-F]{2}[:-]){5}([0-9A-F]{2})$/', $clean_m)) {
                    $mac_array[] = str_replace('-', ':', $clean_m);
                }
            }
        }
        $mac_array = array_unique($mac_array);

        // Instant cutoff for removed MACs
        if ($action === 'edit_sub' && isset($subs[$sub_id])) {
            $old_macs = $subs[$sub_id]['macs'] ?? [];
            $removed_macs = array_diff($old_macs, $mac_array);
            foreach ($removed_macs as $rm_mac) {
                fw_drop($rm_mac);
            }
        }

        if ($action === 'add_sub') {
            $months = (int)$_POST['sub_duration'];
            $expires_at = $current_time + ($months * 30 * 86400);
            
            if (empty($gateway_ip) || empty($router_ip)) {
                $max_subnet = 0;
                foreach ($subs as $s) {
                    if (isset($s['subnet_id'])) $max_subnet = max($max_subnet, $s['subnet_id']);
                }
                $next_subnet = $max_subnet + 1;
                $gateway_ip = empty($gateway_ip) ? "10.1.{$next_subnet}.1" : $gateway_ip;
                $router_ip = empty($router_ip) ? "10.1.{$next_subnet}.2" : $router_ip;
                $subnet_id = $next_subnet;
            } else {
                $subnet_id = isset($subs[$sub_id]['subnet_id']) ? $subs[$sub_id]['subnet_id'] : rand(100, 999);
            }
            $status = 'active';
            $created_at = $current_time;
        } else {
            $expires_at = strtotime($_POST['expires_at']);
            $subnet_id = $subs[$sub_id]['subnet_id'] ?? rand(100, 999);
            $status = ($expires_at > $current_time) ? 'active' : 'expired';
            $created_at = $subs[$sub_id]['created_at'] ?? $current_time;
        }

        // 🔥 FIXED: Hardcoded Speed to 'MAX' since OpenWrt Lite Mode bypasses throttling!
        $subs[$sub_id] = [
            'name' => $name, 'type' => $type, 'speed' => 'MAX', 'ttl' => $ttl,
            'gateway_ip' => $gateway_ip, 'router_ip' => $router_ip, 'subnet_id' => $subnet_id,
            'macs' => $mac_array, 'expires_at' => $expires_at,
            'status' => $status, 'created_at' => $created_at
        ];

        pushToVault('subscriptions.json', json_encode($subs));
        $word = ($action === 'add_sub') ? 'CREATED' : 'UPDATED';
        $message = "<div style='color: var(--success); font-weight: bold;'>SUCCESS: $word SUBSCRIPTION [$name].</div>";
        $trigger_firewall_sync = true;
    }
    
    elseif ($action === 'delete_sub') {
        $sub_id = $_POST['sub_id'];
        if (isset($subs[$sub_id])) {
            $name = $subs[$sub_id]['name'];
            foreach ($subs[$sub_id]['macs'] as $m) { fw_drop($m); }
            unset($subs[$sub_id]);
            pushToVault('subscriptions.json', json_encode($subs));
            $message = "<div style='color: var(--danger); font-weight: bold;'>PURGED SUBSCRIPTION [$name].</div>";
            $trigger_firewall_sync = true;
        }
    }
    
    elseif ($action === 'renew_sub') {
        $sub_id = $_POST['sub_id'];
        $months = (int)$_POST['months'];
        if (isset($subs[$sub_id])) {
            $add_seconds = $months * 30 * 86400;
            $base_time = ($subs[$sub_id]['expires_at'] > $current_time) ? $subs[$sub_id]['expires_at'] : $current_time;
            $subs[$sub_id]['expires_at'] = $base_time + $add_seconds;
            $subs[$sub_id]['status'] = 'active';
            
            pushToVault('subscriptions.json', json_encode($subs));
            $message = "<div style='color: var(--success); font-weight: bold;'>RENEWED [{$subs[$sub_id]['name']}] FOR $months MONTH(S).</div>";
            $trigger_firewall_sync = true;
        }
    }
    
    elseif ($action === 'update_macs') {
        $sub_id = $_POST['sub_id'];
        if (isset($subs[$sub_id])) {
            $raw_macs = $_POST['new_macs'] ?? '';
            $mac_array = [];
            $split_macs = explode(',', $raw_macs);
            foreach ($split_macs as $m) {
                $clean_m = strtoupper(trim($m));
                if (preg_match('/^([0-9A-F]{2}[:-]){5}([0-9A-F]{2})$/', $clean_m)) {
                    $mac_array[] = str_replace('-', ':', $clean_m);
                }
            }
            $mac_array = array_unique($mac_array);
            
            $old_macs = $subs[$sub_id]['macs'] ?? [];
            $removed_macs = array_diff($old_macs, $mac_array);
            foreach ($removed_macs as $rm_mac) { fw_drop($rm_mac); }

            $subs[$sub_id]['macs'] = $mac_array;
            pushToVault('subscriptions.json', json_encode($subs));
            $message = "<div style='color: var(--info); font-weight: bold;'>UPDATED MAC DEVICES FOR [{$subs[$sub_id]['name']}].</div>";
            $trigger_firewall_sync = true;
        }
    }
}

// 🔄 Auto-Expire Checker
$needs_save = false;
foreach ($subs as $id => &$sub) {
    if ($sub['expires_at'] <= $current_time && $sub['status'] === 'active') {
        $sub['status'] = 'expired';
        foreach ($sub['macs'] as $m) { fw_drop($m); }
        $needs_save = true;
        $trigger_firewall_sync = true;
    } elseif ($sub['expires_at'] > $current_time && $sub['status'] === 'expired') {
        $sub['status'] = 'active';
        $needs_save = true;
        $trigger_firewall_sync = true;
    }
}
if ($needs_save) pushToVault('subscriptions.json', json_encode($subs));

// OpenWrt Native Firewall Reload (No sudo needed)
if ($trigger_firewall_sync) {
    exec("/etc/vaultos_core.sh > /dev/null 2>&1 &");
}

require_once 'header.php';
?>

<div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 30px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="color: var(--vip); text-shadow: 0 0 10px var(--vip); margin-bottom:5px;">WISP MANAGER</h1>
        <p style="color: #888; margin-top:0;">Manage dedicated monthly subscribers, bypasses, and isolated IPs.</p>
    </div>
    <div style="display: flex; gap: 10px;">
        <div style="background: rgba(176, 38, 255, 0.05); border: 1px solid rgba(176, 38, 255, 0.2); padding: 10px 20px; border-radius: 4px; text-align: right;">
            <div style="font-size: 0.7rem; color: var(--vip); font-family: 'Orbitron'; letter-spacing: 2px;">ACTIVE SUBS</div>
            <div style="font-size: 1.5rem; color: #fff; font-family: 'Orbitron'; font-weight: bold;"><?php echo count(array_filter($subs, fn($s) => $s['status']==='active')); ?></div>
        </div>
        <button class="btn btn-success" onclick="openAddModal()" style="margin-top: 0; padding: 10px 20px; font-size: 1rem; width: auto; box-shadow: 0 0 15px rgba(16,185,129,0.4);">+ ADD SUBSCRIBER</button>
    </div>
</div>

<div id="alert-box"><?php echo $message; ?></div>
<script>setTimeout(() => { let a = document.getElementById('alert-box'); if(a) a.innerHTML = ''; }, 4000);</script>

<style>
    .sub-card { background: rgba(0, 5, 15, 0.6); border: 1px solid #333; border-radius: 5px; margin-bottom: 15px; padding: 15px; display: grid; grid-template-columns: 2fr 1fr 1.5fr 1fr; gap: 15px; align-items: center; box-shadow: 0 0 15px rgba(0,0,0,0.8); }
    .sub-card.router { border-left: 4px solid var(--vip); }
    .sub-card.phone { border-left: 4px solid var(--info); }
    .sub-card.expired { border-left: 4px solid var(--danger); opacity: 0.8; }
    
    .lbl { font-size: 0.7rem; color: #888; font-family: 'Orbitron'; letter-spacing: 1px; margin-bottom: 3px; display: block; }
    .val { font-size: 1.1rem; color: #fff; font-weight: bold; font-family: 'Rajdhani'; }
    .mac-chip { display: inline-flex; align-items: center; background: #111; border: 1px solid var(--theme-color); color: #fff; padding: 4px 8px; font-size: 0.8rem; font-family: 'Source Code Pro'; border-radius: 4px; margin: 3px; }
    .mac-chip span { margin-right: 5px; }
    .mac-chip button { background: transparent; border: none; color: var(--danger); cursor: pointer; font-weight: bold; padding: 0 2px; }
    
    .input-field { width:100%; padding:10px; background:#111; color:#fff; border:1px solid #555; margin-bottom:10px; box-sizing:border-box; font-family:'Rajdhani'; font-size: 1rem;}
</style>

<!-- 🔥 RENDER SUBSCRIPTIONS 🔥 -->
<?php foreach(['router' => ['color'=>'--vip', 'title'=>'📡 ROUTER SUBSCRIPTIONS (SOLO IP)'], 'phone_group' => ['color'=>'--info', 'title'=>'📱 PHONE GROUPS (BULK MACS)']] as $filter_type => $ui): ?>
    <h2 style="color: var(<?php echo $ui['color']; ?>); font-family: 'Orbitron'; margin-top: 30px; margin-bottom: 15px; border-bottom: 1px dashed var(<?php echo $ui['color']; ?>); padding-bottom: 5px;"><?php echo $ui['title']; ?></h2>
    <?php
    $filtered = array_filter($subs, fn($s) => $s['type'] === $filter_type);
    if (empty($filtered)) echo "<p style='color:#555; text-align:center; padding: 20px;'>No Active Subscriptions.</p>";

    foreach($filtered as $id => $s):
        $is_exp = ($s['status'] === 'expired');
        $days_left = max(0, floor(($s['expires_at'] - $current_time) / 86400));
    ?>
        <div class="sub-card <?php echo $filter_type === 'router' ? 'router' : 'phone'; ?> <?php echo $is_exp ? 'expired' : ''; ?>">
            <div>
                <span class="lbl">NAME / IDENTIFIER</span>
                <span class="val" style="color: var(<?php echo $ui['color']; ?>); font-size: 1.3rem; font-family:'Orbitron'; text-transform:uppercase;"><?php echo htmlspecialchars($s['name']); ?></span>
                <div style="margin-top: 5px; max-height: 60px; overflow-y:auto;">
                    <?php foreach($s['macs'] as $m) echo "<div class='mac-chip'><span>$m</span></div>"; ?>
                </div>
            </div>
            
            <div>
                <span class="lbl">NETWORK CONFIG</span>
                <div class="val" style="font-size: 0.9rem;">Speed: <span style="color:var(--danger); font-weight:bold;">MAX (Bypassed)</span></div>
                <div class="val" style="font-size: 0.9rem;">TTL Lock: <span style="color:var(--warning);"><?php echo $s['ttl']; ?></span></div>
            </div>
            
            <div>
                <span class="lbl">IP ASSIGNMENT</span>
                <div class="val" style="font-size: 0.9rem; font-family:'Source Code Pro';">Gateway: <span style="color:#aaa;"><?php echo $s['gateway_ip']; ?></span></div>
                <div class="val" style="font-size: 0.9rem; font-family:'Source Code Pro';">Device IP: <span style="color:var(--info);"><?php echo $s['router_ip']; ?></span></div>
            </div>
            
            <div style="text-align: right;">
                <span class="lbl">STATUS</span>
                <?php if($is_exp): ?>
                    <div class="val" style="color: var(--danger); font-family:'Orbitron';">EXPIRED</div>
                <?php else: ?>
                    <div class="val" style="color: var(--success); font-family:'Orbitron';"><?php echo $days_left; ?> DAYS LEFT</div>
                <?php endif; ?>
                
                <div style="margin-top: 10px; display:flex; gap:5px; flex-wrap:wrap; justify-content:flex-end;">
                    <button type="button" class="btn" onclick='openEditModal(<?php echo json_encode(array_merge($s, ['id' => $id, 'expires_at_formatted' => date('Y-m-d\TH:i', $s['expires_at'])])); ?>)' style="padding: 5px; font-size:0.7rem; width:auto; margin:0; border-color:var(--warning); color:var(--warning);">EDIT</button>
                    <form method="POST" style="margin:0;" onsubmit="return confirm('Delete <?php echo $s['name']; ?>?');"><input type="hidden" name="action" value="delete_sub"><input type="hidden" name="sub_id" value="<?php echo $id; ?>"><button type="submit" class="btn btn-danger" style="padding: 5px; font-size:0.7rem; width:auto; margin:0;">DEL</button></form>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php endforeach; ?>

<!-- 🔥 UNIVERSAL MODAL: ADD / EDIT SUBSCRIBER 🔥 -->
<div id="m-sub-modal" class="modal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.8); z-index:9999; align-items:center; justify-content:center;">
    <div style="background:#000; border:2px solid var(--vip); padding:25px; border-radius:8px; width:95%; max-width:450px; box-shadow: 0 0 20px rgba(176,38,255,0.4); max-height: 90vh; overflow-y: auto;">
        <h2 id="modal-title" style="color:var(--vip); font-family:'Orbitron'; margin-top:0;">+ NEW SUBSCRIBER</h2>
        
        <form method="POST" id="sub-form" onsubmit="syncMacsToInput()">
            <input type="hidden" name="action" id="modal-action" value="add_sub">
            <input type="hidden" name="sub_id" id="modal-sub-id" value="">
            <input type="hidden" name="sub_macs" id="hidden-mac-input" value="">
            
            <div style="display:flex; gap:10px;">
                <div style="flex:1;">
                    <label class="lbl">TYPE</label>
                    <select name="sub_type" id="modal-sub-type" class="input-field" onchange="toggleSubType()">
                        <option value="router">📡 ROUTER</option>
                        <option value="phone_group">📱 PHONE</option>
                    </select>
                </div>
                <div style="flex:2;">
                    <label class="lbl">NAME / IDENTIFIER</label>
                    <input type="text" name="sub_name" id="modal-sub-name" class="input-field" required>
                </div>
            </div>

            <label class="lbl">MAC ADDRESSES (Type MAC and press Enter)</label>
            <div style="background:#111; border:1px solid #555; padding:5px; margin-bottom:10px; border-radius:4px; min-height:50px;">
                <div id="mac-chip-container" style="display:inline;"></div>
                <input type="text" id="mac-typer" placeholder="AA:BB:CC:DD:EE:FF" style="background:transparent; border:none; color:var(--info); font-family:'Source Code Pro'; width:160px; padding:5px; outline:none;" onkeypress="handleMacTyping(event)">
            </div>

            <div style="margin-bottom: 10px;">
                <label class="lbl">TTL LOCK (1 = Block Hotspot, 64 = Allow Hotspot)</label>
                <input type="number" name="sub_ttl" id="modal-sub-ttl" class="input-field" style="color:var(--warning); font-weight:bold; text-align:center;" required>
            </div>

            <div style="display:flex; gap:10px;">
                <div style="flex:1;">
                    <label class="lbl">GATEWAY IP (Optional)</label>
                    <input type="text" name="gateway_ip" id="modal-gw-ip" class="input-field" placeholder="Auto-Generate" style="font-family:'Source Code Pro'; font-size:0.85rem;">
                </div>
                <div style="flex:1;">
                    <label class="lbl">DEVICE IP (Optional)</label>
                    <input type="text" name="router_ip" id="modal-dev-ip" class="input-field" placeholder="Auto-Generate" style="font-family:'Source Code Pro'; font-size:0.85rem;">
                </div>
            </div>

            <div id="div-add-duration">
                <label class="lbl">INITIAL DURATION</label>
                <select name="sub_duration" id="modal-sub-duration" class="input-field">
                    <option value="1">1 Month (30 Days)</option>
                    <option value="2">2 Months (60 Days)</option>
                    <option value="3">3 Months (90 Days)</option>
                    <option value="6">6 Months (180 Days)</option>
                    <option value="12">1 Year (360 Days)</option>
                </select>
            </div>

            <div id="div-edit-date" style="display:none;">
                <label class="lbl">EXPIRATION DATE & TIME</label>
                <input type="datetime-local" name="expires_at" id="modal-expires-at" class="input-field" style="color:var(--danger); font-weight:bold;">
            </div>

            <button type="submit" id="modal-submit-btn" class="btn btn-success" style="width:100%; padding:12px; font-size:1rem;">CREATE SUBSCRIPTION</button>
            <button type="button" class="btn outline" onclick="document.getElementById('m-sub-modal').style.display='none'" style="width:100%; border-color:#555; color:#888; margin-top:10px;">CANCEL</button>
        </form>
    </div>
</div>

<script>
    let macList = [];

    function renderMacChips() {
        let container = document.getElementById('mac-chip-container');
        container.innerHTML = '';
        macList.forEach((m, index) => {
            container.innerHTML += `<div class="mac-chip"><span>${m}</span> <button type="button" onclick="removeMac(${index})">X</button></div>`;
        });
    }

    function handleMacTyping(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            let val = e.target.value.trim().toUpperCase();
            if (val && !macList.includes(val)) {
                macList.push(val);
                renderMacChips();
            }
            e.target.value = '';
        }
    }

    function removeMac(index) {
        macList.splice(index, 1);
        renderMacChips();
    }

    function syncMacsToInput() {
        document.getElementById('hidden-mac-input').value = macList.join(',');
    }

    function openAddModal() {
        document.getElementById('modal-action').value = 'add_sub';
        document.getElementById('modal-title').innerText = '+ NEW SUBSCRIBER';
        document.getElementById('modal-submit-btn').innerText = 'CREATE SUBSCRIPTION';
        
        document.getElementById('sub-form').reset();
        macList = []; renderMacChips();
        
        document.getElementById('modal-sub-ttl').value = 64;
        
        document.getElementById('div-add-duration').style.display = 'block';
        document.getElementById('div-edit-date').style.display = 'none';
        
        document.getElementById('m-sub-modal').style.display = 'flex';
    }

    function openEditModal(sub) {
        document.getElementById('modal-action').value = 'edit_sub';
        document.getElementById('modal-sub-id').value = sub.id;
        document.getElementById('modal-title').innerText = '⚙️ EDIT SUBSCRIBER';
        document.getElementById('modal-submit-btn').innerText = 'SAVE CHANGES';
        
        document.getElementById('modal-sub-type').value = sub.type;
        document.getElementById('modal-sub-name').value = sub.name;
        document.getElementById('modal-sub-ttl').value = sub.ttl;
        document.getElementById('modal-gw-ip').value = sub.gateway_ip || '';
        document.getElementById('modal-dev-ip').value = sub.router_ip || '';
        
        macList = sub.macs || [];
        renderMacChips();
        
        document.getElementById('div-add-duration').style.display = 'none';
        document.getElementById('div-edit-date').style.display = 'block';
        document.getElementById('modal-expires-at').value = sub.expires_at_formatted;
        
        document.getElementById('m-sub-modal').style.display = 'flex';
    }

    function toggleSubType() {
        let type = document.getElementById('modal-sub-type').value;
        let ttl = document.getElementById('modal-sub-ttl');
        if (type === 'router') { ttl.value = 64; } 
        else { ttl.value = 1; }
    }
</script>

</div></body></html>