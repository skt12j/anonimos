<?php
// admin/users.php - OPENWRT RAM-DISK EDITION (Time Radar)
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php"); exit;
}

$sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
$blocked = json_decode(pullFromVault('blocked.json'), true) ?: [];
$chat_names = json_decode(pullFromVault('chat_names.json'), true) ?: [];

$current_time = time();
$message = '';

// ⚡ AJAX COMMAND HANDLER
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['mac'])) {
    $mac = $_POST['mac'];
    $action = $_POST['action'];
    $ip = $sessions[$mac]['ip'] ?? '';
    
    if (isset($sessions[$mac])) {
        $active_tier = $sessions[$mac]['tier'] ?? 'Regular';

        // --- ⏳ TIME CONTROLS ---
        if ($action === 'extend' || $action === 'reduce') {
            $days  = (int)($_POST['days'] ?? 0);
            $hours = (int)($_POST['hours'] ?? 0);
            $mins  = (int)($_POST['mins'] ?? 0);
            $secs_in = (int)($_POST['secs'] ?? 0);
            
            $secs = ($days * 86400) + ($hours * 3600) + ($mins * 60) + $secs_in;
            $target = $_POST['target_tier'] ?? 'Regular';

            if ($active_tier === $target && $sessions[$mac]['status'] === 'active') {
                $sessions[$mac]['expires'] += ($action === 'extend') ? $secs : -$secs;
            } else {
                $bank_key = "bank_$target";
                $sessions[$mac][$bank_key] = max(0, ($sessions[$mac][$bank_key] ?? 0) + (($action === 'extend') ? $secs : -$secs));
            }
            
            $msg_time = "";
            if($days>0) $msg_time.="${days}D "; if($hours>0) $msg_time.="${hours}H "; 
            if($mins>0) $msg_time.="${mins}M "; if($secs_in>0) $msg_time.="${secs_in}S";
            if($msg_time === "") $msg_time = "0S";
            
            $msg_word = ($action === 'extend') ? 'INJECTED' : 'REMOVED';
            $message = "<div style='color: var(--success); font-weight: bold;'>$msg_word ".trim($msg_time)." FOR [$mac].</div>";
        }

        // --- 🔌 STATE & TIER CONTROLS ---
        elseif ($action === 'force_tier') {
            $target = $_POST['force_target'];
            
            if ($sessions[$mac]['status'] === 'active') {
                $sessions[$mac]["bank_$active_tier"] = max(0, $sessions[$mac]['expires'] - $current_time);
            }
            
            $sessions[$mac]['tier'] = $target;
            $new_time = $sessions[$mac]["bank_$target"] ?? 0;
            
            if ($new_time > 0) {
                $sessions[$mac]['active_mode'] = 'Time';
                $sessions[$mac]['expires'] = $current_time + $new_time;
                $sessions[$mac]["bank_$target"] = 0;
                $sessions[$mac]['status'] = 'active';
                fw_allow($mac, $ip, $target);
            } else {
                $sessions[$mac]['status'] = 'paused';
                fw_drop($mac, $ip);
            }
            $message = "<div style='color: var(--warning); font-weight: bold;'>FORCED MAC [$mac] TO $target TIER.</div>";
        }
        elseif ($action === 'pause') {
            if ($sessions[$mac]['status'] === 'active') {
                $sessions[$mac]['time_left'] = max(0, $sessions[$mac]['expires'] - $current_time);
                $sessions[$mac]['status'] = 'paused';
                $sessions[$mac]['last_paused_at'] = $current_time;
                fw_drop($mac, $ip);
                $message = "<div style='color: var(--info); font-weight: bold;'>SESSION [$mac] FROZEN.</div>";
            }
        } 
        elseif ($action === 'resume') {
            if ($sessions[$mac]['status'] === 'paused') {
                $sessions[$mac]['expires'] = $current_time + ($sessions[$mac]['time_left'] ?? 0);
                $sessions[$mac]['time_left'] = 0;
                $sessions[$mac]['status'] = 'active';
                unset($sessions[$mac]['last_paused_at']);
                fw_allow($mac, $ip, $active_tier);
                $message = "<div style='color: var(--success); font-weight: bold;'>SESSION [$mac] RESUMED.</div>";
            }
        } 
        elseif ($action === 'kick') {
            $sessions[$mac]['expires'] = 0;
            $sessions[$mac]['time_left'] = 0;
            $sessions[$mac]['bank_Regular'] = 0; 
            $sessions[$mac]['bank_Gaming'] = 0;  
            $sessions[$mac]['status'] = 'expired';
            fw_drop($mac, $ip);
            $message = "<div style='color: var(--danger); font-weight: bold;'>MAC [$mac] KICKED & WIPED.</div>";
        }
        elseif ($action === 'delete') {
            unset($sessions[$mac]);
            fw_drop($mac, $ip);
            $message = "<div style='color: var(--danger); font-weight: bold;'>MAC [$mac] PERMANENTLY PURGED.</div>";
        }
        elseif ($action === 'ban') {
            $blocked[strtoupper($mac)] = [
                'date_banned' => date('Y-m-d H:i:s'),
                'reason' => "Admin Perma-Ban"
            ];
            unset($sessions[$mac]);
            pushToVault('blocked.json', json_encode($blocked));
            fw_ban($mac, $ip);
            $message = "<div style='color: var(--danger); font-weight: bold;'>MAC [$mac] BANNED.</div>";
        }

        if (in_array($action, ['extend', 'reduce'])) {
            if (($active_tier === ($_POST['target_tier'] ?? 'Regular')) && ($sessions[$mac]['status'] === 'active')) {
                 fw_allow($mac, $ip, $active_tier);
            }
        }
        pushToVault('sessions.json', json_encode($sessions));
    }
    if (isset($_POST['ajax_action'])) { echo json_encode(['status' => 'success', 'message' => $message]); exit; }
}

require_once 'header.php';
?>

<div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 30px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="color: var(--info); text-shadow: 0 0 10px var(--info); margin-bottom:5px;">NETWORK RADAR <span id="sync-pulse" style="font-size:0.5em; color:var(--success);">●</span></h1>
        <p style="color: #888; margin-top:0;">Manage all users. View active mode and precision time banks.</p>
    </div>
</div>

<div id="alert-box"></div>

<style>
    .sortable-header { cursor: pointer; user-select: none; transition: color 0.2s; position: relative; }
    .sortable-header:hover { color: #fff; background: rgba(255,255,255,0.05); }
    .sort-icon { font-size: 0.7rem; margin-left: 5px; color: #888; display:inline-block; }
    .table-section { margin-bottom: 40px; border: 1px solid rgba(0, 243, 255, 0.2); border-radius: 4px; overflow: hidden; background: rgba(0, 5, 15, 0.6); box-shadow: 0 0 20px rgba(0,0,0,0.8); }
    .section-header { padding: 15px; font-family: 'Orbitron'; font-size: 1.2rem; font-weight: 900; border-bottom: 2px solid; letter-spacing: 2px; }
    .sh-time { color: var(--success); border-color: var(--success); text-shadow: 0 0 10px var(--success); }
    .sh-bank { color: var(--warning); border-color: var(--warning); text-shadow: 0 0 10px var(--warning); }
    .sh-expired { color: var(--danger); border-color: var(--danger); text-shadow: 0 0 10px var(--danger); }
</style>

<div class="table-section">
    <div class="section-header sh-time">⏱️ ACTIVE TIME SESSIONS</div>
    <div style="overflow-x: auto;">
        <table style="width:100%; border-collapse:collapse; min-width:1400px;">
            <thead>
                <tr style="background: rgba(0,243,255,0.05); border-bottom: 1px solid #333;">
                    <th class="sortable-header" onclick="setSort('device')" style="padding:15px 10px;">DEVICE <span class="sort-icon">↕</span></th>
                    <th class="sortable-header" onclick="setSort('reg_time')" style="padding:15px 10px;">REGULAR TIME <span class="sort-icon">↕</span></th>
                    <th style="padding:15px 10px;">GAMING TIME</th>
                    <th class="sortable-header" onclick="setSort('state')" style="padding:15px 10px; text-align:center;">STATE <span class="sort-icon">↕</span></th>
                    <th style="padding:15px 10px; text-align:center;">CONTROLS</th>
                </tr>
            </thead>
            <tbody id="ajax-time">
                <tr><td colspan='5' style='text-align: center; color: #555; padding: 30px;'>SCANNING RADAR...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<div class="table-section">
    <div class="section-header sh-bank">❄️ FROZEN & BANKED ACCOUNTS</div>
    <div style="overflow-x: auto;">
        <table style="width:100%; border-collapse:collapse; min-width:1400px;">
            <thead>
                <tr style="background: rgba(0,243,255,0.05); border-bottom: 1px solid #333;">
                    <th class="sortable-header" onclick="setSort('device')" style="padding:15px 10px;">DEVICE <span class="sort-icon">↕</span></th>
                    <th class="sortable-header" onclick="setSort('reg_time')" style="padding:15px 10px;">BANKED TIME <span class="sort-icon">↕</span></th>
                    <th class="sortable-header" onclick="setSort('state')" style="padding:15px 10px; text-align:center;">STATE <span class="sort-icon">↕</span></th>
                    <th style="padding:15px 10px; text-align:center;">CONTROLS</th>
                </tr>
            </thead>
            <tbody id="ajax-bank">
                <tr><td colspan='4' style='text-align: center; color: #555; padding: 30px;'>SCANNING RADAR...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<div class="table-section">
    <div class="section-header sh-expired">💀 RECENTLY EXPIRED / LOBBY (WAITING FOR DAEMON)</div>
    <div style="overflow-x: auto;">
        <table style="width:100%; border-collapse:collapse; min-width:1400px;">
            <thead>
                <tr style="background: rgba(0,243,255,0.05); border-bottom: 1px solid #333;">
                    <th class="sortable-header" onclick="setSort('device')" style="padding:15px 10px;">DEVICE <span class="sort-icon">↕</span></th>
                    <th class="sortable-header" onclick="setSort('state')" style="padding:15px 10px; text-align:center;">STATE <span class="sort-icon">↕</span></th>
                    <th style="padding:15px 10px; text-align:center;">CONTROLS</th>
                </tr>
            </thead>
            <tbody id="ajax-expired">
                <tr><td colspan='3' style='text-align: center; color: #555; padding: 30px;'>SCANNING RADAR...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<script>
    let chatNames = <?php echo json_encode($chat_names); ?>;
    let currentSort = { column: 'state', direction: 'desc' }; 

    window.setSort = function(column) {
        if (currentSort.column === column) {
            currentSort.direction = currentSort.direction === 'asc' ? 'desc' : 'asc';
        } else {
            currentSort.column = column;
            currentSort.direction = 'desc'; 
        }
        fetchLiveUsers(); 
    };

    function formatTimeJS(totalSeconds) {
        if (totalSeconds <= 0) return "00:00:00";
        let h = Math.floor(totalSeconds / 3600).toString().padStart(2, '0');
        let m = Math.floor((totalSeconds % 3600) / 60).toString().padStart(2, '0');
        let s = Math.floor(totalSeconds % 60).toString().padStart(2, '0');
        return `${h}:${m}:${s}`;
    }

    window.executeAction = function(btn, actionName, extra = {}) {
        let form = btn.closest('form');
        let formData = new FormData(form);
        formData.append('ajax_action', '1');
        formData.append('action', actionName);
        for (let key in extra) formData.append(key, extra[key]);

        fetch(window.location.href, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.message) {
                document.getElementById('alert-box').innerHTML = data.message;
                setTimeout(() => document.getElementById('alert-box').innerHTML = '', 4000);
            }
            fetchLiveUsers();
        })
        .catch(err => console.error("Action Error:", err));
    };

    function fetchLiveUsers() {
        if (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'SELECT') return;

        fetch('api_core.php?action=users')
            .then(response => response.json())
            .then(data => {
                let timeHtml = '';
                let bankHtml = '';
                let expiredHtml = '';

                let users = data.users;

                users.forEach(u => {
                    u.uName = chatNames[u.mac] ? chatNames[u.mac] : "UNKNOWN NODE";
                    if (u.status === 'paused') u.sortState = 3; 
                    else if (u.status === 'active') u.sortState = u.is_connected ? 5 : 4; 
                    else if (u.status === 'inactive') u.sortState = 1; 
                    else u.sortState = 2; 
                });

                if (currentSort.column) {
                    users.sort((a, b) => {
                        let valA, valB;
                        if (currentSort.column === 'device') { valA = a.uName.toLowerCase(); valB = b.uName.toLowerCase(); }
                        else if (currentSort.column === 'reg_time') { valA = a.time_left || 0; valB = b.time_left || 0; }
                        else if (currentSort.column === 'state') { valA = a.sortState; valB = b.sortState; }
                        else { valA = 0; valB = 0; }

                        if (valA < valB) return currentSort.direction === 'asc' ? -1 : 1;
                        if (valA > valB) return currentSort.direction === 'asc' ? 1 : -1;
                        return 0;
                    });
                }

                users.forEach(u => {
                    let stateLabel = "EXPIRED"; 
                    let stateColor = "#555";
                    if (u.status === 'paused') { 
                        stateLabel = "FROZEN"; 
                        stateColor = "var(--warning)"; 
                    } else if (u.status === 'active') {
                        if (u.is_connected) { 
                            stateLabel = "ACTIVE"; 
                            stateColor = "#0088ff"; 
                        } else { 
                            stateLabel = "PASSIVE<br><span style='font-size:0.6rem;'>(AWAY)</span>"; 
                            stateColor = "var(--success)"; 
                        }
                    } else if (u.status === 'inactive') {
                        stateLabel = "LOBBY<br><span style='font-size:0.6rem;'>(WIPED)</span>";
                        stateColor = "var(--danger)";
                    } else if (u.status === 'expired') {
                        stateLabel = "EXPIRED";
                        stateColor = "var(--danger)";
                    }

                    let actionButtons = (u.status === 'active') 
                        ? `<form style='margin: 0;'><input type='hidden' name='mac' value='${u.mac}'><button type='button' onclick='executeAction(this, "pause")' class='btn' style='padding: 5px; font-size: 0.7rem; border-color: var(--info); color: var(--info); width:60px;'>PAUSE</button></form>`
                        : `<form style='margin: 0;'><input type='hidden' name='mac' value='${u.mac}'><button type='button' onclick='executeAction(this, "resume")' class='btn btn-success' style='padding: 5px; font-size: 0.7rem; width:60px;'>RESUME</button></form>`;
                        
                    let forceTierTarget = (u.active_tier === 'Regular') ? 'Gaming' : 'Regular';
                    let forceTierColor = (u.active_tier === 'Regular') ? 'var(--vip)' : 'var(--info)';
                    let forceTierBtn = `<form style='margin: 0;'><input type='hidden' name='mac' value='${u.mac}'><input type='hidden' name='force_target' value='${forceTierTarget}'><button type='button' onclick='executeAction(this, "force_tier")' class='btn' style='padding: 5px; font-size: 0.7rem; border-color: ${forceTierColor}; color: ${forceTierColor};'>JUMP -> ${forceTierTarget.substring(0,3)}</button></form>`;
                    
                    let actionRow = `<div style='display: flex; gap: 5px; justify-content:center;'>
                                        ${actionButtons} ${forceTierBtn}
                                        <form style='margin: 0;'><input type='hidden' name='mac' value='${u.mac}'><button type='button' onclick='executeAction(this, "kick")' class='btn' style='padding: 5px; font-size: 0.7rem; border-color: #f59e0b; color: #f59e0b;'>KICK</button></form>
                                        <form style='margin: 0;'><input type='hidden' name='mac' value='${u.mac}'><button type='button' onclick='executeAction(this, "ban")' class='btn btn-danger' style='padding: 5px; font-size: 0.7rem;'>BAN</button></form>
                                    </div>`;
                                    
                    let wipeRow = `<div style='display: flex; gap: 5px; justify-content:center;'>
                                        <form style='margin: 0;'><input type='hidden' name='mac' value='${u.mac}'><button type='button' onclick='executeAction(this, "delete")' class='btn' style='padding: 5px; font-size: 0.7rem; border-color: var(--danger); color: var(--danger);'>DELETE SESSION</button></form>
                                        <form style='margin: 0;'><input type='hidden' name='mac' value='${u.mac}'><button type='button' onclick='executeAction(this, "ban")' class='btn btn-danger' style='padding: 5px; font-size: 0.7rem;'>BAN</button></form>
                                    </div>`;

                    let timeForm = `<form style='display: flex; gap: 3px; align-items: center; justify-content:center; margin: 0;'>
                                        <input type='hidden' name='mac' value='${u.mac}'>
                                        <input type='number' name='days' placeholder='D' min='0' style='width: 32px; padding: 3px; background: rgba(0,0,0,0.5); border: 1px solid var(--theme-color); color: #fff; text-align: center; font-size:0.75rem;'>
                                        <input type='number' name='hours' placeholder='H' min='0' style='width: 32px; padding: 3px; background: rgba(0,0,0,0.5); border: 1px solid var(--theme-color); color: #fff; text-align: center; font-size:0.75rem;'>
                                        <input type='number' name='mins' placeholder='M' min='0' style='width: 32px; padding: 3px; background: rgba(0,0,0,0.5); border: 1px solid var(--theme-color); color: #fff; text-align: center; font-size:0.75rem;'>
                                        <input type='number' name='secs' placeholder='S' min='0' style='width: 32px; padding: 3px; background: rgba(0,0,0,0.5); border: 1px solid var(--theme-color); color: #fff; text-align: center; font-size:0.75rem;'>
                                        <select name='target_tier' style='padding: 3px; background: rgba(0,0,0,0.5); border: 1px solid var(--theme-color); color: #fff; font-family: "Rajdhani"; font-size:0.75rem;'>
                                            <option value='Regular' style='color: var(--info);'>Reg</option><option value='Gaming' style='color: var(--vip);'>Gam</option>
                                        </select>
                                        <button type='button' onclick='executeAction(this, "extend")' class='btn btn-success' style='padding: 3px 5px; font-size: 0.75rem; font-weight:bold;'>+</button>
                                        <button type='button' onclick='executeAction(this, "reduce")' class='btn' style='padding: 3px 5px; font-size: 0.75rem; border-color:#888; color:#888; font-weight:bold;'>-</button>
                                    </form>`;

                    // 1. ACTIVE TIME USERS
                    if (u.status === 'active') {
                        let regTime = (u.active_tier === 'Regular') ? `<span class='live-timer' data-seconds='${u.time_left}' data-state='active'>${formatTimeJS(u.time_left)}</span> <span style='font-size:0.6rem; color:#fff; border:1px solid #fff; padding:2px;'>ON</span>` : formatTimeJS(u.time_left);
                        let gamTime = (u.active_tier === 'Gaming') ? `<span class='live-timer' data-seconds='${u.time_left}' data-state='active'>${formatTimeJS(u.time_left)}</span> <span style='font-size:0.6rem; color:#fff; border:1px solid #fff; padding:2px;'>ON</span>` : "00:00:00";
                        
                        let adminControls = `<div style="display:flex; flex-direction:column; gap:10px;">${timeForm}${actionRow}</div>`;

                        timeHtml += `<tr style='border-bottom: 1px solid rgba(255,255,255,0.05);'>
                            <td style='padding: 15px 10px; font-family: "Orbitron"; font-size: 0.9rem;'><span style='color:var(--info); font-weight:bold; text-transform:uppercase;'>${u.uName}</span><br>${u.mac}<br><span style='color:#555; font-size:0.7rem;'>IP: ${u.ip}</span></td>
                            <td style='padding: 15px 10px; font-family: "Orbitron"; font-size: 1.1rem; color: var(--info);'>${regTime}</td>
                            <td style='padding: 15px 10px; font-family: "Orbitron"; font-size: 1.1rem; color: var(--vip);'>${gamTime}</td>
                            <td style='padding: 15px 10px; font-weight:bold; text-align:center; font-family:"Orbitron"; color:${stateColor};'>${stateLabel}</td>
                            <td style='padding: 15px 10px;'>${adminControls}</td>
                        </tr>`;
                    }
                    
                    // 2. PASSIVE / PAUSED USERS
                    else if (u.status === 'paused') {
                        let bTime = `<div style="color:var(--info); font-family:Orbitron;">REG: ${formatTimeJS(u.time_left)}</div>`;
                        let adminControls = `<div style="display:flex; flex-direction:column; gap:10px;">${timeForm}${actionRow}</div>`;

                        bankHtml += `<tr style='border-bottom: 1px solid rgba(255,255,255,0.05);'>
                            <td style='padding: 15px 10px; font-family: "Orbitron"; font-size: 0.9rem;'><span style='color:var(--info); font-weight:bold; text-transform:uppercase;'>${u.uName}</span><br>${u.mac}<br><span style='color:#555; font-size:0.7rem;'>IP: ${u.ip}</span></td>
                            <td style='padding: 15px 10px;'>${bTime}</td>
                            <td style='padding: 15px 10px; font-weight:bold; text-align:center; font-family:"Orbitron"; color:${stateColor};'>${stateLabel}</td>
                            <td style='padding: 15px 10px;'>${adminControls}</td>
                        </tr>`;
                    }
                    
                    // 3. EXPIRED / ZOMBIE USERS
                    else if (u.status === 'expired' || u.status === 'inactive') {
                        let adminControls = `<div style="display:flex; flex-direction:column; gap:10px;">${timeForm}${wipeRow}</div>`;

                        expiredHtml += `<tr style='border-bottom: 1px solid rgba(255,0,0,0.1); background: rgba(255,0,0,0.02);'>
                            <td style='padding: 15px 10px; font-family: "Orbitron"; font-size: 0.9rem;'><span style='color:var(--info); font-weight:bold; text-transform:uppercase;'>${u.uName}</span><br>${u.mac}<br><span style='color:#555; font-size:0.7rem;'>IP: ${u.ip}</span></td>
                            <td style='padding: 15px 10px; font-weight:bold; text-align:center; font-family:"Orbitron"; color:${stateColor};'>${stateLabel}</td>
                            <td style='padding: 15px 10px;'>${adminControls}</td>
                        </tr>`;
                    }
                });

                document.getElementById('ajax-time').innerHTML = timeHtml || "<tr><td colspan='5' style='text-align: center; color: #555; padding: 30px;'>NO ACTIVE TIME SESSIONS.</td></tr>";
                document.getElementById('ajax-bank').innerHTML = bankHtml || "<tr><td colspan='4' style='text-align: center; color: #555; padding: 30px;'>NO PASSIVE OR PAUSED SESSIONS.</td></tr>";
                document.getElementById('ajax-expired').innerHTML = expiredHtml || "<tr><td colspan='3' style='text-align: center; color: #555; padding: 30px;'>NO EXPIRED SESSIONS DETECTED.</td></tr>";

                let pulse = document.getElementById('sync-pulse');
                pulse.style.opacity = '1';
                setTimeout(() => pulse.style.opacity = '0.2', 500);
            }).catch(err => console.error("SYNC ERROR:", err));
    }

    fetchLiveUsers();
    setInterval(fetchLiveUsers, 3000);

    setInterval(() => {
        let timers = document.querySelectorAll('.live-timer');
        timers.forEach(timer => {
            if (timer.getAttribute('data-state') === 'active') {
                let seconds = parseInt(timer.getAttribute('data-seconds'));
                if (seconds > 0) {
                    seconds--; 
                    timer.setAttribute('data-seconds', seconds); 
                    timer.innerText = formatTimeJS(seconds); 
                }
            }
        });
    }, 1000);
</script>
</div></body></html>