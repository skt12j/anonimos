<?php
// portal/coin_core.php - OPENWRT RAM-DISK EDITION (Instant Coin Drop & Offline Fix)
require_once '../core.php';

$payment_config_raw = pullFromVault('payment_config.json');
$payment_config = $payment_config_raw ? json_decode($payment_config_raw, true) : [];
$qr_enabled = ($payment_config['qr_ph_enabled'] ?? 'off') === 'on';
$demo_mode = ($payment_config['demo_mode'] ?? 'off') === 'on'; 

if (isset($_POST['demo_inject_coins']) && $demo_mode) {
    if (session_status() == PHP_SESSION_NONE) session_start();
    $_SESSION['buffered_coins'] = (int)$_POST['demo_inject_coins']; 
    $_SESSION['slot_active'] = true; 
    header('Content-Type: application/json');
    echo json_encode(['status' => 'success']);
    exit; 
}
?>

<?php if($qr_enabled): ?>
<script src="../assets/qrcode.min.js"></script>
<?php endif; ?>

<!-- 📱 MODE SELECT MODAL (Only shows for Vouchers or QR!) -->
<div id="m-mode-select" class="modal">
    <div class="modal-content" style="border-color: var(--theme-color); box-shadow: var(--theme-glow);">
        <h2 id="mode-select-title" style="color: var(--theme-color); font-family: 'Orbitron'; margin-bottom: 5px;">SELECT PURCHASE TYPE</h2>
        <p id="mode-select-desc" style="font-size: 0.9rem; color: #aaa; margin-bottom: 20px;">Choose physical coin deposit or digital QR Ph payment.</p>
        
        <div id="mode-buttons-container">
            <?php $button_section = 'coin_mode_select'; include 'buttons.php'; ?>
        </div>

        <div id="physical-btn-container" style="display:none; margin-bottom: 15px;">
            <button type="button" class="btn" style="width: 100%; background: #222; color: #fff; border: 1px solid #555; font-weight: bold; font-family: 'Orbitron'; padding: 15px;" onclick="proceedToPhysical()">
                🪙 INSERT COIN TO PAY
            </button>
        </div>

        <?php if($qr_enabled): ?>
        <div style="margin: 15px 0;">
            <div style="width: 100%; height: 1px; background: #333; margin-bottom: 15px;"></div>
            <button type="button" class="btn" style="width: 100%; background: #0052cc; color: #fff; border: 1px solid #00f3ff; font-weight: bold; box-shadow: 0 0 10px rgba(0,243,255,0.4); padding: 15px;" onclick="openQRPay('wifi')">
                💳 PAY VIA GCASH / MAYA (QR PH)
            </button>
        </div>
        <?php endif; ?>

        <?php $button_section = 'modal_cancel'; include 'buttons.php'; ?>
    </div>
</div>

<!-- 💳 UNIVERSAL E-WALLET QR PAYMENT MODAL -->
<?php if($qr_enabled): ?>
<div id="m-qr-pay" class="modal">
    <div class="modal-content" style="border-color: #00f3ff; box-shadow: 0 0 20px rgba(0,243,255,0.4);">
        <h2 style="color: #00f3ff; font-family: 'Orbitron'; margin-top: 0; display: flex; align-items: center; justify-content: center; gap: 10px;">
            <span style="font-size: 1.5rem;">📱</span> <span id="qr-modal-title">DIGITAL PAYMENT</span>
        </h2>
        
        <div id="qr-step-1">
            <p style="font-size: 0.9rem; color: #aaa; margin-bottom: 15px;" id="qr-modal-desc">Enter the exact amount you want to buy.</p>
            
            <div id="qr-wifi-options" style="display: none; gap: 10px; margin-bottom: 15px;">
                <select id="qr-opt-mode" style="width: 50%; padding: 10px; background: #111; color: #fff; border: 1px solid #444; font-family: 'Orbitron'; font-weight: bold;">
                    <option value="Time">BUY TIME LIMIT</option>
                </select>
                <select id="qr-opt-tier" style="width: 50%; padding: 10px; background: #111; color: var(--vip); border: 1px solid #444; font-family: 'Orbitron'; font-weight: bold;">
                    <option value="Regular">REGULAR TIER</option>
                    <option value="Gaming">GAMING TIER</option>
                </select>
            </div>

            <div style="display: flex; justify-content: center; align-items: center; gap: 10px; margin-bottom: 20px;">
                <span style="color: var(--success); font-size: 2rem; font-weight: bold;">₱</span>
                <input type="number" id="qr-input-amount" oninput="calculateQRFee()" placeholder="0.00" style="width: 60%; background: #000; color: var(--success); border: 2px solid var(--success); padding: 10px; font-size: 2rem; text-align: center; font-weight: bold; font-family: 'Source Code Pro';">
            </div>

            <div style="background: rgba(255,255,255,0.05); padding: 15px; border-radius: 5px; margin-bottom: 20px; text-align: left;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                    <span style="color: #ccc;">Base Amount:</span>
                    <span style="color: #fff; font-weight: bold;" id="qr-display-base">₱0.00</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                    <span style="color: var(--warning);">Convenience Fee:</span>
                    <span style="color: var(--warning); font-weight: bold;" id="qr-display-fee">₱0.00</span>
                </div>
                <div style="border-bottom: 1px dashed #444; margin: 10px 0;"></div>
                <div style="display: flex; justify-content: space-between; font-size: 1.2rem;">
                    <span style="color: #00f3ff; font-family: 'Orbitron';">TOTAL TO PAY:</span>
                    <span style="color: #00f3ff; font-weight: bold;" id="qr-display-total">₱0.00</span>
                </div>
            </div>

            <button type="button" class="btn btn-success" style="width: 100%; font-size: 1.1rem; padding: 15px;" onclick="generateCustomerQR()">
                GENERATE GCASH / MAYA QR
            </button>
            <button type="button" class="btn outline" style="width: 100%; margin-top: 10px; border-color: #555; color: #888;" onclick="closeM('m-qr-pay')">CANCEL</button>
        </div>

        <div id="qr-step-2" style="display: none;">
            <p style="color: var(--warning); font-size: 0.85rem; margin-bottom: 10px;">Scan this code using GCash, Maya, or any Banking App. <br><strong>Pay exactly <span id="qr-exact-total"></span></strong></p>
            
            <div style="background: #fff; display: inline-block; padding: 15px; border-radius: 10px; margin-bottom: 15px;">
                <div id="customer-qr-output"></div>
            </div>
            
            <button type="button" class="btn btn-success" style="width: 100%; font-size: 1.1rem; padding: 15px; box-shadow: 0 0 15px rgba(16,185,129,0.5);" onclick="verifyQRPayment()">
                ✅ I HAVE PAID
            </button>
            
            <?php if($demo_mode): ?>
            <button type="button" class="btn" style="width: 100%; margin-top: 10px; background: #ff0055; color: #fff; font-weight: bold; border: none; padding: 15px; box-shadow: 0 0 15px rgba(255,0,85,0.5);" onclick="executeDemoPayment()">
                🧪 SIMULATE SUCCESSFUL PAYMENT
            </button>
            <?php endif; ?>

            <button type="button" class="btn outline" style="width: 100%; margin-top: 10px; border-color: #555; color: #888;" onclick="resetQRModal()">GO BACK</button>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- 🪙 PHYSICAL COIN SLOT MODAL -->
<div id="m-coin" class="modal"><div class="modal-content" style="transition: border-color 0.3s, box-shadow 0.3s;">
    <h3 id="c-status" style="margin-bottom: 10px; transition: color 0.3s;">DEPOSITING...</h3>
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; border-bottom: 1px dashed #333; padding-bottom: 10px;">
        <div id="c-tier-tabs-wrapper" style="display: flex; gap: 5px;">
            <?php $button_section = 'coin_tier_tabs'; include 'buttons.php'; ?>
        </div>
        <div id="c-mode-badge" style="font-family: 'Orbitron'; font-size: 0.9rem; color: #fff; background: #222; padding: 5px 10px; border-radius: 4px; border: 1px solid #444;">
            TIME MODE
        </div>
    </div>

    <div class="coin-counter">₱<span id="c-val">0</span></div>
    
    <div id="c-calc-container" style="font-size: 1.8rem; color: #fff; font-family: 'Orbitron'; margin-bottom: 15px; text-shadow: 0 0 10px #fff; font-weight: bold;">
        <span id="c-icon">⏳</span> <span id="c-calc-display">00:00</span>
    </div>

    <div style="width: 100%; height: 6px; background: rgba(255,255,255,0.1); margin-bottom: 5px; border-radius: 3px; overflow: hidden;">
        <div id="c-gauge" style="width: 100%; height: 100%; background: var(--success); transition: width 1s linear, background-color 0.3s;"></div>
    </div>
    <p id="c-timer" style="color: var(--danger); font-family: 'Orbitron'; margin-top: 0; font-size: 0.9rem;">SIGNAL LOST IN: 30s</p>
    
    <form id="c-form" method="POST">
        <input type="hidden" name="action" id="c-action" value="insert_coin">
        <input type="hidden" name="coins" id="c-input" value="0">
        <input type="hidden" name="tier" id="c-tier" value="Regular">
        <input type="hidden" name="mode" id="c-mode" value="Time">
        <input type="hidden" name="coin_history" id="c-history" value="">
        <?php $button_section = 'coin_dynamic_submit'; include 'buttons.php'; ?>
    </form>

    <div id="m-rates-display" style="margin-top: 15px; text-align: left; background: rgba(0,0,0,0.4); padding: 10px; border: 1px solid var(--theme-color); transition: border-color 0.3s; max-height: 150px; overflow-y: auto;">
    </div>
</div></div>

<!-- ⚠️ PENDING CHOICE MODAL -->
<div id="m-pending-choice" class="modal">
    <div class="modal-content" style="border-color: var(--success); box-shadow: 0 0 20px rgba(16, 185, 129, 0.4);">
        <h2 style="color: var(--success); font-family: 'Orbitron'; margin-top: 0;">🟢 COINS RECOVERED!</h2>
        <p style="font-size: 1.1rem; color: #fff; margin-bottom: 5px;">We found <strong id="pending-amt" style="color: var(--success); font-size: 1.5rem; text-shadow: 0 0 10px var(--success);">₱0</strong> from your previous session.</p>
        <p style="font-size: 0.9rem; color: #aaa; margin-bottom: 25px; line-height: 1.4;">Would you like to resume and use these coins, or discard them?</p>
        
        <div style="display: flex; flex-direction: column; gap: 10px;">
            <button type="button" class="btn btn-success" style="padding: 12px; font-size: 1.1rem; font-weight: bold; font-family: 'Orbitron';" onclick="handlePendingChoice('process')">RESUME & USE COINS</button>
            <button type="button" class="btn btn-danger" style="padding: 10px; font-size: 0.9rem;" onclick="handlePendingChoice('discard')">DISCARD COINS</button>
        </div>
    </div>
</div>

<script>
    var cTotal = 0;
    var lockT = null;
    var pollT = null;
    var slotAction = 'insert_coin'; 
    var isSlotOpening = false;
    var coinHistoryArray = []; 
    var pendingCoins = 0; 
    var currentQRTransactionType = 'wifi';
    var paymentConfig = <?php echo json_encode($payment_config); ?>;

    window.currentPurchaseMode = 'Time'; 

    <?php if($qr_enabled): ?>
    function openQRPay(type = 'wifi') {
        currentQRTransactionType = type;
        var modeSelect = document.getElementById('m-mode-select');
        if (modeSelect) modeSelect.style.display = 'none';
        
        var titleEl = document.getElementById('qr-modal-title');
        var descEl = document.getElementById('qr-modal-desc');
        var wifiOptions = document.getElementById('qr-wifi-options');

        var isStatusPage = window.location.pathname.includes('status') || window.location.pathname.includes('expired');

        if (titleEl) titleEl.innerText = "WIFI DIGITAL PAYMENT";
        
        if (isStatusPage) {
            var activeT = typeof viewTier !== 'undefined' ? viewTier : (typeof activeTier !== 'undefined' ? activeTier : 'Regular');
            if (descEl) descEl.innerHTML = `Extending <span style="color:var(--success); font-weight:bold;">TIME</span> for <span style="color:var(--vip); font-weight:bold;">${activeT.toUpperCase()} TIER</span>.`;
            if (wifiOptions) wifiOptions.style.display = 'none'; 
            if (document.getElementById('qr-opt-tier')) document.getElementById('qr-opt-tier').value = activeT;
        } else {
            if (descEl) descEl.innerText = "Enter the amount of Wi-Fi balance you want to buy.";
            if (wifiOptions) wifiOptions.style.display = 'flex'; 
        }

        resetQRModal();
        document.getElementById('m-qr-pay').style.display = 'block';
    }

    function resetQRModal() {
        document.getElementById('qr-step-1').style.display = 'block';
        document.getElementById('qr-step-2').style.display = 'none';
        document.getElementById('qr-input-amount').value = '';
        document.getElementById('qr-display-base').innerText = '₱0.00';
        document.getElementById('qr-display-fee').innerText = '₱0.00';
        document.getElementById('qr-display-total').innerText = '₱0.00';
    }

    function calculateQRFee() {
        var baseAmt = parseFloat(document.getElementById('qr-input-amount').value);
        if (isNaN(baseAmt) || baseAmt <= 0) {
            document.getElementById('qr-display-base').innerText = '₱0.00';
            document.getElementById('qr-display-fee').innerText = '₱0.00';
            document.getElementById('qr-display-total').innerText = '₱0.00';
            return;
        }
        var fee = parseFloat(paymentConfig.convenience_fee) || 0;
        var total = baseAmt + fee;
        document.getElementById('qr-display-base').innerText = '₱' + baseAmt.toFixed(2);
        document.getElementById('qr-display-fee').innerText = '₱' + fee.toFixed(2);
        document.getElementById('qr-display-total').innerText = '₱' + total.toFixed(2);
    }

    function crc16(str) {
        var crc = 0xFFFF;
        for (var c = 0; c < str.length; c++) {
            crc ^= str.charCodeAt(c) << 8;
            for (var i = 0; i < 8; i++) {
                if (crc & 0x8000) crc = (crc << 1) ^ 0x1021;
                else crc = crc << 1;
            }
        }
        return (crc & 0xFFFF).toString(16).toUpperCase().padStart(4, '0');
    }

    function generateCustomerQR() {
        var totalStr = document.getElementById('qr-display-total').innerText.replace('₱', '');
        var totalAmt = parseFloat(totalStr);
        if (isNaN(totalAmt) || totalAmt <= 0) { alert("Please enter a valid amount."); return; }
        var amtStr = totalAmt.toFixed(2);

        var basePayload = paymentConfig.qr_base_payload;
        var merchantName = paymentConfig.qr_merchant_name_wifi || "ANONIMOS Piso WiFi";

        if (!basePayload) { alert("System Error: No QR Payload Configured."); return; }

        var i = 0; var newPayload = "";
        while (i < basePayload.length) {
            var tag = basePayload.substring(i, i + 2);
            if (tag === "63") break; 
            var lenStr = basePayload.substring(i + 2, i + 4);
            var len = parseInt(lenStr, 10);
            if (isNaN(len)) break; 
            
            var val = basePayload.substring(i + 4, i + 4 + len);
            if (tag === "54") { } 
            else if (tag === "59" && merchantName !== "") {
                var newLen = merchantName.length.toString().padStart(2, '0');
                newPayload += tag + newLen + merchantName;
            } else {
                newPayload += tag + lenStr + val;
            }
            i += 4 + len;
        }

        var amtLen = amtStr.length.toString().padStart(2, '0');
        newPayload += "54" + amtLen + amtStr + "6304";
        var finalCrc = crc16(newPayload);
        var dynamicQrString = newPayload + finalCrc;

        document.getElementById('qr-step-1').style.display = 'none';
        document.getElementById('qr-step-2').style.display = 'block';
        document.getElementById('qr-exact-total').innerText = '₱' + amtStr;

        var outputDiv = document.getElementById('customer-qr-output');
        outputDiv.innerHTML = ""; 

        new QRCode(outputDiv, {
            text: dynamicQrString, width: 220, height: 220, colorDark : "#000000", colorLight : "#ffffff", correctLevel : QRCode.CorrectLevel.M
        });
    }

    function verifyQRPayment() { alert("Verification Engine listening for SMS payment confirmation..."); }

    async function executeDemoPayment() {
        var baseAmt = parseFloat(document.getElementById('qr-input-amount').value);
        if(isNaN(baseAmt) || baseAmt <= 0) return;

        var isStatusPage = window.location.pathname.includes('status') || window.location.pathname.includes('expired');
        var finalTier = 'Regular';

        if (isStatusPage) {
            finalTier = typeof viewTier !== 'undefined' ? viewTier : (typeof activeTier !== 'undefined' ? activeTier : 'Regular');
        } else {
            finalTier = document.getElementById('qr-opt-tier') ? document.getElementById('qr-opt-tier').value : 'Regular';
        }

        var submitAction = slotAction ? slotAction : (isStatusPage ? 'add_coin' : 'insert_coin');

        document.getElementById('qr-step-2').innerHTML = `<h3 style="color:var(--success); font-family:'Orbitron';">🧪 DEMO IN PROGRESS</h3><p style="color:#aaa;">Bypassing Anti-Cheat Security...</p>`;

        try {
            var fdHack = new FormData(); fdHack.append('demo_inject_coins', baseAmt);
            await fetch(window.location.pathname, { method: 'POST', body: fdHack });

            document.getElementById('c-input').value = baseAmt;
            document.getElementById('c-history').value = baseAmt;
            document.getElementById('c-mode').value = 'Time';
            document.getElementById('c-tier').value = finalTier;
            document.getElementById('c-action').value = submitAction;
            cTotal = baseAmt; 

            document.getElementById('qr-step-2').innerHTML = `<h3 style="color:var(--success); font-family:'Orbitron';">✅ SYSTEM OVERRIDDEN!</h3><p style="color:#aaa;">Processing Payment for ${finalTier.toUpperCase()}...</p>`;
            setTimeout(() => { closeM('m-qr-pay'); stopSlot(); }, 1000);
        } catch (e) { alert("Demo simulation failed."); }
    }
    <?php endif; ?>

    // 🔥 INSTANT COIN SLOT BYPASS ENGINE 🔥
    function openSlot(actionType) {
        if (isSlotOpening) return; 
        slotAction = actionType; 

        <?php if($qr_enabled): ?>
            document.getElementById('mode-select-title').innerText = "PAYMENT METHOD";
            document.getElementById('mode-select-desc').innerText = "Choose physical coin deposit or digital QR payment.";
            document.getElementById('mode-buttons-container').style.display = 'none'; // Hide Hacker button if present
            document.getElementById('physical-btn-container').style.display = 'block';
            document.getElementById('m-mode-select').style.display = 'flex';
        <?php else: ?>
            if (actionType === 'buy_voucher') {
                document.getElementById('mode-select-title').innerText = "BUY HACKER CODE";
                document.getElementById('mode-select-desc').innerText = "Insert coin to buy a time keycode.";
                document.getElementById('mode-buttons-container').style.display = 'block';
                document.getElementById('physical-btn-container').style.display = 'none';
                document.getElementById('m-mode-select').style.display = 'flex';
            } else {
                // INSTANTLY JUMP TO HARDWARE SLOT (Skip Menu)
                confirmMode('Time');
            }
        <?php endif; ?>
    }

    function proceedToPhysical() { confirmMode('Time'); }

    async function confirmMode(selectedMode) {
        document.getElementById('m-mode-select').style.display = 'none';
        isSlotOpening = true;
        currentPurchaseMode = 'Time';
        
        document.getElementById('c-mode').value = 'Time';
        document.getElementById('c-icon').innerText = '⏳';
        
        var cAction = document.getElementById('c-action');
        if (cAction) cAction.value = slotAction; 
        
        var cStatus = document.getElementById('c-status');
        if (cStatus) {
            cStatus.innerHTML = (slotAction === 'buy_voucher') ? 'MINTING VOUCHER...' : 'DEPOSITING COINS...';
        }
        
        setModalTier(typeof currentModalTier !== 'undefined' ? currentModalTier : 'Regular'); 
        
        try {
            const r = await fetch('slot_api.php?action=lock');
            const d = await r.json();
            
            if(d.status === 'success') {
                document.getElementById('m-coin').style.display = 'block';
                
                if(d.msg === 'Session Resumed!') {
                    cTotal = parseInt(d.buffered_coins) || 0;
                    coinHistoryArray = [cTotal]; 
                } else {
                    cTotal = 0; coinHistoryArray = []; 
                }
                
                document.getElementById('c-history').value = coinHistoryArray.join(',');
                document.getElementById('c-val').innerText = cTotal;
                document.getElementById('c-input').value = cTotal;
                updateDisplayCalc(); updateDynamicSubmitButton();
                
                var welcomeAudio = document.getElementById('s-welcome');
                if (welcomeAudio && !welcomeAudio.paused) { welcomeAudio.pause(); }

                var insertAudio = document.getElementById('s-insert');
                if (insertAudio) { insertAudio.volume = 0.5; insertAudio.currentTime = 0; insertAudio.play().catch(e=>{}); }

                startLock(d.expires_in || 30); startPoll();
            } 
            else if (d.status === 'pending_choice') {
                isSlotOpening = false; pendingCoins = parseInt(d.buffered_coins) || 0;
                document.getElementById('pending-amt').innerText = '₱' + pendingCoins;
                document.getElementById('m-pending-choice').style.display = 'flex';
            } else { 
                // 🔥 BEAUTIFUL HARDWARE ERROR POPUP (Fixed Text) 🔥
                var alertBox = document.getElementById('m-alert');
                if(alertBox) {
                    var aTitle = alertBox.querySelector('h2');
                    if(aTitle) { aTitle.innerText = "ERROR DETECTED"; aTitle.style.color = "var(--danger)"; }
                    alertBox.querySelector('.modal-content').style.borderColor = "var(--danger)";
                    document.getElementById('m-alert-txt').innerHTML = "<div style='color:var(--danger); font-weight:bold; font-size:1.2rem; text-transform:uppercase;'>THE COINSLOT IS OFFLINE</div>";
                    alertBox.style.display = 'flex';
                }
                var errAudio = document.getElementById('s-error');
                if (errAudio) { errAudio.currentTime = 0; errAudio.play().catch(e=>{}); }
            }
        } catch (error) { console.error("Network Error:", error); } 
        finally { setTimeout(() => { isSlotOpening = false; }, 2000); }
    }

    function updateDynamicSubmitButton() {
        var btn = document.getElementById('coin-submit-btn');
        if(!btn) return;
        if (cTotal === 0) {
            btn.innerText = "CANCEL"; btn.className = "btn btn-dynamic-cancel"; btn.type = "button"; btn.onclick = stopSlot; 
        } else {
            btn.innerText = "DONE / PROCESS"; btn.className = "btn btn-success btn-dynamic-submit"; btn.type = "submit"; btn.onclick = null; 
        }
    }

    async function handlePendingChoice(choice) {
        document.getElementById('m-pending-choice').style.display = 'none';
        
        if (choice === 'discard') {
            var fd = new FormData(); fd.append('action', 'discard_pending');
            const discardResp = await fetch('slot_api.php', { method: 'POST', body: fd });
            const discardData = await discardResp.json();
            if(discardData.status === 'success') location.reload();
        } else if (choice === 'process') {
            var fd = new FormData(); fd.append('action', 'resume_pending');
            const resumeResp = await fetch('slot_api.php', { method: 'POST', body: fd });
            const resumeData = await resumeResp.json();

            if (resumeData.status === 'success') {
                document.getElementById('m-coin').style.display = 'block';
                cTotal = parseInt(resumeData.recovered_coins) || pendingCoins;
                coinHistoryArray = [cTotal];
                document.getElementById('c-history').value = coinHistoryArray.join(',');
                document.getElementById('c-val').innerText = cTotal;
                document.getElementById('c-input').value = cTotal;
                
                updateDisplayCalc(); updateDynamicSubmitButton();
                
                var insertAudio = document.getElementById('s-insert');
                if (insertAudio) { insertAudio.volume = 0.5; insertAudio.currentTime = 0; insertAudio.play().catch(e=>{}); }
                startLock(30); startPoll();
            } else {
                var alertBox = document.getElementById('m-alert');
                if(alertBox) {
                    var aTitle = alertBox.querySelector('h2');
                    if(aTitle) { aTitle.innerText = "ERROR DETECTED"; aTitle.style.color = "var(--danger)"; }
                    alertBox.querySelector('.modal-content').style.borderColor = "var(--danger)";
                    document.getElementById('m-alert-txt').innerHTML = resumeData.msg || "Failed to resume pending coins.";
                    alertBox.style.display = 'flex';
                }
            }
        }
    }

    function setModalTier(t) {
        var cTierInput = document.getElementById('c-tier');
        if(cTierInput) cTierInput.value = t;
        
        var btnReg = document.getElementById('m-btn-reg');
        var btnGam = document.getElementById('m-btn-gam');
        var rateBox = document.getElementById('m-rates-display');
        var modalContent = document.querySelector('#m-coin .modal-content');
        var statusText = document.getElementById('c-status');

        if(t === 'Gaming') {
            if(btnGam) btnGam.classList.add('active', 'modal-tab-gam');
            if(btnReg) btnReg.classList.remove('active');
            if(rateBox) rateBox.style.borderColor = 'var(--vip)';
            if(modalContent) modalContent.style.borderColor = 'var(--vip)';
            if(modalContent) modalContent.style.boxShadow = '0 0 20px var(--vip)';
            if(statusText) statusText.style.color = 'var(--vip)';
        } else {
            if(btnReg) btnReg.classList.add('active');
            if(btnGam) btnGam.classList.remove('active', 'modal-tab-gam');
            if(rateBox) rateBox.style.borderColor = 'var(--info)';
            if(modalContent) modalContent.style.borderColor = 'var(--theme-color)';
            if(modalContent) modalContent.style.boxShadow = 'var(--theme-glow)';
            if(statusText) statusText.style.color = '#fff';
        }

        var tRates = (typeof ratesData !== 'undefined') ? (ratesData['Time'] ? ratesData['Time'][t] : ratesData[t]) : {};
        if (!tRates) tRates = {};
        
        var html = `<div style="color:${(t==='Gaming')?'var(--vip)':'var(--info)'}; font-family:'Orbitron'; font-size:0.8rem; margin-bottom:5px; transition: color 0.3s;">${t.toUpperCase()} RATES:</div>`;
        for(var price in tRates) {
            var val = parseFloat(tRates[price]);
            var display = '';
            
            if (val >= 1440) { var d = val / 1440; display = (d % 1 === 0 ? d : d.toFixed(1)) + " Days"; } 
            else if (val >= 60) { var h = val / 60; display = (h % 1 === 0 ? h : h.toFixed(1)) + " Hrs"; } 
            else { display = val + " Mins"; }
            
            html += `<div style="display:flex; justify-content:space-between; font-size:0.85rem; padding: 2px 0;"><span style="color:var(--success); font-weight:bold;">₱${price}</span><span style="color:#ccc;">${display}</span></div>`;
        }
        if(rateBox) rateBox.innerHTML = html;
        window._tempTierForCalc = t; updateDisplayCalc(); 
    }

    function updateDisplayCalc() {
        var activeCalcTier = window._tempTierForCalc || (typeof currentModalTier !== 'undefined' ? currentModalTier : 'Regular');
        var tRates = (typeof ratesData !== 'undefined') ? (ratesData['Time'] ? ratesData['Time'][activeCalcTier] : ratesData[activeCalcTier]) : {};
        if (!tRates) tRates = {};
        
        var denoms = Object.keys(tRates).map(Number).sort((a,b) => b-a);
        var totalVal = 0; var rem = cTotal;
        
        for(var d of denoms) {
            if (d <= 0) continue;
            var count = Math.floor(rem / d);
            if (count > 0) { totalVal += count * parseFloat(tRates[d]); rem -= count * d; }
        }
        
        var secs = totalVal * 60;
        var d = Math.floor(secs / 86400); var h = Math.floor((secs % 86400) / 3600); var m = Math.floor((secs % 3600) / 60); var s = Math.floor(secs % 60);
        
        var displayStr = "";
        if (totalVal === 0) { displayStr = "00:00"; } 
        else if (d > 0) { displayStr = `${d.toString().padStart(2,'0')}D:${h.toString().padStart(2,'0')}H:${m.toString().padStart(2,'0')}M:${s.toString().padStart(2,'0')}S`; } 
        else if (h > 0) { displayStr = `${h.toString().padStart(2,'0')}H:${m.toString().padStart(2,'0')}M:${s.toString().padStart(2,'0')}S`; } 
        else if (m > 0) { displayStr = `${m.toString().padStart(2,'0')}M:${s.toString().padStart(2,'0')}S`; } 
        else { displayStr = `${s.toString().padStart(2,'0')}S`; }
        
        document.getElementById('c-calc-display').innerText = displayStr;
    }

    function startLock(s) {
        clearInterval(lockT);
        var gauge = document.getElementById('c-gauge');
        lockT = setInterval(() => {
            s--; 
            document.getElementById('c-timer').innerText = `SIGNAL LOST IN: ${s}s`;
            var pct = (s / 30) * 100;
            gauge.style.width = Math.max(0, pct) + '%';
            if (s <= 10) { gauge.style.background = 'var(--danger)'; } 
            else { gauge.style.background = 'var(--success)'; }
            if(s <= 0) stopSlot();
        }, 1000);
    }

    function startPoll() {
        clearInterval(pollT);
        pollT = setInterval(async () => {
            const r = await fetch('slot_api.php?action=check');
            const d = await r.json();
            
            if(d.status === 'success' && parseInt(d.coins) > cTotal) {
                var newlyInserted = parseInt(d.coins) - cTotal;
                coinHistoryArray.push(newlyInserted);
                document.getElementById('c-history').value = coinHistoryArray.join(',');

                cTotal = parseInt(d.coins); 
                document.getElementById('c-val').innerText = cTotal;
                document.getElementById('c-input').value = cTotal;
                updateDisplayCalc(); updateDynamicSubmitButton();
                
                var coinAudio = document.getElementById('s-coin');
                if (coinAudio) { coinAudio.currentTime = 0; coinAudio.play().catch(e=>{}); }
                startLock(30); 
            }
        }, 1000);
    }

    function stopSlot() {
        clearInterval(lockT); clearInterval(pollT);
        var insertAudio = document.getElementById('s-insert');
        if (insertAudio) { insertAudio.pause(); insertAudio.currentTime = 0; }
        fetch('slot_api.php?action=release');
        if(cTotal > 0) {
            var loadText = (slotAction === 'buy_voucher') ? 'GENERATING KEYCODE...' : 'VERIFYING COIN DEPOSIT...';
            triggerSubmitLoader(null, document.getElementById('c-form'), loadText, false, 's-loading');
        } else {
            closeM('m-coin');
            var errAudio = document.getElementById('s-error');
            if (errAudio) { errAudio.currentTime = 0; errAudio.play().catch(e=>{}); }
            
            var alertBox = document.getElementById('m-alert');
            if(alertBox) {
                var aTitle = alertBox.querySelector('h2');
                if(aTitle) { aTitle.innerText = "ERROR DETECTED"; aTitle.style.color = "var(--danger)"; }
                alertBox.querySelector('.modal-content').style.borderColor = "var(--danger)";
                alertBox.querySelector('.modal-content').style.boxShadow = "0 0 20px rgba(220, 38, 38, 0.4)";
                document.getElementById('m-alert-txt').innerHTML = "<div style='color:var(--theme-color); font-weight:bold; font-size:1.1rem; text-transform:uppercase;'>DEPOSIT TIMEOUT. TRANSACTION CANCELLED.</div>";
                alertBox.style.display = 'flex';
            }
            
            var welcomeAudio = document.getElementById('s-welcome');
            if (welcomeAudio && welcomeAudio.paused) { welcomeAudio.play().catch(e=>{}); }
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        var cForm = document.getElementById('c-form');
        if(cForm) { cForm.addEventListener('submit', function(e) { e.preventDefault(); stopSlot(); }); }
    });

    window.addEventListener('beforeunload', function (e) {
        var mCoin = document.getElementById('m-coin');
        if (mCoin && (mCoin.style.display === 'block' || mCoin.style.display === 'flex') && typeof isSubmitting !== 'undefined' && !isSubmitting) {
            var fd = new FormData(); fd.append('action', 'abandon');
            navigator.sendBeacon('slot_api.php', fd);
        }
    });
</script>