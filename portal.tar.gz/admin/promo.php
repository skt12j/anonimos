<?php
// admin/promo.php - OPENWRT RAM-DISK EDITION
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }

$promo_raw = pullFromVault('promo.json');
if (!$promo_raw) {
    $promo = [
        "status" => "off",
        "message" => "🔥 PROMO: Insert the new 20 PHP coin and get an EXTRA 10 HOURS! Click Here! 🔥",
        "color" => "#ff0055",
        "target_amount" => 20,
        "bonus_minutes" => 600
    ];
    pushToVault('promo.json', json_encode($promo));
} else {
    $promo = json_decode($promo_raw, true);
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $promo['status'] = $_POST['status'];
    $promo['message'] = $_POST['message'];
    $promo['color'] = $_POST['color'];
    $promo['target_amount'] = (int)$_POST['target_amount'];
    $promo['bonus_minutes'] = (int)$_POST['bonus_minutes'];
    
    pushToVault('promo.json', json_encode($promo, JSON_PRETTY_PRINT));
    
    $message = "<div style='color: var(--success); padding: 15px; border: 1px solid var(--success); background: rgba(16,185,129,0.1); margin-bottom: 20px; font-family: \"Orbitron\"; text-shadow: 0 0 5px var(--success);'>✅ PROMO SETTINGS UPDATED SUCCESSFULLY!</div>";
}

require_once 'header.php';
?>

<div class="container">
    <div style="margin-bottom: 30px;">
        <h1 style="color: var(--vip); text-shadow: 0 0 10px var(--vip);">PROMO MANAGER</h1>
        <p style="color: #888; font-family: 'Source Code Pro';">Control the neon portal banner and strict coin acceptor bonuses.</p>
    </div>

    <?php echo $message; ?>

    <div class="card" style="max-width: 650px; border-color: var(--vip); border-left-width: 5px;">
        <form method="POST" style="margin: 0; display: flex; flex-direction: column; gap: 20px;">
            
            <div>
                <label style="color: #ccc; font-family: 'Orbitron'; font-size: 0.9rem; display: block; margin-bottom: 8px;">PROMO STATUS</label>
                <select name="status" style="width: 100%; background: #000; border: 1px solid var(--vip); color: #fff; padding: 15px; font-size: 1.1rem; font-family: 'Rajdhani'; cursor: pointer;">
                    <option value="on" <?php echo $promo['status'] == 'on' ? 'selected' : ''; ?>>🟢 ACTIVE (Display Neon Banner)</option>
                    <option value="off" <?php echo $promo['status'] == 'off' ? 'selected' : ''; ?>>🔴 DISABLED (Hide Banner)</option>
                </select>
            </div>

            <div>
                <label style="color: #ccc; font-family: 'Orbitron'; font-size: 0.9rem; display: block; margin-bottom: 8px;">BANNER NOTIFICATION TEXT</label>
                <input type="text" name="message" value="<?php echo htmlspecialchars($promo['message']); ?>" required style="width: 100%; background: #000; border: 1px solid #444; color: #fff; padding: 15px; font-size: 1.1rem; font-family: 'Rajdhani'; box-sizing: border-box;">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div style="background: rgba(0, 243, 255, 0.05); padding: 15px; border: 1px dashed var(--info);">
                    <label style="color: var(--info); font-family: 'Orbitron'; font-size: 0.8rem; display: block; margin-bottom: 8px;">STRICT TARGET COIN (PHP)</label>
                    <input type="number" name="target_amount" value="<?php echo $promo['target_amount']; ?>" required style="width: 100%; background: #000; border: 1px solid var(--info); color: var(--info); padding: 12px; font-size: 1.5rem; text-align: center; box-sizing: border-box;">
                </div>
                
                <div style="background: rgba(16, 185, 129, 0.05); padding: 15px; border: 1px dashed var(--success);">
                    <label style="color: var(--success); font-family: 'Orbitron'; font-size: 0.8rem; display: block; margin-bottom: 8px;">BONUS REWARD (MINUTES)</label>
                    <input type="number" name="bonus_minutes" value="<?php echo $promo['bonus_minutes']; ?>" required style="width: 100%; background: #000; border: 1px solid var(--success); color: var(--success); padding: 12px; font-size: 1.5rem; text-align: center; box-sizing: border-box;">
                </div>
            </div>
            
            <div>
                <label style="color: #ccc; font-family: 'Orbitron'; font-size: 0.9rem; display: block; margin-bottom: 8px;">NEON GLOW COLOR</label>
                <input type="color" name="color" value="<?php echo $promo['color']; ?>" style="width: 100%; height: 55px; background: #000; border: 1px solid #444; cursor: pointer;">
            </div>

            <button type="submit" class="btn" style="border: 1px solid var(--vip); color: var(--vip); padding: 15px; font-size: 1.2rem; font-weight: bold; background: rgba(176, 38, 255, 0.1); width: 100%; margin-top: 10px;">
                💾 DEPLOY PROMO SETTINGS
            </button>
        </form>
    </div>
</div>
</body>
</html>