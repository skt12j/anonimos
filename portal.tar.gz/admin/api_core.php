<?php
// admin/api_core.php - OPENWRT RAM-DISK EDITION (Time & WISP Only)
require_once '../core.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

// Load the sessions DB
$sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
$current_time = time();

// Read OpenWrt Kernel ARP directly
function getLocalActiveMacs() {
    $connected_macs = [];
    $arp_table = @file('/proc/net/arp');
    if ($arp_table) {
        foreach ($arp_table as $line) {
            $cols = preg_split('/\s+/', $line);
            if (isset($cols[3]) && $cols[3] !== '00:00:00:00:00:00' && $cols[3] !== 'HWaddress') {
                $connected_macs[] = strtolower(trim($cols[3]));
            }
        }
    }
    return $connected_macs;
}

// ==========================================
// 📊 ROUTE 1: MISSION CONTROL STATS
// ==========================================
if ($action === 'stats') {
    $vouchers = json_decode(pullFromVault('vouchers.json'), true) ?: [];
    $logs = json_decode(pullFromVault('logs.json'), true) ?: [];
    $sales_raw = pullFromVault('sales.txt');

    // 1. Calculate Revenue
    $total_sales = is_numeric($sales_raw) ? number_format((float)$sales_raw, 2) : "0.00";

    // 2. Count Active/Passive/Paused Nodes (Time Mode Only)
    $connected_macs = getLocalActiveMacs();

    $nodes = ['active' => 0, 'passive' => 0, 'paused' => 0, 'total' => 0];

    foreach ($sessions as $mac => $data) {
        $status = $data['status'] ?? 'expired';
        $time_left = ($status === 'active') ? max(0, ($data['expires'] ?? 0) - $current_time) : ($data['time_left'] ?? 0);

        if ($time_left > 0) {
            $nodes['total']++;
            if ($status === 'paused') {
                $nodes['paused']++;
            } elseif ($status === 'active') {
                if (in_array(strtolower($mac), $connected_macs)) {
                    $nodes['active']++;
                } else {
                    $nodes['passive']++;
                }
            }
        }
    }

    // 3. Count Vouchers
    $total_vouchers = count($vouchers);
    $used_vouchers = 0;
    foreach ($vouchers as $v) {
        if (($v['status'] ?? '') === 'used') { $used_vouchers++; }
    }

    // 4. Get latest 10 logs
    $recent_logs = array_slice(array_reverse($logs), 0, 10);

    echo json_encode([
        'revenue' => $total_sales,
        'nodes' => $nodes,
        'total_bytes' => 0, // Data mode removed to save router CPU
        'total_vouchers' => $total_vouchers,
        'used_vouchers' => $used_vouchers,
        'logs' => $recent_logs
    ]);
    exit;
}

// ==========================================
// 💀 ROUTE 2: THE CRYPT (ZOMBIES & BANNED)
// ==========================================
if ($action === 'zombies') {
    $blocked = json_decode(pullFromVault('blocked.json'), true) ?: [];

    $response = [
        'zombies' => [],
        'banned' => []
    ];

    $changed = false;
    foreach ($sessions as $mac => $data) {
        $has_pending = isset($data['pending_coins']) && $data['pending_coins'] > 0;
        $status = $data['status'] ?? 'expired';
        $is_expired = false;
        
        if ($status !== 'paused' && $status !== 'expired' && $status !== 'inactive') {
            // Pure Time-Based Depletion
            if (($data['expires'] ?? 0) <= $current_time) {
                $is_expired = true;
                $sessions[$mac]['status'] = 'expired';
                $sessions[$mac]['last_expired_at'] = $current_time;
                fw_drop($mac, $data['ip'] ?? '');
                $changed = true;
            }
        } elseif ($status === 'expired' || $status === 'inactive') {
            $is_expired = true;
        }

        if ($has_pending || $is_expired) {
            $response['zombies'][] = [
                'mac' => $mac,
                'ip' => $data['ip'] ?? '0.0.0.0',
                'status' => $has_pending ? 'pending_recovery' : $status, 
                'buffered_coins' => $has_pending ? $data['pending_coins'] : 0,
                'pending_coins' => $has_pending ? $data['pending_coins'] : 0
            ];
        }
    }

    if ($changed) {
        pushToVault('sessions.json', json_encode($sessions));
    }

    // Shadow Realm (Banned)
    foreach ($blocked as $mac => $info) {
        $response['banned'][] = [
            'mac' => $mac,
            'date' => $info['date_banned'] ?? $info['date'] ?? 'Unknown Date',
            'reason' => $info['reason'] ?? 'Admin Perma-Ban'
        ];
    }

    echo json_encode($response);
    exit;
}

// ==========================================
// 🎟️ ROUTE 3: VOUCHER LEDGER
// ==========================================
if ($action === 'vouchers') {
    $vouchers = json_decode(pullFromVault('vouchers.json'), true) ?: [];
    
    $admin_vouchers = [];
    $user_vouchers = [];
    $used_vouchers = [];

    foreach ($vouchers as $code => $data) {
        $data['code'] = $code; 
        if (($data['status'] ?? '') === 'unused') {
            if (!isset($data['creator_mac']) || $data['creator_mac'] === 'ADMIN' || $data['creator_mac'] === 'ADMIN_SYSTEM') {
                $admin_vouchers[] = $data;
            } else {
                $user_vouchers[] = $data;
            }
        } else {
            $used_vouchers[] = $data;
        }
    }

    $sortFunc = function($a, $b) { 
        $dateA = $a['created_date'] ?? $a['used_date'] ?? 0;
        $dateB = $b['created_date'] ?? $b['used_date'] ?? 0;
        return strtotime($dateB) - strtotime($dateA); 
    };
    
    usort($admin_vouchers, $sortFunc);
    usort($user_vouchers, $sortFunc);
    usort($used_vouchers, $sortFunc);

    echo json_encode([
        'admin' => $admin_vouchers,
        'user' => $user_vouchers,
        'used' => $used_vouchers
    ]);
    exit;
}

// ==========================================
// 📡 ROUTE 4: NETWORK RADAR (USERS)
// ==========================================
if ($action === 'users') {
    $connected_macs = getLocalActiveMacs();
    $response = ['users' => []];

    foreach ($sessions as $mac => $data) {
        $is_connected = in_array(strtolower($mac), $connected_macs);
        $status = $data['status'] ?? 'expired';
        
        $active_time_left = 0;
        if ($status === 'active') {
            $active_time_left = max(0, ($data['expires'] ?? 0) - $current_time);
        } elseif ($status === 'paused') {
            $active_time_left = $data['time_left'] ?? 0;
        }

        $response['users'][] = [
            'mac' => $mac,
            'ip' => $data['ip'] ?? '0.0.0.0',
            'status' => $status,
            'active_mode' => 'Time',
            'is_connected' => $is_connected,
            'time_left' => $active_time_left,
            'pending_coins' => $data['pending_coins'] ?? 0
        ];
    }

    echo json_encode($response);
    exit;
}

// ==========================================
// 💲 ROUTE 5: RATES
// ==========================================
if ($action === 'rates') {
    $rates = json_decode(pullFromVault('rates.json'), true) ?: ['Time' => []];
    echo json_encode($rates);
    exit;
}

// ==========================================
// 📜 ROUTE 6: SYSTEM LOGS
// ==========================================
if ($action === 'logs') {
    $logs = json_decode(pullFromVault('logs.json'), true) ?: [];

    $total_revenue = 0;
    $total_minutes = 0;
    $total_connections = 0;

    foreach ($logs as $log) {
        $total_revenue += (float)($log['revenue'] ?? 0);
        if (preg_match('/Added:\s*(\d+)m/', $log['details'] ?? '', $matches)) {
            $total_minutes += (int)$matches[1];
        }
        
        $event_upper = strtoupper($log['event'] ?? '');
        if (strpos($event_upper, 'CONNECTING') !== false || strpos($event_upper, 'STABLE') !== false || strpos($event_upper, 'CONNECTED') !== false) {
            $total_connections++;
        }
    }

    $logs = array_reverse($logs);

    echo json_encode([
        'total_revenue' => number_format($total_revenue, 2),
        'total_minutes' => $total_minutes,
        'total_connections' => $total_connections,
        'logs' => $logs
    ]);
    exit;
}

echo json_encode(['error' => 'INVALID_API_ROUTE']);
?>