<?php
// admin/bandwidth.php - OPENWRT RAM-DISK EDITION (Lite Mode)
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

$message = '';
$bw_raw = pullFromVault('bandwidth.json');
$bw = json_decode($bw_raw, true) ?: [
    'gaming' => 20, 'regular' => 50, 'ttl' => 1
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bw['gaming'] = max(1, (int)$_POST['gaming']);
    $bw['regular'] = max(1, (int)$_POST['regular']);
    $bw['ttl'] = isset($_POST['ttl']) ? max(1, min(255, (int)$_POST['ttl'])) : 1;
    
    // Save to Vault (Now points to RAM disk via core.php)
    pushToVault('bandwidth.json', json_encode($bw));

    // Restart the OpenWrt Firewall (No sudo needed!)
    exec("/etc/vaultos_core.sh > /dev/null 2>&1");
    
    $message = "<div style='color: var(--success); margin-bottom: 20px; font-weight: bold;'>SUCCESS: NETWORK UPDATED! OpenWrt Firewall restarted!</div>";
}

require_once 'header.php';
?>

<div style="margin-bottom: 30px;">
    <h1 style="color: var(--success); text-shadow: 0 0 10px var(--success);">NETWORK CONTROL</h1>
    <p style="color: #888;">Dynamically adjust network limits and packet lifespan (TTL).</p>
</div>

<?php echo $message; ?>

<div class="card" style="max-width: 500px; border-color: var(--success);">
    <form method="POST" onsubmit="return triggerSubmitLoader(event, this, 'UPDATING ROUTER FIREWALL...', true, 's-loading');">
        
        <!-- VISUAL BADGE FOR LITE MODE -->
        <div style="background: rgba(255, 0, 0, 0.1); border: 1px solid var(--danger); padding: 10px; text-align: center; margin-bottom: 20px;">
            <strong style="color: var(--danger); font-family: 'Orbitron';">🚀 SPEED LIMITS DISABLED</strong>
            <p style="color: #ccc; font-size: 0.8rem; margin: 5px 0 0 0;">(OpenWrt Lite Mode: Bandwidth throttling is bypassed to conserve router memory. Users browse at maximum hardware speed.)</p>
        </div>

        <div style="margin-bottom: 20px; opacity: 0.5;">
            <label style="color: var(--vip); font-family: 'Orbitron'; font-size: 1.2rem; display: block; margin-bottom: 5px;">VIP GAMING SPEED (Mbps)</label>
            <input type="number" name="gaming" min="1" max="1000" value="<?php echo $bw['gaming']; ?>" required style="width: 100%; background: #000; border: 1px solid var(--vip); color: var(--vip); padding: 15px; font-size: 1.5rem; text-align: center;" readonly>
        </div>

        <div style="margin-bottom: 30px; opacity: 0.5;">
            <label style="color: var(--info); font-family: 'Orbitron'; font-size: 1.2rem; display: block; margin-bottom: 5px;">REGULAR SPEED (Mbps)</label>
            <input type="number" name="regular" min="1" max="1000" value="<?php echo $bw['regular']; ?>" required style="width: 100%; background: #000; border: 1px solid var(--info); color: var(--info); padding: 15px; font-size: 1.5rem; text-align: center;" readonly>
        </div>

        <!-- MAIN WIFI TTL (Still active in OpenWrt!) -->
        <div style="margin-bottom: 15px; padding: 15px; border: 1px dashed var(--warning); background: rgba(245, 158, 11, 0.05);">
            <label style="color: var(--warning); font-family: 'Orbitron'; font-size: 1.2rem; display: block; margin-bottom: 5px;">WIFI ANTI-TETHERING (TTL)</label>
            <p style="color: #888; font-size: 0.8rem; margin-top: 0; line-height: 1.4;">
                <strong>TTL = 1:</strong> Blocks Hotspot/Tethering sharing.<br>
                <strong>TTL = 64:</strong> Standard setting (Sharing allowed).
            </p>
            <input type="number" name="ttl" min="1" max="255" value="<?php echo $bw['ttl'] ?? 1; ?>" required style="width: 100%; background: #000; border: 1px solid var(--warning); color: var(--warning); padding: 15px; font-size: 1.5rem; text-align: center;">
        </div>

        <button type="submit" class="btn btn-success" style="padding: 15px; font-size: 1.2rem; width: 100%;">APPLY NETWORK CHANGES</button>
    </form>
</div>

<div id="loader" style="display:none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(3, 6, 12, 0.95); z-index: 9999; flex-direction: column; align-items: center; justify-content: center;">
    <h2 id="l-title" style="color: var(--success); font-size: 2rem; font-family: 'Orbitron';">UPDATING ROUTER FIREWALL...</h2>
</div>

<script>
    function triggerSubmitLoader(event, formElement, titleText) {
        event.preventDefault(); 
        document.getElementById('loader').style.display = 'flex';
        document.getElementById('l-title').innerText = titleText;
        setTimeout(() => { formElement.submit(); }, 500);
    }
</script>