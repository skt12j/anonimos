<?php
// register_esp.php - OPENWRT RAM-DISK EDITION
require_once __DIR__ . '/core.php';

$esp_ip = $_SERVER['REMOTE_ADDR'];
$token = $_GET['token'] ?? '';

// Pull the master key from the SSD
$master_key = pullFromVault('master_key.txt') ?: "111625080052";

if ($token === $master_key) {
    pushToVault('esp_ip.txt', $esp_ip);
    @chmod(DB_DIR . 'esp_ip.txt', 0777); 
    echo "ESP32_SYNC_SUCCESS: " . $esp_ip;
} else {
    http_response_code(403);
    echo "UNAUTHORIZED_HARDWARE";
}
?>