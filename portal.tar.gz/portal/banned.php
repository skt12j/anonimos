<?php
// portal/banned.php - OPENWRT RAM-DISK EDITION (Shadow Realm)
require_once '../core.php';

$client_ip = $_SERVER['REMOTE_ADDR'];
$mac = getClientMac($client_ip); 

$is_banned = false;
$ban_reason = "Suspicious network activity or violation of terms.";

$blocked_file = DB_DIR . 'blocked.json';
if (file_exists($blocked_file)) {
    $blocked = json_decode(file_get_contents($blocked_file), true);
    
    if (isset($blocked[$mac])) {
        $is_banned = true;
        if (isset($blocked[$mac]['reason']) && !empty($blocked[$mac]['reason'])) {
            $ban_reason = $blocked[$mac]['reason'];
        }
    }
}

if (!$is_banned) {
    header("Location: ../portal/");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>ACCESS DENIED | VAULT OS</title>
    <style>
        * { box-sizing: border-box; user-select: none; -webkit-tap-highlight-color: transparent; }
        body { color: #ff0000; font-family: 'Courier New', Courier, monospace; display: flex; flex-direction: column; justify-content: center; align-items: center; min-height: 100vh; margin: 0; overflow: hidden; text-align: center; padding: 20px; animation: alarmFlash 1.5s infinite; }
        @keyframes alarmFlash { 0%, 100% { background-color: #030000; box-shadow: inset 0 0 50px rgba(255,0,0,0.1); } 50% { background-color: #2a0000; box-shadow: inset 0 0 150px rgba(255,0,0,0.4); } }
        body::after { content: ""; position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.25) 50%), linear-gradient(90deg, rgba(255, 0, 0, 0.06), rgba(0, 255, 0, 0.02), rgba(0, 0, 255, 0.06)); z-index: 999; background-size: 100% 4px, 3px 100%; pointer-events: none; }
        .warning-box { width: 100%; max-width: 450px; border: 2px solid #ff0000; background: rgba(0, 0, 0, 0.85); padding: 50px 20px 30px 20px; box-shadow: 0 0 30px rgba(255, 0, 0, 0.4), inset 0 0 20px rgba(255, 0, 0, 0.2); position: relative; z-index: 10; margin-top: 40px; border-radius: 4px; }
        .warning-icon { font-size: 6rem; line-height: 1; position: absolute; top: -45px; left: 50%; transform: translateX(-50%); text-shadow: 0 0 40px #ff0000; background: #030000; border-radius: 50%; padding: 0 15px; }
        .blinking-text { font-family: 'Impact', 'Arial Black', sans-serif; font-size: 2.2rem; font-weight: 900; text-shadow: 0 0 15px #ff0000; animation: blinker 1s step-start infinite; margin-bottom: 15px; letter-spacing: 2px; }
        @keyframes blinker { 50% { opacity: 0; } }
        .message { color: #ccc; font-size: 1rem; line-height: 1.5; margin-bottom: 20px; padding: 0 10px; }
        .reason-box { background: rgba(255, 0, 0, 0.1); border: 1px dashed #ff4444; color: #ffaa00; padding: 15px; font-weight: bold; margin-bottom: 25px; font-size: 0.9rem; text-transform: uppercase; word-wrap: break-word; }
        .mac-display { font-family: 'Impact', 'Arial Black', sans-serif; color: #fff; background: #ff0000; display: inline-block; padding: 8px 15px; font-size: 1.2rem; letter-spacing: 3px; border-radius: 2px; box-shadow: 0 0 15px rgba(255,0,0,0.5); }
        .footer { color: #555; font-size: 0.8rem; position: absolute; bottom: 20px; width: 100%; text-align: center; z-index: 10; }
        @media (max-width: 350px) { .blinking-text { font-size: 1.8rem; } .mac-display { font-size: 1rem; } }
    </style>
</head>
<body>
    <audio id="s-denied" src="../assets/denied.mp3"></audio>
    <audio id="s-error" src="../assets/error.mp3" loop></audio>

    <div class="warning-box">
        <div class="warning-icon">&#9888;</div>
        <div class="blinking-text">RESTRICTED ZONE</div>
        <div class="message">Your hardware signature has been <strong>PERMANENTLY BLACKLISTED</strong> from ANONIMO'S PISO WIFI.</div>
        <div class="reason-box">> LOG REASON: <?php echo htmlspecialchars($ban_reason); ?></div>
        <div style="color: #888; font-size: 0.8rem; margin-bottom: 8px; font-weight: bold;">TARGET HARDWARE MAC:</div>
        <div class="mac-display"><?php echo $mac; ?></div>
    </div>
    
    <div class="footer">VAULT OS SECURITY PROTOCOL | NODE LOCKED</div>

    <script>
        document.addEventListener('click', () => {
            let deniedAudio = document.getElementById('s-denied');
            let errorAudio = document.getElementById('s-error');
            if (deniedAudio && deniedAudio.paused) {
                deniedAudio.volume = 1.0; deniedAudio.play().catch(e=>{});
                setTimeout(() => { if (errorAudio) { errorAudio.volume = 0.5; errorAudio.play().catch(e=>{}); } }, 1000); 
            }
        }, {once: true});
    </script>
</body>
</html>