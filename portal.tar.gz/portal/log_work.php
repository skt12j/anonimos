<?php
// portal/log_work.php - OPENWRT RAM-DISK EDITION
// Requires $log_mode, $client_mac, and $client_ip to be set before inclusion.
if (!isset($log_mode)) { $log_mode = 'lobby'; }

// 🔥 FIXED: Translate 'status' into connected/paused based on user state
if ($log_mode === 'status') {
    global $user_data;
    $log_mode = (isset($user_data['status']) && $user_data['status'] === 'active') ? 'connected' : 'paused';
}

$disp_mac = isset($client_mac) ? $client_mac : 'UNKNOWN_MAC';
$disp_ip = isset($client_ip) ? $client_ip : 'UNKNOWN_IP';
?>

<style>
    #sys-log-container::-webkit-scrollbar { width: 4px; }
    #sys-log-container::-webkit-scrollbar-track { background: rgba(0, 0, 0, 0.5); }
    #sys-log-container::-webkit-scrollbar-thumb { background: var(--theme-color, #00f3ff); border-radius: 4px; }
    
    .cursor-blink { display: inline-block; width: 8px; height: 15px; background-color: var(--theme-color, #00f3ff); animation: blink 1s step-end infinite; vertical-align: middle; margin-left: 2px; margin-top: -2px; }
    @keyframes blink { 50% { opacity: 0; } }

    .terminal-interactive {
        max-height: 120px; overflow-y: auto; text-align: left; padding: 15px; margin-bottom: 20px; 
        font-family: 'Source Code Pro', monospace; font-size: 0.85rem;
        background: rgba(0,0,0,0.6);
        border: 1px dashed var(--theme-color);
        transition: border-color 0.3s, box-shadow 0.3s;
        cursor: crosshair;
    }
    .terminal-interactive:hover {
        box-shadow: inset 0 0 15px rgba(255,255,255,0.05);
    }
</style>

<div class="terminal-log terminal-interactive" id="sys-log-container">
    <span id="sys-log-text"></span><span class="cursor-blink" id="sys-cursor"></span>
</div>

<script>
    window.addEventListener('DOMContentLoaded', () => {
        const sysLogText = document.getElementById('sys-log-text');
        const sysLogContainer = document.getElementById('sys-log-container');
        const sysCursor = document.getElementById('sys-cursor');
        if (!sysLogText || !sysLogContainer) return; 
        
        let mode = "<?php echo htmlspecialchars($log_mode, ENT_QUOTES, 'UTF-8'); ?>";
        let mac = "<?php echo htmlspecialchars($disp_mac, ENT_QUOTES, 'UTF-8'); ?>";
        let ip = "<?php echo htmlspecialchars($disp_ip, ENT_QUOTES, 'UTF-8'); ?>";
        let date = new Date().toLocaleString();
        
        if (mode === 'connected') { 
            sysCursor.style.backgroundColor = 'var(--success)';
            sysLogContainer.style.borderColor = 'var(--success)';
        } else if (mode === 'paused') { 
            sysCursor.style.backgroundColor = 'var(--warning)';
            sysLogContainer.style.borderColor = 'var(--warning)';
        } else { 
            sysCursor.style.backgroundColor = 'var(--danger)';
            sysLogContainer.style.borderColor = 'var(--danger)';
        }

        let bootLines = []; 
        
        if (mode === 'connected') { 
            bootLines = [
                `> TARGET_NODE: ${mac} [${ip}]`,
                "> AUTHENTICATION: SUCCESS", 
                `> LAST LOGIN: ${date}`, 
                "> TIME-BANK ACTIVE", 
                "<span style='color: var(--success);'>> CONNECTED TO INTERNET</span>"
            ]; 
        } else if (mode === 'paused') { 
            bootLines = [
                `> TARGET_NODE: ${mac} [${ip}]`,
                `> SESSION FROZEN: ${date}`, 
                "> FIREWALL: TRAFFIC BLOCKED", 
                "<span style='color: var(--warning);'>> AWAITING RESUME COMMAND...</span>"
            ]; 
        } else if (mode === 'expired') {
            bootLines = [
                `> TARGET_NODE: ${mac} [${ip}]`,
                `> WARNING: ZERO BALANCE DETECTED`, 
                "> UPLINK: SEVERED", 
                "> KERNEL: EXECUTING TIME CUTOFF PROTOCOL", 
                "<span style='color: var(--danger);'>> SESSION TERMINATED.</span>"
            ]; 
        } else if (mode === 'banned') {
            bootLines = [
                `> TARGET_NODE: ${mac} [${ip}]`,
                "<span style='color: var(--danger); font-weight: bold;'>> CRITICAL: ILLICIT ACTIVITY DETECTED</span>", 
                "> KERNEL: INITIATING SHADOW REALM PROTOCOL", 
                "> MAC_ADDRESS: PERMANENTLY BLACKLISTED", 
                "<span style='color: var(--danger);'>> ACCESS PERMANENTLY DENIED.</span>"
            ]; 
        } else {
            bootLines = [
                `> SCANNING HARDWARE: ${mac}`, 
                `> ASSIGNED IP: ${ip}`,
                "> KERNEL: NODE DISCONNECTED", 
                "> FIREWALL: ENFORCING ISOLATION", 
                "<span style='color: var(--danger);'>> AUTHENTICATION REQUIRED.</span>"
            ];
        }

        // 🔥 FIXED: Ping Local Gateway Instead of 1.1.1.1 to bypass Captive Browser blocks 🔥
        async function checkRealPing() {
            const start = performance.now();
            try {
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 2000); 
                
                await fetch('/portal/index.php?pingtest=' + Math.random(), { 
                    method: 'HEAD',
                    cache: 'no-store',
                    signal: controller.signal
                });
                clearTimeout(timeoutId);
                
                const end = performance.now();
                return Math.round(end - start);
            } catch (e) {
                return null; 
            }
        }
        
        let currentLine = 0;
        let isLooping = false;

        async function typeLine() { 
            if (!isLooping) {
                if (currentLine < bootLines.length) { 
                    sysLogText.innerHTML += bootLines[currentLine] + "<br>"; 
                    sysLogContainer.scrollTop = sysLogContainer.scrollHeight; 
                    currentLine++; 
                    setTimeout(typeLine, Math.floor(Math.random() * 300) + 400); 
                } else {
                    isLooping = true;
                    setTimeout(() => {
                        sysLogText.innerHTML += "<br>";
                        typeLine();
                    }, 1500);
                }
            } else {
                let nextLine = "";
                
                if (mode === 'connected') {
                    let roll = Math.random();
                    if (roll > 0.4) {
                        let ping = await checkRealPing();
                        if (ping !== null) {
                            nextLine = `> PING: LOCAL_GATEWAY [<span style='color:var(--success);'>${ping}ms</span>]`;
                        } else {
                            nextLine = `<span style='color:var(--danger);'>> PING: LOCAL_GATEWAY [DESTINATION UNREACHABLE]</span>`;
                        }
                    } else {
                        let actions = ["> ROUTING PACKETS: OK", "> FIREWALL: TRAFFIC ALLOWED"];
                        nextLine = actions[Math.floor(Math.random() * actions.length)];
                    }
                } else if (mode === 'paused') {
                    let actions = ["> KERNEL: NODE IN STANDBY", "> VAULT: DATA SECURED", "> TUNNEL: SEVERED", "> WAITING_FOR_USER_INPUT..."];
                    nextLine = actions[Math.floor(Math.random() * actions.length)];
                } else if (mode === 'expired') {
                    let actions = ["> FIREWALL: PACKETS REJECTED", "> STATUS: LOCKED IN CRYPT", "> KERNEL: WAITING FOR TIME TOP-UP", "> DAEMON_PURGE: PENDING"];
                    nextLine = actions[Math.floor(Math.random() * actions.length)];
                } else if (mode === 'banned') {
                    let actions = ["> FIREWALL: DROP ALL PACKETS", "> STATUS: EXILED TO SHADOW REALM", "> ADMIN_ALERT: LOGGED", "> NO_ESCAPE..."];
                    nextLine = actions[Math.floor(Math.random() * actions.length)];
                } else {
                    let actions = ["> SECURITY_SCAN: PORT 80 [BLOCKED]", "> SECURITY_SCAN: PORT 443 [BLOCKED]", "> GUEST_NET: TRAFFIC DROPPED", "> AWAITING_COIN_DEPOSIT..."];
                    nextLine = actions[Math.floor(Math.random() * actions.length)];
                }

                sysLogText.innerHTML += nextLine + "<br>";
                
                let textArray = sysLogText.innerHTML.split('<br>');
                if (textArray.length > 15) {
                    sysLogText.innerHTML = textArray.slice(textArray.length - 15).join('<br>');
                }
                
                sysLogContainer.scrollTop = sysLogContainer.scrollHeight;
                setTimeout(typeLine, Math.floor(Math.random() * 2000) + 1500);
            }
        }
        
        setTimeout(typeLine, 500);

        sysLogContainer.addEventListener('click', async () => {
            sysLogText.innerHTML += `> MANUAL_DIAGNOSTIC_RUN: ${new Date().toLocaleTimeString()}<br>`;
            sysLogContainer.scrollTop = sysLogContainer.scrollHeight; 
            
            let ping = await checkRealPing();
            if (ping !== null) {
                sysLogText.innerHTML += `<span style="color:var(--theme-color);">> UPLINK TEST: OK [${ping}ms]</span><br>`;
            } else {
                sysLogText.innerHTML += `<span style="color:var(--danger);">> UPLINK TEST: FAILED (OFFLINE)</span><br>`;
            }
            sysLogContainer.scrollTop = sysLogContainer.scrollHeight; 
        });
    });
</script>