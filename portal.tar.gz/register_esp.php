<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  3.0.0   |
    |              on 2026-09-12 02:59:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto tAS1p; LyHUI: echo "\x55\116\101\x55\124\x48\117\x52\x49\x5a\105\x44\137\110\x41\122\104\127\x41\x52\x45"; goto iPa4Y; P1vo4: $NJ5EV = $_GET["\164\157\x6b\x65\156"] ?? ''; goto RYC3R; aEB8s: @chmod(xd0JN . "\145\x73\x70\x5f\x69\x70\x2e\x74\x78\x74", 0777); goto rBjYH; tAS1p: require_once __DIR__ . "\x2f\143\157\162\145\x2e\160\x68\x70"; goto gjb4G; rvfAy: qobCi("\x65\163\x70\x5f\x69\160\56\x74\x78\164", $za4mS); goto aEB8s; iPa4Y: goto LXNBd; goto cPExr; cPExr: jyITy: goto rvfAy; dtWsX: http_response_code(403); goto LyHUI; RYC3R: $unTCM = Gz1QM("\155\141\x73\x74\145\162\137\153\145\171\x2e\164\x78\x74") ?: "\61\61\61\x36\62\x35\x30\x38\60\x30\x35\62"; goto ozMs9; ozMs9: if ($NJ5EV === $unTCM) { goto jyITy; } goto dtWsX; rBjYH: echo "\x45\123\120\x33\x32\137\123\131\x4e\103\x5f\123\125\103\103\105\123\x53\72\x20" . $za4mS; goto kU3aO; gjb4G: $za4mS = $_SERVER["\122\x45\115\x4f\x54\x45\x5f\101\x44\x44\x52"]; goto P1vo4; kU3aO: LXNBd:
