<?php
// portal/status.php - OPENWRT RAM-DISK EDITION (Unified Core + UI)
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }

// 🔥 LITE MODE TOGGLE ENGINE 🔥
if (isset($_GET['mode'])) {
    $new_mode = ($_GET['mode'] === 'lite') ? 'lite' : 'advance';
    setcookie('vault_mode', $new_mode, time() + (86400 * 30), "/"); 
    header("Location: status.php");
    exit;
}
$vault_mode = $_COOKIE['vault_mode'] ?? 'advance';
$is_lite = ($vault_mode === 'lite');

$client_ip = $_SERVER['REMOTE_ADDR'];
$client_mac = getClientMac($client_ip);

// =======================================================
// 👑 PHASE 3: WISP SUBSCRIBER AUTO-ROUTING & INSTANT UNLOCK 👑
// =======================================================
if (isWispSubscriber($client_mac)) {
    if (!isset($_GET['force_lobby'])) {
        // 1. Force the firewall to instantly grant internet!
        exec("nft add element inet pisowifi wisp_macs { $client_mac } 2>/dev/null");
        $safe_ip = escapeshellarg($client_ip);
        exec("conntrack -D -s $safe_ip 2>/dev/null");
        exec("conntrack -D -d $safe_ip 2>/dev/null");
        
        // 2. Route them to their dedicated dashboard
        header("Location: sub_status.php");
        exit;
    }
}

$blocked_file = DB_DIR . 'blocked.json';
if (file_exists($blocked_file)) {
    $blocked = json_decode(file_get_contents($blocked_file), true);
    if (isset($blocked[$client_mac])) { header("Location: /portal/banned.php"); exit; }
}

$sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
$current_time = time();

// 📡 LIVE INTERNET PING CHECK (SERVER-SIDE)
if (isset($_GET['ping_check'])) {
    header('Content-Type: application/json');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    $fp = @fsockopen("1.1.1.1", 53, $errno, $errstr, 1);
    if ($fp) { fclose($fp); echo json_encode(['internet' => true]); } 
    else { echo json_encode(['internet' => false]); }
    exit;
}

// 📡 LIVE AJAX SYNC ENDPOINT
if (isset($_GET['ajax_data'])) {
    header('Content-Type: application/json');
    header('Cache-Control: no-cache, no-store, must-revalidate');

    if (!isset($sessions[$client_mac])) { echo json_encode(['status' => 'expired']); exit; }

    $data = $sessions[$client_mac];
    if ($data['status'] === 'expired') { echo json_encode(['status' => 'expired']); exit; }

    $active_tier = $data['tier'] ?? 'Regular';
    $time_left = max(0, ($data['expires'] ?? 0) - $current_time);

    // If time depleted, automatically freeze the session so daemon picks it up
    if ($time_left <= 0 && $data['status'] === 'active') {
        $bank_other = ($active_tier === 'Regular') ? ($data['bank_Gaming'] ?? 0) : ($data['bank_Regular'] ?? 0);
        if ($bank_other > 0) {
            $sessions[$client_mac]['status'] = 'paused';
            $sessions[$client_mac]['time_left'] = 0;
            $sessions[$client_mac]['last_paused_at'] = $current_time;
            fw_drop($client_mac, $client_ip);
            pushToVault('sessions.json', json_encode($sessions));
            echo json_encode(['status' => 'frozen']); exit;
        } else {
            echo json_encode(['status' => 'expired']); exit;
        }
    }

    if ($data['status'] === 'paused') { echo json_encode(['status' => 'frozen']); exit; }

    $time_reg = ($active_tier === 'Regular') ? $time_left : ($data['bank_Regular'] ?? 0);
    $time_gam = ($active_tier === 'Gaming') ? $time_left : ($data['bank_Gaming'] ?? 0);

    echo json_encode(['status' => 'active', 'tier' => $active_tier, 'time_reg' => $time_reg, 'time_gam' => $time_gam]);
    exit;
}

// 🛑 IF USER IS NOT IN DATABASE -> BOUNCE TO LOBBY
if (!isset($sessions[$client_mac]) || $sessions[$client_mac]['status'] === 'expired') {
    header("Location: index.php");
    exit;
}

$user_data = $sessions[$client_mac];
$active_tier = $user_data['tier'] ?? 'Regular';
$active_time_left = max(0, ($user_data['expires'] ?? 0) - $current_time);
$bank_reg = $user_data['bank_Regular'] ?? 0;
$bank_gam = $user_data['bank_Gaming'] ?? 0;

$error_message = '';
$voucher_conflict = false;

// ⚡ MASTER ACTION HANDLER
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    // 1. TIER SWITCHING
    if ($action === 'switch_tier') {
        $target_tier = $_POST['target_tier'] ?? 'Regular';
        
        if ($target_tier !== $active_tier) {
            $current_bank_key = "bank_" . $active_tier;
            $sessions[$client_mac][$current_bank_key] = $active_time_left;
            
            $target_bank_key = "bank_" . $target_tier;
            $new_time = $sessions[$client_mac][$target_bank_key] ?? 0;
            
            $sessions[$client_mac]['tier'] = $target_tier;
            $sessions[$client_mac]['expires'] = $current_time + $new_time;
            $sessions[$client_mac][$target_bank_key] = 0;
            
            $sessions[$client_mac]['status'] = 'active';
            $sessions[$client_mac]['ignore_late_payload'] = true; 
            unset($sessions[$client_mac]['last_paused_at']);
            
            fw_drop($client_mac, $client_ip);
            fw_allow($client_mac, $client_ip, $target_tier);
            
            pushToVault('sessions.json', json_encode($sessions));
            header("Location: status.php"); exit;
        }
    }

    // 2. PAUSE SESSION (FREEZE)
    elseif ($action === 'pause') {
        if ($user_data['status'] === 'active') {
            $sessions[$client_mac]['status'] = 'paused';
            $sessions[$client_mac]['time_left'] = $active_time_left;
            $sessions[$client_mac]['last_paused_at'] = $current_time;
            
            fw_drop($client_mac, $client_ip);
            pushToVault('sessions.json', json_encode($sessions));
            header("Location: status.php"); exit;
        }
    }

    // 3. RESUME SESSION
    elseif ($action === 'resume' || $action === 'force_connect') {
        if ($user_data['status'] === 'paused') {
            $sessions[$client_mac]['status'] = 'active';
            $sessions[$client_mac]['expires'] = $current_time + ($user_data['time_left'] ?? 0);
            $sessions[$client_mac]['time_left'] = 0;
            unset($sessions[$client_mac]['last_paused_at']);
            
            fw_allow($client_mac, $client_ip, $active_tier);
            pushToVault('sessions.json', json_encode($sessions));
            header("Location: status.php"); exit;
        } elseif ($action === 'force_connect') {
            // Re-sync firewall rules if internet drops
            fw_drop($client_mac, $client_ip);
            fw_allow($client_mac, $client_ip, $active_tier);
            header("Location: status.php"); exit;
        }
    }

    // 4. ADD COINS OR REDEEM VOUCHER
    elseif ($action === 'add_coin' || $action === 'insert_coin' || $action === 'redeem_voucher') {
        $logs = json_decode(pullFromVault('logs.json'), true) ?: [];
        $sales_raw = pullFromVault('sales.txt');
        $total_sales = is_numeric($sales_raw) ? (float)$sales_raw : 0.00;

        $target_tier = $_POST['tier'] ?? $active_tier;
        $val_added = 0; $price = 0; $details = "";

        if ($action === 'redeem_voucher') {
            $code = strtoupper(trim($_POST['voucher']));
            $vouchers = json_decode(pullFromVault('vouchers.json'), true) ?: [];
            
            if (isset($vouchers[$code]) && $vouchers[$code]['status'] === 'unused') {
                $val_added = (float)($vouchers[$code]['value'] ?? $vouchers[$code]['minutes']);
                $price = (float)($vouchers[$code]['price'] ?? 0);
                $target_tier = $vouchers[$code]['tier'] ?? 'Regular';

                $vouchers[$code]['status'] = 'used'; 
                $vouchers[$code]['used_by'] = $client_mac; 
                $vouchers[$code]['used_date'] = date('Y-m-d H:i:s');
                pushToVault('vouchers.json', json_encode($vouchers));
                
                $details = "Code: $code | Added {$val_added}m";
            } else {
                $error_message = "ENCRYPTED KEY INVALID OR CONSUMED.";
            }
        } else {
            $inserted_coins = (int)$_POST['coins'];
            $rates_data = json_decode(pullFromVault('rates.json'), true) ?: [];
            $tier_rates = $rates_data['Time'][$target_tier] ?? [];
            
            $remaining_coins = $inserted_coins; $price = $inserted_coins;
            if(!empty($tier_rates)) {
                $available_denoms = array_keys($tier_rates); rsort($available_denoms, SORT_NUMERIC); 
                foreach ($available_denoms as $denom) {
                    $denom_int = (int)$denom; if ($denom_int <= 0) continue;
                    $count = floor($remaining_coins / $denom_int);
                    if ($count > 0) { $val_added += ($count * (float)$tier_rates[$denom]); $remaining_coins -= ($count * $denom_int); }
                }
            }
            $details = "Inserted ₱$price | Added {$val_added}m";
        }

        if ($val_added > 0) {
            $is_frozen = ($sessions[$client_mac]['status'] === 'paused');
            
            if ($target_tier === $active_tier && !$is_frozen) {
                $sessions[$client_mac]['expires'] += ($val_added * 60);
            } else {
                $bank_key = "bank_" . $target_tier;
                if ($is_frozen && $target_tier === $active_tier) {
                    $sessions[$client_mac]['time_left'] += ($val_added * 60);
                } else {
                    $sessions[$client_mac][$bank_key] += ($val_added * 60);
                }
            }

            $total_sales += $price;
            $event_name = ($action === 'redeem_voucher') ? 'VOUCHER_ACTIVATED' : 'TOP_UP';
            $logs[] = ['date' => date('Y-m-d H:i:s'), 'mac' => $client_mac, 'event' => $event_name, 'tier' => $target_tier, 'details' => $details, 'revenue' => $price];
            
            pushToVault('sessions.json', json_encode($sessions)); 
            pushToVault('logs.json', json_encode($logs)); 
            pushToVault('sales.txt', (string)$total_sales);
            
            header("Location: status.php"); exit;
        } elseif ($action !== 'redeem_voucher') {
            $error_message = "SYSTEM ERROR: No valid rates configured for " . strtoupper($target_tier) . ".";
        }
    }
}

$rates = json_decode(pullFromVault('rates.json'), true) ?: [];
$rates_json = json_encode($rates); 

$time_reg = ($active_tier === 'Regular') ? $active_time_left : $bank_reg;
$time_gam = ($active_tier === 'Gaming') ? $active_time_left : $bank_gam;
if ($user_data['status'] === 'paused') {
    $time_reg = ($active_tier === 'Regular') ? ($user_data['time_left'] ?? 0) : $bank_reg;
    $time_gam = ($active_tier === 'Gaming') ? ($user_data['time_left'] ?? 0) : $bank_gam;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>VAULT OS | PISO WIFI DASHBOARD</title>
    <?php include 'theme.php'; ?>
    <style>
        .result-cursor { display: inline-block; width: 8px; height: 15px; animation: blink 1s step-end infinite; vertical-align: middle; margin-left: 2px; margin-top: -2px; }
        @keyframes blink { 50% { opacity: 0; } }
        
        .offline-disabled { opacity: 0.4 !important; pointer-events: none !important; filter: grayscale(100%); }
        .offline-pulse { animation: offlineBlink 1.5s infinite; }
        @keyframes offlineBlink { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; color: #ff4c4c; } }

        .status-time-box { background: rgba(0,0,0,0.5); border: 1px solid var(--theme-color); padding: 15px; border-radius: 4px; text-align: center; }
        .stb-val { font-size: 2rem; font-family: 'Source Code Pro', monospace; font-weight: bold; color: #fff; margin-top: 5px; }
        .stb-label { font-size: 0.8rem; font-family: 'Orbitron'; color: var(--theme-color); letter-spacing: 1px; }
    </style>

    <?php if ($is_lite): ?>
    <style>
        body { background: #0a0a0a !important; background-image: none !important; }
        * { animation: none !important; transition: none !important; box-shadow: none !important; text-shadow: none !important; }
        .panel, .modal-content, .card { background: #111 !important; border: 1px solid #333 !important; }
        .btn { box-shadow: none !important; border-radius: 4px !important; }
        #particles-js, .glitch, .scanlines { display: none !important; }
    </style>
    <?php endif; ?>
</head>
<body class="<?php echo ($active_tier === 'Gaming') ? 'theme-gaming' : ''; ?>">

    <audio id="s-denied" src="../assets/denied.mp3"></audio>
    <audio id="s-loading" src="../assets/loading.mp3"></audio>
    <audio id="s-welcome" src="../assets/welcome.mp3"></audio>
    <audio id="s-coin" src="../assets/coin.mp3"></audio>
    <audio id="s-insert" src="../assets/insert_coin.mp3" loop></audio>
    <audio id="s-freeze" src="../assets/freeze.mp3"></audio>
    <audio id="s-error" src="../assets/error.mp3"></audio>

    <?php include 'loading.php'; ?>

    <div class="container">
        
        <div style="display: flex; justify-content: flex-end; margin-bottom: 10px;">
            <?php if ($is_lite): ?>
                <button onclick="window.location.href='?mode=advance'" class="btn outline" style="font-size: 0.7rem; padding: 6px 12px; border-color: var(--vip); color: var(--vip); font-family: 'Orbitron'; font-weight: bold;">🚀 ADVANCE MODE</button>
            <?php else: ?>
                <button onclick="window.location.href='?mode=lite'" class="btn outline" style="font-size: 0.7rem; padding: 6px 12px; border-color: var(--success); color: var(--success); font-family: 'Orbitron'; font-weight: bold;">⚡ LITE MODE</button>
            <?php endif; ?>
        </div>

        <div style="margin-bottom: 20px;">
            <?php if(!$is_lite): ?>
                <img src="../assets/logo.png" style="max-width: 120px; filter: drop-shadow(var(--theme-glow)); margin-bottom: 10px;">
            <?php endif; ?>
            <h1 style="font-size: 1.5rem; <?php echo $is_lite ? 'color: var(--theme-color);' : ''; ?>">COMMAND DASHBOARD</h1>
        </div>

        <div class="panel" data-node="<?php echo substr($client_mac, -5); ?>" style="border-top: 4px solid var(--theme-color);">
            
            <?php if ($user_data['status'] === 'paused'): ?>
                <div class="status-badge" style="color: var(--warning); border-color: var(--warning); box-shadow: 0 0 10px rgba(245,158,11,0.2);">
                    ❄️ SESSION FROZEN (PAUSED)
                </div>
            <?php else: ?>
                <div class="status-badge" id="sys-status-label" style="color: var(--success); border-color: var(--success); box-shadow: 0 0 10px rgba(16,185,129,0.2);">
                    ● UPLINK ACTIVE (<?php echo strtoupper($active_tier); ?>)
                </div>
            <?php endif; ?>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 25px 0;">
                <div class="status-time-box" style="border-color: var(--info);">
                    <div class="stb-label" style="color: var(--info);">REGULAR TIME</div>
                    <div class="stb-val" id="disp-reg-time"><?php echo gmdate("H:i:s", $time_reg); ?></div>
                    <?php if ($active_tier !== 'Regular' && $time_reg > 0): ?>
                        <form method="POST" style="margin-top: 10px;" onsubmit="return triggerSubmitLoader(event, this, 'ROUTING TO REGULAR...', false);">
                            <input type="hidden" name="action" value="switch_tier">
                            <input type="hidden" name="target_tier" value="Regular">
                            <button class="btn outline" style="font-size: 0.7rem; padding: 5px; width: 100%; border-color: var(--info); color: var(--info);">ACTIVATE REGULAR</button>
                        </form>
                    <?php endif; ?>
                </div>

                <div class="status-time-box" style="border-color: var(--vip);">
                    <div class="stb-label" style="color: var(--vip);">VIP GAMING TIME</div>
                    <div class="stb-val" id="disp-gam-time"><?php echo gmdate("H:i:s", $time_gam); ?></div>
                    <?php if ($active_tier !== 'Gaming' && $time_gam > 0): ?>
                        <form method="POST" style="margin-top: 10px;" onsubmit="return triggerSubmitLoader(event, this, 'ROUTING TO GAMING...', false);">
                            <input type="hidden" name="action" value="switch_tier">
                            <input type="hidden" name="target_tier" value="Gaming">
                            <button class="btn outline" style="font-size: 0.7rem; padding: 5px; width: 100%; border-color: var(--vip); color: var(--vip);">ACTIVATE GAMING</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <?php 
                $status = ($user_data['status'] === 'active') ? 'connected' : 'paused'; 
                $button_section = 'action_controls'; 
                include 'buttons.php'; 
            ?>

            <?php $log_mode = 'status'; include 'log_work.php'; ?>
        </div>
        
    </div>

    <!-- MODALS -->
    <div id="m-voucher" class="modal"><div class="modal-content" style="border-color: var(--theme-color);">
        <h2 style="color: var(--theme-color); font-family: 'Orbitron';">REDEEM KEYCODE</h2>
        <form method="POST" onsubmit="return triggerSubmitLoader(event, this, 'DECRYPTING KEYCODE...', false);">
            <input type="hidden" name="action" value="redeem_voucher">
            <input type="text" name="voucher" placeholder="XXXXXX" autocomplete="off" required>
            <?php $button_section = 'modal_submit'; include 'buttons.php'; ?>
        </form>
        <?php $button_section = 'modal_cancel'; include 'buttons.php'; ?>
    </div></div>

    <div id="m-alert" class="modal" <?php if($error_message) echo 'style="display:flex;"'; ?>><div class="modal-content" style="border-color: var(--danger);">
        <h2 style="color: var(--danger);">ERROR DETECTED</h2>
        <p id="m-alert-txt" style="font-size: 1.2rem; margin: 20px 0;"><?php echo $error_message; ?></p>
        <?php $button_section = 'modal_ack'; include 'buttons.php'; ?>
    </div></div>

    <?php include 'rates_modal.php'; ?>

    <script>
        var ratesData = <?php echo empty($rates_json) ? '{}' : $rates_json; ?>;
        var currentModalTier = '<?php echo $active_tier; ?>'; 
        var activeTier = '<?php echo $active_tier; ?>';
        var isPaused = <?php echo ($user_data['status'] === 'paused') ? 'true' : 'false'; ?>;
        
        var timeReg = <?php echo $time_reg; ?>;
        var timeGam = <?php echo $time_gam; ?>;

        const MY_LOBBY_TAB_ID = Date.now().toString() + Math.random().toString();
        localStorage.setItem('vault_lobby_tab', MY_LOBBY_TAB_ID);

        window.addEventListener('storage', function(e) {
            if (e.key === 'vault_lobby_tab' && e.newValue !== MY_LOBBY_TAB_ID) {
                lockScreen("SESSION TRANSFERRED", "You opened the Vault Dashboard in a new tab.");
            }
        });

        function lockScreen(title, msg) {
            if(document.getElementById('global-shield')) return;
            let shield = document.createElement('div'); shield.id = 'global-shield';
            shield.style.position = 'fixed'; shield.style.top = '0'; shield.style.left = '0';
            shield.style.width = '100%'; shield.style.height = '100%'; shield.style.background = 'rgba(0,0,0,0.95)';
            shield.style.zIndex = '999999'; shield.style.display = 'flex'; shield.style.flexDirection = 'column';
            shield.style.alignItems = 'center'; shield.style.justifyContent = 'center'; shield.style.backdropFilter = 'blur(5px)';
            shield.innerHTML = `<h2 style="color:var(--danger); font-family:'Orbitron';">${title}</h2><p style="color:#aaa;">${msg}</p>`;
            document.body.appendChild(shield);
        }

        function formatTimeJS(seconds) {
            if (seconds <= 0) return "00:00:00";
            let h = Math.floor(seconds / 3600).toString().padStart(2, '0');
            let m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
            let s = Math.floor(seconds % 60).toString().padStart(2, '0');
            return `${h}:${m}:${s}`;
        }

        function updateDisplay() {
            document.getElementById('disp-reg-time').innerText = formatTimeJS(timeReg);
            document.getElementById('disp-gam-time').innerText = formatTimeJS(timeGam);
        }

        // Live Server Sync
        setInterval(() => {
            fetch('?ajax_data=1&t=' + new Date().getTime())
            .then(r => r.json())
            .then(d => {
                if(d.status === 'expired') window.location.href = 'expired.php';
                else if(d.status === 'frozen' && !isPaused) location.reload();
                else if(d.status === 'active') {
                    timeReg = d.time_reg; timeGam = d.time_gam;
                    if(d.tier !== activeTier) location.reload();
                    updateDisplay();
                }
            }).catch(e=>{});
        }, 5000);

        // Local Countdown
        setInterval(() => {
            if (!isPaused) {
                if (activeTier === 'Regular' && timeReg > 0) timeReg--;
                if (activeTier === 'Gaming' && timeGam > 0) timeGam--;
                if (timeReg <= 0 && activeTier === 'Regular') location.reload();
                if (timeGam <= 0 && activeTier === 'Gaming') location.reload();
            }
            updateDisplay();
        }, 1000);

        function openVoucher() { document.getElementById('m-voucher').style.display = 'flex'; }
        function openRates() { document.getElementById('m-rates').style.display = 'flex'; }
        function closeM(id) { let modal = document.getElementById(id); if (modal) modal.style.display = 'none'; }
        function startHackerCodeBuy() { if (typeof openSlot === 'function') openSlot('buy_voucher'); }

        // Internet Checker
        var isInternetOnline = true;
        var badgeOriginalText = "";
        var badgeOriginalColor = "";
        
        function checkServerInternet() {
            var badge = document.getElementById('sys-status-label');
            if (badge && !badgeOriginalText && !badge.innerText.includes('INTERNET')) {
                badgeOriginalText = badge.innerHTML;
                badgeOriginalColor = badge.style.color;
            }

            fetch('?ping_check=1&t=' + new Date().getTime())
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    isInternetOnline = data.internet;
                    var btns = document.querySelectorAll('.btn, .hud-btn');
                    
                    if (!isInternetOnline) {
                        if (badge) {
                            badge.innerHTML = '● NO INTERNET... PLEASE TRY AGAIN LATER';
                            badge.style.color = 'var(--danger)';
                            badge.classList.add('offline-pulse');
                        }
                        btns.forEach(function(btn) { btn.classList.add('offline-disabled'); });
                    } else {
                        if (badge && badgeOriginalText) {
                            badge.innerHTML = badgeOriginalText;
                            badge.style.color = badgeOriginalColor;
                            badge.classList.remove('offline-pulse');
                        }
                        btns.forEach(function(btn) { btn.classList.remove('offline-disabled'); });
                    }
                }).catch(function(e) {});
            setTimeout(checkServerInternet, 4000);
        }
        setTimeout(checkServerInternet, 1000);

        <?php if($error_message): ?>
            document.getElementById('m-alert').style.display = 'flex';
        <?php endif; ?>
    </script>
    
    <?php include 'coin_core.php'; ?>
    
    <?php if (!$is_lite): ?>
        <?php include 'chat_widget.php'; ?>
    <?php endif; ?>

</body>
</html>