<?php
// portal/chat_widget.php - OPENWRT RAM-DISK EDITION (AJAX Polling Edition)

// 🔥 1. SECURELY LOAD PERMANENT CLIENT NAME FROM SSD DATABASE 🔥
$vc_names_db = json_decode(pullFromVault('chat_names.json'), true) ?: [];
$server_saved_name = $vc_names_db[$client_mac] ?? '';

// 🔥 2. SECURELY PARSE ONLY USED VOUCHERS 🔥
$vc_vouchers_db = json_decode(pullFromVault('vouchers.json'), true) ?: [];
$vc_consumed_codes = [];
foreach ($vc_vouchers_db as $code => $v) {
    if (($v['status'] ?? '') === 'used') {
        $vc_consumed_codes[] = $code;
    }
}
?>
<style>
    /* 🔥 VAULT CHAT WIDGET STYLES 🔥 */
    #vc-widget {
        position: fixed; bottom: 20px; left: 20px; z-index: 9999;
        font-family: 'Rajdhani', sans-serif; display: flex; flex-direction: column; align-items: flex-start; 
    }

    #vc-btn {
        background: var(--theme-color, #00f3ff); color: #000; width: 60px; height: 60px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center; font-size: 1.2rem; font-weight: 900;
        cursor: pointer; box-shadow: 0 0 20px var(--theme-color, #00f3ff); transition: transform 0.2s, box-shadow 0.2s;
        border: 2px solid #000; position: relative; z-index: 10001;
    }
    #vc-btn:hover { transform: scale(1.1); box-shadow: 0 0 30px var(--theme-color, #00f3ff); }
    #vc-btn.unread-pulse { animation: vcPulse 1.5s infinite; }
    @keyframes vcPulse { 0% { box-shadow: 0 0 0 0 rgba(0, 243, 255, 0.7); } 70% { box-shadow: 0 0 0 20px rgba(0, 243, 255, 0); } 100% { box-shadow: 0 0 0 0 rgba(0, 243, 255, 0); } }

    #vc-panel {
        display: none; flex-direction: column; width: 320px; height: 450px; max-width: 90vw; max-height: 70vh; 
        background: rgba(5, 10, 21, 0.95); backdrop-filter: blur(10px); border: 2px solid var(--theme-color, #00f3ff);
        border-radius: 8px; box-shadow: 0 0 30px rgba(0, 0, 0, 0.8), inset 0 0 15px rgba(0, 243, 255, 0.1);
        overflow: hidden; margin-bottom: 15px; position: relative; z-index: 10000; animation: vcSlideUp 0.3s ease-out forwards;
    }
    @keyframes vcSlideUp { from { opacity: 0; transform: scale(0.8) translateY(20px); } to { opacity: 1; transform: scale(1) translateY(0); } }

    #vc-header { background: var(--theme-color, #00f3ff); color: #000; padding: 10px 15px; display: flex; justify-content: space-between; align-items: center; font-family: 'Orbitron', sans-serif; font-weight: 900; flex-shrink: 0; }
    #vc-close { background: none; border: none; color: #000; font-size: 1.2rem; cursor: pointer; font-weight: bold; padding: 5px; z-index: 10002; }

    #vc-stage1 { padding: 30px 20px; text-align: center; display: flex; flex-direction: column; height: 100%; justify-content: center; }
    #vc-stage1 h3 { color: var(--theme-color, #00f3ff); margin-bottom: 10px; font-family: 'Orbitron'; }
    #vc-stage1 p { color: #aaa; font-size: 0.9rem; margin-bottom: 20px; }
    #vc-name-input { letter-spacing: normal !important; text-align: center !important; font-weight: 500 !important; width: 100%; padding: 12px; background: #000; border: 1px solid var(--theme-color, #00f3ff); color: #fff; font-family: 'Rajdhani'; font-size: 1.1rem; border-radius: 4px; margin-bottom: 15px; box-sizing: border-box; }
    
    #vc-stage2 { display: none; flex-direction: column; height: 100%; overflow: hidden; } 
    #vc-messages { flex-grow: 1; padding: 15px; overflow-y: auto; display: flex; flex-direction: column; gap: 10px; background: rgba(0,0,0,0.4); scroll-behavior: smooth; }
    
    .vc-msg { max-width: 85%; padding: 8px 12px; border-radius: 6px; font-size: 0.95rem; line-height: 1.3; position: relative; word-wrap: break-word; }
    .vc-time { font-size: 0.6rem; color: rgba(255,255,255,0.4); position: absolute; bottom: -14px; white-space: nowrap; }
    .vc-msg-admin { align-self: flex-start; background: #1a2a44; border: 1px solid var(--theme-color, #00f3ff); color: #fff; border-bottom-left-radius: 0; margin-bottom: 10px; }
    .vc-msg-admin .vc-time { left: 0; }
    .vc-msg-client { align-self: flex-end; background: var(--theme-color, #00f3ff); color: #000; border-bottom-right-radius: 0; font-weight: 500; margin-bottom: 10px; }
    .vc-msg-client .vc-time { right: 0; text-align: right; }
    
    .vc-system { align-self: center; background: none; color: var(--warning, #f59e0b); font-size: 0.8rem; font-family: 'Source Code Pro'; text-align: center; border: 1px dashed var(--warning, #f59e0b); border-radius: 4px; padding: 5px 10px; margin: 10px 0; }

    #vc-input-area { display: flex; padding: 10px; background: #050a15; border-top: 1px solid #333; gap: 8px; align-items: center; flex-shrink: 0; }
    #vc-input-msg { letter-spacing: normal !important; text-align: left !important; font-weight: 500 !important; margin: 0 !important; flex-grow: 1; background: #000; border: 1px solid #444; color: #fff; padding: 10px; font-family: 'Rajdhani'; font-size: 1rem; border-radius: 4px; box-sizing: border-box; }
    #vc-input-msg:focus { border-color: var(--theme-color, #00f3ff); outline: none; }
    
    .vc-btn-icon { background: none; border: 1px dashed #555; color: #aaa; padding: 8px; cursor: pointer; border-radius: 4px; transition: 0.2s; }
    .vc-btn-icon:hover { border-color: var(--theme-color, #00f3ff); color: var(--theme-color, #00f3ff); }
    #vc-send-btn { background: var(--theme-color, #00f3ff); color: #000; border: none; padding: 0 15px; font-family: 'Orbitron'; font-weight: 900; cursor: pointer; border-radius: 4px; height: 38px; }
    
    #vc-welcome-popup { display: none; position: absolute; bottom: 80px; left: 0px; background: var(--theme-color, #00f3ff); color: #000; padding: 10px 15px; border-radius: 8px; border-bottom-left-radius: 0px; font-weight: 700; font-size: 0.9rem; box-shadow: 0 0 15px var(--theme-color, #00f3ff); white-space: nowrap; z-index: 10000; }
    #vc-welcome-popup.show { animation: popUp 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards; }
    #vc-welcome-popup.hide { animation: popDown 0.3s ease-in forwards; }
    #vc-welcome-popup::after { content: ''; position: absolute; bottom: -10px; left: 0; border-width: 10px 10px 0 0; border-style: solid; border-color: var(--theme-color, #00f3ff) transparent transparent transparent; }
    
    @keyframes popUp { from { opacity: 0; transform: scale(0.5) translateY(20px); } to { opacity: 1; transform: scale(1) translateY(0); } }
    @keyframes popDown { from { opacity: 1; transform: scale(1) translateY(0); } to { opacity: 0; transform: scale(0.5) translateY(20px); } }

    .vc-voucher-btn { display: inline-block; background: rgba(16, 185, 129, 0.1); border: 1px solid var(--success, #10b981); color: var(--success, #10b981); padding: 5px 10px; margin-top: 5px; border-radius: 4px; font-family: 'Orbitron', sans-serif; font-size: 0.8rem; font-weight: bold; cursor: pointer; transition: 0.2s; }
    .vc-voucher-btn:hover { background: var(--success, #10b981); color: #000; box-shadow: 0 0 10px var(--success, #10b981); }
    .vc-voucher-used { display: inline-block; background: rgba(255, 76, 76, 0.1); border: 1px solid var(--danger, #ff4c4c); color: var(--danger, #ff4c4c); padding: 5px 10px; margin-top: 5px; border-radius: 4px; font-family: 'Orbitron', sans-serif; font-size: 0.8rem; font-weight: bold; text-decoration: line-through; opacity: 0.6; cursor: not-allowed; }
</style>

<audio id="vc-ting" src="../assets/ting.mp3"></audio>

<div id="vc-widget">
    <div id="vc-panel">
        <div id="vc-header">
            <span>🛡️ VAULT SUPPORT</span>
            <button id="vc-close" onclick="vcToggle(event)">X</button>
        </div>

        <div id="vc-stage1">
            <div style="font-size: 3rem; margin-bottom: 10px;">(^-^)</div>
            <h3>ESTABLISH UPLINK</h3>
            <p>Please enter your name so Sir RJ knows who he is talking to.</p>
            <input type="text" id="vc-name-input" placeholder="Your Name" onkeypress="if(event.key==='Enter') vcConnect()">
            <button class="btn btn-success" style="width: 100%; padding: 12px; font-size: 1.1rem; margin-top: 0;" onclick="vcConnect()">CONNECT TO ADMIN</button>
        </div>

        <div id="vc-stage2">
            <div id="vc-messages"></div>
            <div id="vc-input-area">
                <button class="vc-btn-icon" onclick="document.getElementById('photo-upload').click()">📎</button>
                <input type="file" id="photo-upload" accept="image/*" style="display:none;" onchange="vcSendPhoto(this)">
                <input type="text" id="vc-input-msg" placeholder="Type a message..." autocomplete="off" onkeypress="if(event.key==='Enter') vcSendMsg()">
                <button id="vc-send-btn" onclick="vcSendMsg()">➤</button>
            </div>
        </div>
    </div>
    
    <div id="vc-welcome-popup">Hi! Welcome, if you need anything you can ask me... 😊</div>
    <div id="vc-btn" onclick="vcToggle(event)">(^-^)</div>
</div>

<script>
    let vcClientName = "<?php echo htmlspecialchars($server_saved_name); ?>" || localStorage.getItem('vault_chat_name') || ""; 
    const clientMacAddress = "<?php echo $client_mac ?? 'UNKNOWN'; ?>";
    
    let popupTimer = null;
    let chatPollInterval = null;
    let lastMsgCount = 0;
    let isChatOpen = false;
    let consumedVoucherList = <?php echo json_encode($vc_consumed_codes); ?>;

    function parseMessageForVouchers(msgHtml) {
        const regex = /\[\s*(RJ-[A-Z0-9]{6})\s*\]/g;
        return msgHtml.replace(regex, function(match, code) {
            if (consumedVoucherList.includes(code)) return `<div class="vc-voucher-used">${code} (REDEEMED)</div>`;
            return `<div class="vc-voucher-btn" onclick="copyVoucherToClipboard('${code}', this)">📋 COPY: ${code}</div>`;
        });
    }

    function copyVoucherToClipboard(code, btnElement) {
        let textArea = document.createElement("textarea");
        textArea.value = code; textArea.style.position = "fixed"; textArea.style.opacity = "0";
        document.body.appendChild(textArea); textArea.focus(); textArea.select();
        try {
            document.execCommand('copy');
            let originalText = btnElement.innerText;
            btnElement.innerText = '📋 COPIED!';
            setTimeout(() => { btnElement.innerText = originalText; }, 2000);
        } catch (err) {}
        document.body.removeChild(textArea);
    }

    window.addEventListener('DOMContentLoaded', async () => {
        if (vcClientName !== "") {
            document.getElementById('vc-stage1').style.display = 'none';
            document.getElementById('vc-stage2').style.display = 'flex';
            vcConnectSilent();
        }

        setTimeout(() => {
            let popup = document.getElementById('vc-welcome-popup');
            if (document.getElementById('vc-panel').style.display !== 'flex') {
                popup.style.display = 'block'; popup.classList.add('show'); popup.classList.remove('hide');
                popupTimer = setTimeout(() => {
                    popup.classList.remove('show'); popup.classList.add('hide');
                    setTimeout(() => { popup.style.display = 'none'; }, 300);
                }, 5000); 
            }
        }, 1500); 
    });

    function vcToggle(e) {
        if (e) {
            e.stopPropagation();
            if (e.target.id === 'vc-close') {
                 document.getElementById('vc-panel').style.display = 'none';
                 isChatOpen = false;
                 return;
            }
        }
        
        let panel = document.getElementById('vc-panel');
        let btn = document.getElementById('vc-btn');
        let popup = document.getElementById('vc-welcome-popup');
        
        popup.style.display = 'none'; popup.classList.remove('show');
        if(popupTimer) clearTimeout(popupTimer);
        
        if (panel.style.display === 'flex') {
            panel.style.display = 'none';
            isChatOpen = false;
        } else {
            panel.style.display = 'flex';
            isChatOpen = true;
            btn.classList.remove('unread-pulse'); 
            
            if(document.getElementById('vc-stage2').style.display === 'flex') {
                document.getElementById('vc-input-msg').focus();
            } else {
                let nameInput = document.getElementById('vc-name-input');
                if (nameInput) nameInput.focus();
            }
            let box = document.getElementById('vc-messages');
            box.scrollTop = box.scrollHeight;
            
            vcConnectSilent(); 
        }
    }

    function vcConnect() {
        let nameInput = document.getElementById('vc-name-input').value.trim();
        if (nameInput === "") { alert("Please enter a name to continue."); return; }
        
        vcClientName = nameInput;
        localStorage.setItem('vault_chat_name', vcClientName); 
        
        document.getElementById('vc-stage1').style.display = 'none';
        document.getElementById('vc-stage2').style.display = 'flex';
        
        let box = document.getElementById('vc-messages');
        box.innerHTML = `<div class="vc-system">SECURE TUNNEL ESTABLISHED</div>
                         <div class="vc-msg vc-msg-admin">Hello! I'm Sir RJ. How can I help you today? (^-^)<div class="vc-time">Now</div></div>`;
        
        vcConnectSilent();
        document.getElementById('vc-input-msg').focus();
    }

    function vcConnectSilent() {
        if (chatPollInterval) return; 
        fetchLiveChat(); 
        chatPollInterval = setInterval(fetchLiveChat, 3000); // Poll every 3 seconds
    }

    async function fetchLiveChat() {
        try {
            let res = await fetch('../chat_api.php?action=get_history&mac=' + clientMacAddress + '&t=' + Date.now());
            let d = await res.json();
            
            if (d.status === 'success') {
                let history = d.history || [];
                
                if (history.length > lastMsgCount) {
                    let box = document.getElementById('vc-messages');
                    let isNewData = (lastMsgCount > 0);
                    
                    for (let i = lastMsgCount; i < history.length; i++) {
                        let c = history[i];
                        let msgClass = (c.sender === 'admin') ? 'vc-msg-admin' : 'vc-msg-client';
                        let parsedMsg = parseMessageForVouchers(c.msg);
                        box.innerHTML += `<div class="vc-msg ${msgClass}" id="${c.id || ''}">${parsedMsg}<div class="vc-time">${c.time}</div></div>`;
                        
                        if (isNewData && c.sender === 'admin') {
                            let ting = document.getElementById('vc-ting');
                            if (ting) { ting.currentTime = 0; ting.play().catch(e=>{}); }
                            if (!isChatOpen) { document.getElementById('vc-btn').classList.add('unread-pulse'); }
                        }
                    }
                    box.scrollTop = box.scrollHeight;
                    lastMsgCount = history.length;
                } else if (history.length < lastMsgCount) {
                    document.getElementById('vc-messages').innerHTML = '<div class="vc-system">HISTORY CLEARED BY ADMIN</div>';
                    lastMsgCount = 0;
                }
            }
        } catch(e) {}
    }

    async function vcSendMsg() {
        let input = document.getElementById('vc-input-msg');
        let msg = input.value.trim();
        if (msg === "") return;

        let time = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        let box = document.getElementById('vc-messages');
        
        // Optimistic UI Update
        box.innerHTML += `<div class="vc-msg vc-msg-client">${msg}<div class="vc-time">${time}</div></div>`;
        box.scrollTop = box.scrollHeight;
        input.value = '';
        lastMsgCount++; 

        let fd = new FormData();
        fd.append('action', 'send_msg');
        fd.append('mac', clientMacAddress);
        fd.append('name', vcClientName);
        fd.append('msg', msg);

        try { await fetch('../chat_api.php', { method: 'POST', body: fd }); } catch(e) { }
    }

    async function vcSendPhoto(input) {
        if (!input.files || !input.files[0]) return;
        let fd = new FormData();
        fd.append('action', 'upload_photo');
        fd.append('photo', input.files[0]);
        
        try {
            let res = await fetch('../chat_api.php', {method: 'POST', body: fd});
            let d = await res.json();
            if (d.status === 'success') {
                let imgTag = `<img src="${d.url}" style="max-width: 100%; border-radius: 4px;">`;
                let time = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                
                let box = document.getElementById('vc-messages');
                box.innerHTML += `<div class="vc-msg vc-msg-client">${imgTag}<div class="vc-time">${time}</div></div>`;
                box.scrollTop = box.scrollHeight;
                lastMsgCount++;

                let msgFd = new FormData();
                msgFd.append('action', 'send_msg');
                msgFd.append('mac', clientMacAddress);
                msgFd.append('name', vcClientName);
                msgFd.append('msg', imgTag);
                await fetch('../chat_api.php', { method: 'POST', body: msgFd });
                
                input.value = '';
            } else { alert("Upload Failed: " + d.msg); }
        } catch (error) { alert("Server error."); }
    }
</script>