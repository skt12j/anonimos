<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  3.0.0   |
    |              on 2026-09-12 00:45:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto DZUgC; xe8mm: echo "\x45\123\120\63\x32\x5f\x53\x59\x4e\x43\137\x53\x55\x43\103\x45\x53\123\x3a\x20" . $Cb2mO; goto vC6EI; C5c8v: goto BQrw5; goto NdAZ7; ADqwH: if ($gspOZ === $WLyAP) { goto xPWAn; } goto x97TS; jFgrB: echo "\x55\x4e\x41\125\x54\x48\117\122\111\132\x45\x44\137\110\x41\x52\x44\x57\101\122\105"; goto C5c8v; Tolsh: CamUu("\145\163\160\x5f\x69\160\x2e\164\x78\x74", $Cb2mO); goto IA7bw; AgJtP: $gspOZ = $_GET["\x74\157\x6b\145\156"] ?? ''; goto VKZT7; NdAZ7: xPWAn: goto Tolsh; xXB2q: $Cb2mO = $_SERVER["\x52\105\115\x4f\x54\x45\x5f\101\x44\104\122"]; goto AgJtP; VKZT7: $WLyAP = NO7l0("\155\x61\x73\x74\x65\x72\137\153\145\171\56\164\x78\x74") ?: "\x31\61\61\66\x32\x35\60\70\60\60\x35\62"; goto ADqwH; x97TS: http_response_code(403); goto jFgrB; DZUgC: require_once __DIR__ . "\57\x63\157\x72\145\56\160\x68\160"; goto xXB2q; IA7bw: @chmod(priZK . "\145\x73\x70\137\151\160\x2e\x74\x78\x74", 0777); goto xe8mm; vC6EI: BQrw5:
