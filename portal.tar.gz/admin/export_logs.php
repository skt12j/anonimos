<?php
// admin/export_logs.php - Download Analytics as CSV (Ubuntu Edition)

// 1. MUST LOAD CORE FIRST
require_once '../core.php';

// 2. Strict Security: Only logged-in admins can download the ledger!
if (session_status() == PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// 3. Fetch the raw log data
$logs_raw = pullFromVault('logs.json');
$logs = json_decode($logs_raw, true) ?: [];

// 4. Set HTTP headers to force a CSV file download
$filename = "VaultOS_Financial_Logs_" . date('Y-m-d_H-i') . ".csv";
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=' . $filename);

// 5. Open the output stream directly to the browser
$output = fopen('php://output', 'w');

// 6. Write the CSV Column Headers
fputcsv($output, array('TIMESTAMP', 'EVENT TYPE', 'MAC ADDRESS', 'TIER', 'REVENUE (PHP)', 'DETAILS'));

// 7. Write the data row by row (Reversed so newest is at the top)
$logs = array_reverse($logs);
foreach ($logs as $log) {
    fputcsv($output, array(
        $log['date'] ?? 'N/A',
        $log['event'] ?? 'UNKNOWN',
        $log['mac'] ?? 'SYSTEM',
        $log['tier'] ?? '-',
        number_format((float)($log['revenue'] ?? 0), 2),
        $log['details'] ?? '-'
    ));
}

// Close the stream and exit cleanly so no HTML leaks into the CSV
fclose($output);
exit;
?>