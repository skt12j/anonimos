<?php
// portal/rates_modal.php - OPENWRT RAM-DISK EDITION (Time Rates Only)
// This file relies on $rates being defined in the parent index.php

$timeReg = $rates['Time']['Regular'] ?? ($rates['Regular'] ?? []);
$timeGam = $rates['Time']['Gaming'] ?? ($rates['Gaming'] ?? []);

// Sort all arrays from Lowest Price to Highest Price
ksort($timeReg, SORT_NUMERIC);
ksort($timeGam, SORT_NUMERIC);

function formatTimeDisplay($m) {
    $total_seconds = round($m * 60);
    $d = floor($total_seconds / 86400);
    $h = floor(($total_seconds % 86400) / 3600);
    $min = floor(($total_seconds % 3600) / 60);
    $s = $total_seconds % 60;
    
    return sprintf("%02dd:%02dh:%02dm:%02ds", $d, $h, $min, $s);
}
?>

<style>
    .modal-scrollable::-webkit-scrollbar { width: 6px; }
    .modal-scrollable::-webkit-scrollbar-track { background: rgba(0, 0, 0, 0.5); border-radius: 4px; }
    .modal-scrollable::-webkit-scrollbar-thumb { background: var(--info); border-radius: 4px; }
</style>

<div id="m-rates" class="modal">
    <div class="modal-content modal-scrollable" style="max-height: 85vh; overflow-y: auto; padding: 15px; width: 95%; max-width: 500px; display: flex; flex-direction: column;">
        
        <div style="flex: 1;">
            <h2 style="color: var(--info); font-family: 'Orbitron'; margin-bottom: 15px;">NETWORK TARIFFS</h2>
            
            <h3 style="color: #fff; text-align: left; font-family: 'Orbitron'; border-bottom: 1px solid #333; padding-bottom: 5px; font-size: 1.1rem; margin-top: 0;">⏱️ TIME RATES</h3>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 20px;">
                <div>
                    <h4 style="color:var(--info); margin: 10px 0 5px 0; text-align: center; font-size: 0.8rem;">REGULAR</h4>
                    <div style="border: 1px solid rgba(255,255,255,0.1); background: #000; font-size: 0.8rem;">
                        <?php 
                        if (!empty($timeReg)) {
                            foreach ($timeReg as $p => $m) {
                                $display = formatTimeDisplay($m);
                                echo "<div class='rate-row' style='display:flex; justify-content:space-between; align-items: center; padding:6px 8px; border-bottom:1px dashed #333;'><span style='color: var(--success); font-weight:bold; font-family: Orbitron;'>₱{$p}</span><span style='color: #fff; font-family: monospace; font-size: 0.85rem;'>{$display}</span></div>";
                            }
                        } else { echo "<div style='padding:8px; color:#555; text-align:center;'>N/A</div>"; }
                        ?>
                    </div>
                </div>

                <div>
                    <h4 style="color:var(--vip); margin: 10px 0 5px 0; text-align: center; font-size: 0.8rem;">GAMING</h4>
                    <div style="border: 1px solid rgba(255,255,255,0.1); background: #000; font-size: 0.8rem;">
                        <?php 
                        if (!empty($timeGam)) {
                            foreach ($timeGam as $p => $m) {
                                $display = formatTimeDisplay($m);
                                echo "<div class='rate-row' style='display:flex; justify-content:space-between; align-items: center; padding:6px 8px; border-bottom:1px dashed #333;'><span style='color: var(--success); font-weight:bold; font-family: Orbitron;'>₱{$p}</span><span style='color: #fff; font-family: monospace; font-size: 0.85rem;'>{$display}</span></div>";
                            }
                        } else { echo "<div style='padding:8px; color:#555; text-align:center;'>N/A</div>"; }
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <button class="btn" onclick="closeM('m-rates')" style="margin-top: 25px; width: 100%; border-style: dashed; border-color: #555; color: #888;">CLOSE</button>
    </div>
</div>