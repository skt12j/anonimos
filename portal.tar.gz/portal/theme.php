<?php
// portal/theme.php - OPENWRT RAM-DISK EDITION (Pure CSS / Zero Media)

if (!defined('ASSETS_DIR')) define('ASSETS_DIR', '../assets/');

// LITE MODE INHERITANCE
$vault_mode = $_COOKIE['vault_mode'] ?? 'advance';
$is_lite = ($vault_mode === 'lite');
?>

<link rel="icon" type="image/png" href="../assets/logo.png">
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;500;700&family=Source+Code+Pro:wght@400;700&display=swap" rel="stylesheet">

<style>
    :root { 
        --bg-color: #03060c; 
        --info: #00f3ff; 
        --vip: #b026ff; 
        --success: #10b981; 
        --danger: #ff4c4c; 
        --warning: #f59e0b; 
        --theme-color: var(--info); 
        --theme-glow: 0 0 15px var(--info); 
        --theme-bg: rgba(0, 243, 255, 0.05); 
        --border-glow: 1px solid var(--info); 
    }
    
    body.theme-gaming { 
        --theme-color: var(--vip); 
        --theme-glow: 0 0 20px var(--vip); 
        --theme-bg: rgba(176, 38, 255, 0.05); 
        --border-glow: 1px solid var(--vip); 
    }
    
    * { -webkit-tap-highlight-color: transparent; outline: none; }
    
    html {
        background-color: #000 !important; 
        min-height: 100%;
    }

    body { 
        /* Pure CSS Background - No images or videos! */
        background-color: var(--bg-color);
        background-image: radial-gradient(circle at top right, rgba(0, 243, 255, 0.1), transparent 40%),
                          radial-gradient(circle at bottom left, rgba(176, 38, 255, 0.1), transparent 40%);
        background-size: cover; 
        background-position: center; 
        background-attachment: fixed; 
        color: var(--theme-color); 
        font-family: 'Rajdhani', sans-serif; 
        text-align: center; 
        margin: 0; 
        padding: 20px; 
        display: flex; 
        flex-direction: column; 
        align-items: center; 
        min-height: 100vh; 
        overflow-x: hidden;
        user-select: none;
    }

    input, textarea, .selectable, #minted-code { user-select: text !important; }
    
    body::before { 
        <?php if($is_lite) echo 'display: none !important;'; ?>
        content: " "; display: block; position: fixed; top: 0; left: 0; bottom: 0; right: 0; 
        background: linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.25) 50%), 
                    linear-gradient(90deg, rgba(255, 0, 0, 0.06), rgba(0, 255, 0, 0.02), rgba(0, 0, 255, 0.06)); 
        z-index: -500; 
        background-size: 100% 4px, 3px 100%; pointer-events: none; 
    }
    
    h1, h2, h3, h4 { font-family: 'Orbitron', sans-serif; text-transform: uppercase; margin: 10px 0; letter-spacing: 2px; }
    
    h1 { font-weight: 900; font-size: 1.8rem; text-shadow: var(--theme-glow); }
    .container { width: 100%; max-width: 420px; position: relative; z-index: 10; transition: max-width 0.3s ease; }
    
    .panel { background: var(--theme-bg); backdrop-filter: blur(15px); border: var(--border-glow); padding: 20px; box-shadow: inset 0 0 20px rgba(0, 243, 255, 0.1), var(--theme-glow); border-radius: 2px; position: relative; margin-bottom: 20px; clip-path: polygon(0 0, 100% 0, 100% 93%, 95% 100%, 0 100%); transition: padding 0.3s ease; }
    .panel::after { content: "SECURE NODE: " attr(data-node); position: absolute; top: -10px; right: 20px; background: var(--bg-color); padding: 0 10px; font-size: 0.7rem; color: var(--theme-color); border: var(--border-glow); font-family: 'Orbitron'; }
    
    .timer { font-family: 'Orbitron', sans-serif; color: var(--success); text-shadow: 0 0 20px var(--success); margin: 10px 0; font-weight: 900; line-height: 1; transition: font-size 0.3s ease; }
    .timer.paused { color: var(--danger); text-shadow: 0 0 15px var(--danger); }
    
    .status-badge { display: inline-block; padding: 5px 15px; font-family: 'Orbitron'; font-weight: bold; font-size: 0.8rem; margin-bottom: 15px; border-radius: 2px; background: rgba(0,0,0,0.5); border: 1px solid currentColor; }
    
    .btn { 
        background: rgba(0,0,0,0.6); color: var(--theme-color); border: 1px solid var(--theme-color); 
        padding: 14px 8px; font-family: 'Orbitron'; font-weight: 700; font-size: 0.85rem;
        cursor: pointer; text-transform: uppercase; width: 100%; margin-top: 10px; transition: 0.2s all; 
        position: relative; display: flex; align-items: center; justify-content: center; gap: 6px; 
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis; 
    }
    .btn:disabled { cursor: not-allowed; opacity: 0.4; }
    .btn:active:not(:disabled), .btn:hover:not(:disabled) { transform: scale(0.98); background: var(--theme-color); color: #000 !important; box-shadow: var(--theme-glow); }
    
    .btn-success { color: var(--success); border-color: var(--success); background: rgba(16, 185, 129, 0.1); } 
    .btn-success:active:not(:disabled), .btn-success:hover:not(:disabled) { background: var(--success); color: #000 !important; box-shadow: 0 0 20px var(--success); }
    
    .btn-danger { color: var(--danger); border-color: var(--danger); background: rgba(255, 76, 76, 0.1); } 
    .btn-danger:active:not(:disabled), .btn-danger:hover:not(:disabled) { background: var(--danger); color: #000 !important; box-shadow: 0 0 20px var(--danger); }
    
    .btn-warning { color: var(--warning); border-color: var(--warning); background: rgba(245, 158, 11, 0.1); } 
    .btn-warning:active:not(:disabled), .btn-warning:hover:not(:disabled) { background: var(--warning); color: #000 !important; box-shadow: 0 0 20px var(--warning); }
    
    .active-tier { background: var(--theme-color) !important; color: #000 !important; box-shadow: var(--theme-glow); }
    
    input[type="text"], input[type="number"], input[type="password"] { background: rgba(0,0,0,0.7); border: 1px solid var(--theme-color); color: #fff; padding: 15px; width: 100%; margin: 10px 0; font-family: 'Rajdhani'; font-size: 1.4rem; text-align: center; box-sizing: border-box; letter-spacing: 5px; font-weight: 700; transition: font-size 0.3s ease; }
    input[type="text"]:focus, input[type="number"]:focus, input[type="password"]:focus { box-shadow: var(--theme-glow); outline: none; }
    
    .modal { display: none; position: fixed; z-index: 2000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0, 3, 10, 0.85); backdrop-filter: blur(8px); }
    
    .coin-counter { font-size: 5rem; color: var(--success); font-family: 'Orbitron'; font-weight: 900; margin: 10px 0; text-shadow: 0 0 30px var(--success); }
    
    #loader { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: var(--bg-color); z-index: 9999; display: flex; flex-direction: column; align-items: center; justify-content: center; }
    .bar-container { width: 80%; max-width: 400px; border: 1px solid var(--success); height: 10px; padding: 2px; margin: 20px 0; }
    .bar-fill { height: 100%; background: var(--success); width: 0%; box-shadow: 0 0 15px var(--success); transition: width 3s linear; }
    .terminal-log { background: rgba(0,0,0,0.8); border: 1px solid #1a2a44; padding: 10px; font-family: 'Source Code Pro', monospace; font-size: 0.75rem; color: #4a6fa5; text-align: left; height: 80px; overflow: hidden; margin-top: 15px; border-radius: 3px; line-height: 1.4; }
    .rate-row { display: flex; justify-content: space-between; padding: 8px; border-bottom: 1px solid rgba(0,243,255,0.1); font-weight: bold; font-size: 1rem; }
    
    .carousel-slide { position: absolute; width: 100%; height: 100%; object-fit: cover; opacity: 0; transition: opacity 0.5s ease-in-out; }
    .carousel-slide.active { opacity: 1 !important; }
    .ad-frame { margin-top: 20px; border: 1px solid var(--theme-color); padding: 2px; background: #000; box-shadow: var(--theme-glow); border-radius: 3px; position: relative; overflow: hidden; display: flex; justify-content: center; align-items: center; cursor: grab; }
    .ad-frame:active { cursor: grabbing; }
    .ad-frame.portrait { width: 100%; max-width: 350px; height: 480px; margin-left: auto; margin-right: auto; }
    .ad-frame.landscape { width: 100%; height: 160px; }
    
    .modal-tab { padding: 10px; font-family: 'Orbitron'; font-size: 0.8rem; cursor: pointer; flex-grow: 1; border: 1px solid #333; background: #111; color: #666; transition: 0.2s; }
    .modal-tab.active { background: var(--theme-color); color: #000; border-color: var(--theme-color); font-weight: 900; box-shadow: 0 0 10px var(--theme-color); }
    .modal-tab-gam.active { background: var(--vip); border-color: var(--vip); box-shadow: 0 0 10px var(--vip); }
    
    .copy-btn { background: rgba(255,255,255,0.1); border: 1px solid currentColor; color: inherit; padding: 4px 8px; font-size: 0.7rem; font-family: 'Orbitron'; cursor: pointer; border-radius: 2px; }
    .copy-btn:active { background: currentColor; color: #000; }

    @media (min-width: 768px) {
        .container { max-width: 460px; } 
        .panel { padding: 35px; } 
        h1 { font-size: 2rem; margin-bottom: 20px; }
        .btn { font-size: 0.95rem; padding: 16px 10px; } 
        input[type="text"], input[type="number"], input[type="password"] { font-size: 1.6rem; padding: 18px; }
        .status-badge { font-size: 0.9rem; padding: 8px 20px; }
        .ad-frame.portrait { max-width: 400px; height: 500px; } 
        .modal-content { max-width: 460px; padding: 30px; }
        .terminal-log { font-size: 0.8rem; height: 85px; } 
    }
    
    .modal-content {
        background-color: rgba(0, 0, 0, 0.2) !important; 
        backdrop-filter: blur(8px);
        background-image:
            radial-gradient(circle at 100% 0%, rgba(234, 88, 12, 0.25) 0%, transparent 60%),
            radial-gradient(circle at 0% 100%, rgba(0, 243, 255, 0.2) 0%, transparent 60%),
            linear-gradient(rgba(0, 243, 255, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 243, 255, 0.1) 1px, transparent 1px) !important;
        background-size: 100% 100%, 100% 100%, 30px 30px, 30px 30px !important;
        background-position: top right, bottom left, center, center !important;
        border: 2px solid var(--theme-color) !important;
        box-shadow: 0 0 25px rgba(0, 243, 255, 0.15), inset 0 0 20px rgba(0, 243, 255, 0.1) !important;
        border-radius: 8px !important;
        position: relative;
        margin: 10% auto;
        padding: 25px;
        width: 85%;
        max-width: 400px;
        transition: max-width 0.3s ease;
        overflow: hidden; 
    }

    .modal-content::before {
        content: ''; position: absolute; top: 5px; left: 5px; right: 5px; bottom: 5px;
        border: 1px solid rgba(0, 243, 255, 0.1); border-radius: 4px; pointer-events: none; z-index: 0;
    }

    .modal-content > * { position: relative; z-index: 1; }

</style>

<script>
    document.addEventListener('contextmenu', event => {
        if (event.target.tagName !== 'INPUT' && event.target.tagName !== 'TEXTAREA') event.preventDefault();
    });
    document.onkeydown = function(e) {
        if(e.keyCode == 123 || (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) || (e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) || (e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) || (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0))) return false;
    }
</script>