<?php
// activate.php - One-Time Hardware Activation
define('DB_DIR', '/tmp/html/db/');

// Fetch the router's hardware MAC to show to the customer
$hardware_mac = trim(shell_exec("cat /sys/class/net/eth0/address 2>/dev/null"));
$hardware_mac = strtoupper($hardware_mac);
if (empty($hardware_mac)) { $hardware_mac = "UNKNOWN-MAC-ADDRESS"; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $entered_key = trim($_POST['license_key']);
    
    // Save the key to the database
    if (!file_exists(DB_DIR)) { @mkdir(DB_DIR, 0777, true); }
    @file_put_contents(DB_DIR . 'license.key', $entered_key);
    
    // Also save a permanent backup so it survives reboots!
    if (!file_exists('/root/vault_backup/')) { @mkdir('/root/vault_backup/', 0777, true); }
    @file_put_contents('/root/vault_backup/license.key', $entered_key);
    
    echo "<h2>VAULT OS ACTIVATED!</h2><p>Please wait 5 seconds...</p>";
    
    // Delete the activation page so it can never be used again
    @unlink(__FILE__); 
    header("Refresh: 3; url=/admin/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<body style="background: #111; color: #0cf; text-align: center; font-family: sans-serif; padding-top: 50px;">
    <h1>VAULT OS HARDWARE ACTIVATION</h1>
    
    <div style="background: #222; border: 2px dashed #0cf; padding: 20px; margin: 20px auto; width: 350px; border-radius: 10px;">
        <p style="color: #ccc; margin-top: 0;">Your Router's MAC Address:</p>
        <h2 style="color: yellow; margin: 0; letter-spacing: 2px;"><?php echo $hardware_mac; ?></h2>
        <p style="color: #888; font-size: 0.9rem; margin-bottom: 0;">Send this MAC Address to Anonimos Admin to get your License Key.</p>
    </div>

    <form method="POST">
        <p>Enter your assigned License Key:</p>
        <input type="text" name="license_key" style="padding: 10px; width: 300px; font-size: 1.2rem; text-align: center;" required>
        <br><br>
        <button type="submit" style="padding: 12px 25px; background: #0cf; color: #111; font-weight: bold; border: none; border-radius: 5px; cursor: pointer;">ACTIVATE SYSTEM</button>
    </form>
</body>
</html>
