<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  3.0.0   |
    |              on 2026-09-12 03:12:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 header("\114\x6f\143\141\x74\x69\x6f\x6e\72\40\57\x70\157\x72\x74\141\x6c\57"); exit;
