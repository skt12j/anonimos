<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  3.0.0   |
    |              on 2026-09-12 02:59:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto NhUDd; Jn5HW: if (!(session_status() == PHP_SESSION_NONE)) { goto HPunk; } goto cpVGT; T4zSi: HPunk: goto OBcZS; NhUDd: require_once "\56\56\57\x63\157\x72\145\56\160\x68\x70"; goto Jn5HW; OBcZS: $_SESSION = array(); goto fbdmU; NCU8p: header("\114\x6f\x63\x61\x74\151\x6f\x6e\x3a\x20\x6c\157\147\151\x6e\x2e\x70\x68\x70"); goto RUfXS; fbdmU: session_destroy(); goto NCU8p; cpVGT: session_start(); goto T4zSi; RUfXS: exit;
