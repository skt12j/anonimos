<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  3.0.0   |
    |              on 2026-09-12 03:29:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto vqEM_; LYq1G: if (!(session_status() == PHP_SESSION_NONE)) { goto L2Y5P; } goto Adstn; XCzBX: header("\x4c\x6f\x63\x61\164\x69\157\156\x3a\x20\154\157\x67\x69\156\x2e\160\150\x70"); goto bVs0q; Adstn: session_start(); goto px3f2; vqEM_: require_once "\x2e\56\57\143\x6f\x72\x65\56\160\150\x70"; goto LYq1G; px3f2: L2Y5P: goto rryEQ; gSHCF: session_destroy(); goto XCzBX; rryEQ: $_SESSION = array(); goto gSHCF; bVs0q: exit;
