<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  3.0.0   |
    |              on 2026-09-12 03:12:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto zZvsd; d3YrA: session_destroy(); goto jd_S0; zZvsd: require_once "\x2e\x2e\57\x63\157\x72\145\56\160\x68\x70"; goto v1Lx3; v1Lx3: if (!(session_status() == PHP_SESSION_NONE)) { goto XLnV6; } goto Ocpcu; jd_S0: header("\x4c\x6f\143\x61\164\x69\157\x6e\72\x20\154\157\147\x69\156\x2e\160\x68\x70"); goto Ble4I; OKnYa: $_SESSION = array(); goto d3YrA; Ocpcu: session_start(); goto LPGet; LPGet: XLnV6: goto OKnYa; Ble4I: exit;
