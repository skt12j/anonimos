<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  3.0.0   |
    |              on 2026-09-12 02:59:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 header("\x4c\157\143\x61\164\x69\x6f\156\x3a\x20\57\x70\x6f\x72\164\x61\x6c\x2f"); exit;
