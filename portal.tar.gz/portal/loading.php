<?php
// portal/loading.php - OPENWRT RAM-DISK EDITION
$disp_mac = isset($client_mac) ? $client_mac : 'UNKNOWN_MAC';
$disp_ip = isset($client_ip) ? $client_ip : 'UNKNOWN_IP';
?>

<style>
    #l-term::-webkit-scrollbar { width: 4px; }
    #l-term::-webkit-scrollbar-track { background: rgba(0, 0, 0, 0.5); }
    #l-term::-webkit-scrollbar-thumb { background: var(--theme-color, #00f3ff); border-radius: 4px; }
    
    .l-cursor-blink {
        display: inline-block; width: 8px; height: 15px; background-color: var(--theme-color, #00f3ff);
        animation: blink 1s step-end infinite; vertical-align: middle; margin-left: 2px; margin-top: -2px;
    }
    @keyframes blink { 50% { opacity: 0; } }
</style>

<div id="loader" style="display:none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: #000; z-index: 9999; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
    
    <div id="l-icon" style="font-size: 4rem; text-shadow: 0 0 20px var(--theme-color); margin-bottom: 10px; display: none;"></div>
    <h2 id="l-title" style="color: var(--theme-color); font-size: 2rem; font-family: 'Orbitron'; text-shadow: 0 0 15px var(--theme-color);">INITIALIZING UPLINK</h2>
    
    <div class="bar-container" style="width: 80%; max-width: 300px; height: 10px; background: #222; margin: 20px 0; border-radius: 5px; overflow: hidden; border: 1px solid var(--theme-color);">
        <div class="bar-fill" id="bar" style="height: 100%; background: var(--theme-color); width: 0%; transition: width 3s linear;"></div>
    </div>
    
    <p id="l-stat" style="color: var(--theme-color); font-family: 'Source Code Pro'; margin-bottom: 20px;">PLEASE STAND BY...</p>
    
    <div class="terminal-log" id="l-term" style="width: 80%; max-width: 400px; max-height: 150px; overflow-y: auto; color: var(--theme-color); background: rgba(0,0,0,0.8); border: 1px dashed var(--theme-color); padding: 15px; font-family: 'Source Code Pro', monospace; font-size: 0.85rem; text-align: left;">
        <span id="l-term-text"></span><span class="l-cursor-blink" id="l-cursor"></span>
    </div>

</div>

<script>
    var isSubmitting = false;
    var l_typeTimeout = null;

    function triggerSubmitLoader(event, formElement, titleText, isResync = false, audioId = 's-loading', customLines = null, customTheme = null) {
        if(event && event.preventDefault) event.preventDefault(); 
        if (isSubmitting) return false;
        isSubmitting = true;

        let submitBtns = formElement.querySelectorAll('button[type="submit"], button[type="button"]');
        submitBtns.forEach(btn => { btn.disabled = true; btn.style.opacity = '0.5'; btn.style.cursor = 'not-allowed'; });
        
        let welcomeAudio = document.getElementById('s-welcome');
        if (welcomeAudio && !welcomeAudio.paused) welcomeAudio.pause();

        let loadAudio = document.getElementById(audioId);
        if (loadAudio) { loadAudio.currentTime = 0; loadAudio.play().catch(e=>{}); }

        let mac = "<?php echo htmlspecialchars($disp_mac, ENT_QUOTES, 'UTF-8'); ?>";
        let ip = "<?php echo htmlspecialchars($disp_ip, ENT_QUOTES, 'UTF-8'); ?>";
        
        let themeColor = customTheme ? customTheme : 'var(--theme-color)';
        
        if (titleText.includes("FROZEN") || titleText.includes("FREEZING")) { 
            themeColor = '#00f3ff'; document.getElementById('l-icon').innerText = '❄️'; document.getElementById('l-icon').style.display = 'block'; 
        } else if (titleText.includes("PURGING") || titleText.includes("WIPE") || titleText.includes("OVERRIDING") || titleText.includes("WIPING")) { 
            themeColor = 'var(--danger)'; 
        } else if (titleText.includes("RESTORED") || titleText.includes("GRANTED") || titleText.includes("VERIFYING") || titleText.includes("SUCCESS")) { 
            themeColor = 'var(--success)'; 
        } else if (titleText.includes("SWITCHING") || titleText.includes("JUMP")) { 
            themeColor = 'var(--warning)'; document.getElementById('l-icon').innerText = '⚡'; document.getElementById('l-icon').style.display = 'block'; 
        }

        document.getElementById('l-title').style.color = themeColor;
        document.getElementById('l-title').style.textShadow = `0 0 15px ${themeColor}`;
        document.getElementById('bar').style.background = themeColor;
        document.getElementById('bar').parentElement.style.borderColor = themeColor;
        document.getElementById('l-stat').style.color = themeColor;
        document.getElementById('l-term').style.color = themeColor;
        document.getElementById('l-term').style.borderColor = themeColor;
        document.getElementById('l-cursor').style.backgroundColor = themeColor;

        document.getElementById('loader').style.display = 'flex';
        document.getElementById('l-title').innerText = titleText;
        document.getElementById('bar').style.width = '0%';
        
        document.getElementById('l-term-text').innerHTML = "";
        clearTimeout(l_typeTimeout);

        let lines = [];
        
        if (customLines) {
            lines = customLines;
        } else if (titleText.includes("ROUTING TO LOBBY")) {
            lines = [
                `> TARGET_NODE: ${mac} [${ip}]`,
                `> ACTION: TERMINATING SESSION`, 
                "> CLEARING LOCAL CACHE...", 
                "> FIREWALL: ENFORCING ISOLATION", 
                `<span style='color: var(--danger);'>> REDIRECTING TO LOBBY...</span>`
            ];
        } else if (titleText.includes("WIPING") || titleText.includes("PURGING") || titleText.includes("OVERRIDING")) {
            lines = [
                `> TARGET_NODE: ${mac} [${ip}]`,
                `> WARNING: OVERRIDE PROTOCOL INITIATED`, 
                `> PURGING EXISTING VAULT DATA...`, 
                `> EXECUTING FORCE COMMAND...`, 
                `<span style='color: var(--danger);'>> OLD BALANCES PERMANENTLY DELETED.</span>`
            ];
        } else if (titleText.includes("FREEZING")) {
            lines = [
                `> TARGET_NODE: ${mac} [${ip}]`,
                `> INITIATING CRYPTO-FREEZE...`, 
                `> SAVING STATE TO VAULT...`, 
                `> DISCONNECTING IP TUNNEL...`, 
                `<span style='color: #00f3ff;'>> SESSION SECURELY FROZEN.</span>`
            ];
        } else if (isResync || titleText.includes("RESTORE") || titleText.includes("JUMP")) {
            lines = [
                `> TARGET_NODE: ${mac} [${ip}]`,
                `> RETRIEVING VAULT DATA...`, 
                `> BYPASSING FIREWALL...`, 
                `> FORCING IP TUNNEL...`, 
                `<span style='color: var(--success);'>> UPLINK RE-ESTABLISHED.</span>`
            ];
        } else {
            lines = [
                `> TARGET_NODE: ${mac} [${ip}]`,
                `> AUTH_SECURE_EXCHANGE: IN PROGRESS`, 
                `> COMPILING NETWORK REQUEST...`, 
                `> PLEASE STAND BY...`, 
            ];
        }

        let currentLine = 0;
        let sysLogContainer = document.getElementById('l-term');
        
        function typeLine() { 
            if (currentLine < lines.length) { 
                document.getElementById('l-term-text').innerHTML += lines[currentLine] + "<br>"; 
                sysLogContainer.scrollTop = sysLogContainer.scrollHeight; 
                currentLine++; 
                let randomDelay = Math.floor(Math.random() * 400) + 300; 
                l_typeTimeout = setTimeout(typeLine, randomDelay); 
            } 
        }
        
        setTimeout(typeLine, 100);
        setTimeout(() => { document.getElementById("bar").style.width = "100%"; }, 100);
        setTimeout(() => { document.getElementById("l-stat").innerText = "SYNCHRONIZING KERNEL..."; }, 1000);
        setTimeout(() => { document.getElementById("l-stat").innerText = "READY."; }, 2500);
        
        setTimeout(() => { 
            if (loadAudio && audioId === 's-loading') loadAudio.pause(); 
            // 🔥 NATIVE DOM SUBMISSION HACK (Bypasses Android WebView Blocks!) 🔥
            HTMLFormElement.prototype.submit.call(formElement);
        }, 3000); 
    }
</script>