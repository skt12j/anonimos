<?php
// portal/status.php - VAULT OS: THE DASHBOARD (Pure CSS / No Audio / Time Only)
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }

// 🔥 LITE MODE TOGGLE ENGINE 🔥
if (isset($_GET['mode'])) {
    $new_mode = ($_GET['mode'] === 'lite') ? 'lite' : 'advance';
    setcookie('vault_mode', $new_mode, time() + (86400 * 30), "/"); 
    header("Location: status.php");
    exit;
}
$vault_mode = $_COOKIE['vault_mode'] ?? 'advance';
$is_lite = ($vault_mode === 'lite');

// Load massive backend logic from the new modular folder!
require_once 'stat/core.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>VAULT OS | PISO WIFI DASHBOARD</title>
    <?php include 'theme.php'; ?>
    <style>
        .result-cursor { display: inline-block; width: 8px; height: 15px; animation: blink 1s step-end infinite; vertical-align: middle; margin-left: 2px; margin-top: -2px; }
        @keyframes blink { 50% { opacity: 0; } }
        
        .offline-disabled { opacity: 0.4 !important; pointer-events: none !important; filter: grayscale(100%); }
        .offline-pulse { animation: offlineBlink 1.5s infinite; }
        @keyframes offlineBlink { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; color: #ff4c4c; } }

        /* Pure CSS Styling (No heavy background images) */
        .status-time-box { background: rgba(0,0,0,0.5); border: 1px solid var(--theme-color); padding: 15px; border-radius: 4px; text-align: center; }
        .stb-val { font-size: 2rem; font-family: 'Source Code Pro', monospace; font-weight: bold; color: #fff; margin-top: 5px; }
        .stb-label { font-size: 0.8rem; font-family: 'Orbitron'; color: var(--theme-color); letter-spacing: 1px; }
    </style>

    <?php if ($is_lite): ?>
    <style>
        body { background: #0a0a0a !important; background-image: none !important; }
        * { animation: none !important; transition: none !important; box-shadow: none !important; text-shadow: none !important; }
        .panel, .modal-content, .card { background: #111 !important; border: 1px solid #333 !important; }
        .btn { box-shadow: none !important; border-radius: 4px !important; }
        #particles-js, .glitch, .scanlines { display: none !important; }
    </style>
    <?php endif; ?>
</head>
<body class="<?php echo ($active_tier === 'Gaming') ? 'theme-gaming' : ''; ?>">

    <?php include 'loading.php'; ?>

    <div class="container">
        
        <div style="display: flex; justify-content: flex-end; margin-bottom: 10px;">
            <?php if ($is_lite): ?>
                <button onclick="window.location.href='?mode=advance'" class="btn outline" style="font-size: 0.7rem; padding: 6px 12px; border-color: var(--vip); color: var(--vip); font-family: 'Orbitron'; font-weight: bold;">🚀 ADVANCE MODE</button>
            <?php else: ?>
                <button onclick="window.location.href='?mode=lite'" class="btn outline" style="font-size: 0.7rem; padding: 6px 12px; border-color: var(--success); color: var(--success); font-family: 'Orbitron'; font-weight: bold;">⚡ LITE MODE</button>
            <?php endif; ?>
        </div>

        <div style="margin-bottom: 20px;">
            <?php if(!$is_lite): ?>
                <img src="../assets/logo.png" style="max-width: 120px; filter: drop-shadow(var(--theme-glow)); margin-bottom: 10px;">
            <?php endif; ?>
            <h1 style="font-size: 1.5rem; <?php echo $is_lite ? 'color: var(--theme-color);' : ''; ?>">COMMAND DASHBOARD</h1>
        </div>

        <div class="panel" data-node="<?php echo substr($client_mac, -5); ?>" style="border-top: 4px solid var(--theme-color);">
            
            <?php if ($user_data['status'] === 'paused'): ?>
                <div class="status-badge" style="color: var(--warning); border-color: var(--warning); box-shadow: 0 0 10px rgba(245,158,11,0.2);">
                    ❄️ SESSION FROZEN (PAUSED)
                </div>
            <?php else: ?>
                <div class="status-badge" id="sys-status-label" style="color: var(--success); border-color: var(--success); box-shadow: 0 0 10px rgba(16,185,129,0.2);">
                    ● UPLINK ACTIVE (<?php echo strtoupper($active_tier); ?>)
                </div>
            <?php endif; ?>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 25px 0;">
                <div class="status-time-box" style="border-color: var(--info);">
                    <div class="stb-label" style="color: var(--info);">REGULAR TIME</div>
                    <div class="stb-val" id="disp-reg-time"><?php echo gmdate("H:i:s", $time_reg); ?></div>
                    <?php if ($active_tier !== 'Regular' && $time_reg > 0): ?>
                        <form method="POST" style="margin-top: 10px;">
                            <input type="hidden" name="action" value="switch_tier">
                            <input type="hidden" name="target_tier" value="Regular">
                            <button class="btn outline" style="font-size: 0.7rem; padding: 5px; width: 100%; border-color: var(--info); color: var(--info);">ACTIVATE REGULAR</button>
                        </form>
                    <?php endif; ?>
                </div>

                <div class="status-time-box" style="border-color: var(--vip);">
                    <div class="stb-label" style="color: var(--vip);">VIP GAMING TIME</div>
                    <div class="stb-val" id="disp-gam-time"><?php echo gmdate("H:i:s", $time_gam); ?></div>
                    <?php if ($active_tier !== 'Gaming' && $time_gam > 0): ?>
                        <form method="POST" style="margin-top: 10px;">
                            <input type="hidden" name="action" value="switch_tier">
                            <input type="hidden" name="target_tier" value="Gaming">
                            <button class="btn outline" style="font-size: 0.7rem; padding: 5px; width: 100%; border-color: var(--vip); color: var(--vip);">ACTIVATE GAMING</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <?php 
                $button_section = 'status_main'; 
                include 'buttons.php'; 
            ?>

            <?php $log_mode = 'status'; include 'log_work.php'; ?>
        </div>
        
        <?php if (!$is_lite) include 'ads_board.php'; ?>
    </div>

    <div id="m-voucher" class="modal"><div class="modal-content" style="border-color: var(--theme-color);">
        <h2 style="color: var(--theme-color); font-family: 'Orbitron';">REDEEM KEYCODE</h2>
        <form method="POST" onsubmit="return triggerSubmitLoader(event, this, 'DECRYPTING KEYCODE...', false);">
            <input type="hidden" name="action" value="redeem_voucher">
            <input type="text" name="voucher" placeholder="XXXXXX" autocomplete="off" required>
            <?php $button_section = 'modal_submit'; include 'buttons.php'; ?>
        </form>
        <?php $button_section = 'modal_cancel'; include 'buttons.php'; ?>
    </div></div>

    <div id="m-alert" class="modal" <?php if($error_message) echo 'style="display:flex;"'; ?>><div class="modal-content" style="border-color: var(--danger);">
        <h2 style="color: var(--danger);">ERROR DETECTED</h2>
        <p id="m-alert-txt" style="font-size: 1.2rem; margin: 20px 0;"><?php echo $error_message; ?></p>
        <?php $button_section = 'modal_ack'; include 'buttons.php'; ?>
    </div></div>

    <?php include 'rates_modal.php'; ?>

    <script>
        var ratesData = <?php echo empty($rates_json) ? '{}' : $rates_json; ?>;
        var currentModalTier = '<?php echo $active_tier; ?>'; 
        var activeTier = '<?php echo $active_tier; ?>';
        var isPaused = <?php echo ($user_data['status'] === 'paused') ? 'true' : 'false'; ?>;
        
        var timeReg = <?php echo $time_reg; ?>;
        var timeGam = <?php echo $time_gam; ?>;

        const MY_LOBBY_TAB_ID = Date.now().toString() + Math.random().toString();
        localStorage.setItem('vault_lobby_tab', MY_LOBBY_TAB_ID);

        window.addEventListener('storage', function(e) {
            if (e.key === 'vault_lobby_tab' && e.newValue !== MY_LOBBY_TAB_ID) {
                lockScreen("SESSION TRANSFERRED", "You opened the Vault Dashboard in a new tab.");
            }
        });

        function lockScreen(title, msg) {
            if(document.getElementById('global-shield')) return;
            let shield = document.createElement('div'); shield.id = 'global-shield';
            shield.style.position = 'fixed'; shield.style.top = '0'; shield.style.left = '0';
            shield.style.width = '100%'; shield.style.height = '100%'; shield.style.background = 'rgba(0,0,0,0.95)';
            shield.style.zIndex = '999999'; shield.style.display = 'flex'; shield.style.flexDirection = 'column';
            shield.style.alignItems = 'center'; shield.style.justifyContent = 'center'; shield.style.backdropFilter = 'blur(5px)';
            shield.innerHTML = `<h2 style="color:var(--danger); font-family:'Orbitron';">${title}</h2><p style="color:#aaa;">${msg}</p>`;
            document.body.appendChild(shield);
        }

        function formatTimeJS(seconds) {
            if (seconds <= 0) return "00:00:00";
            let h = Math.floor(seconds / 3600).toString().padStart(2, '0');
            let m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
            let s = Math.floor(seconds % 60).toString().padStart(2, '0');
            return `${h}:${m}:${s}`;
        }

        function updateDisplay() {
            document.getElementById('disp-reg-time').innerText = formatTimeJS(timeReg);
            document.getElementById('disp-gam-time').innerText = formatTimeJS(timeGam);
        }

        // Live Server Sync
        setInterval(() => {
            fetch('?ajax_data=1&t=' + new Date().getTime())
            .then(r => r.json())
            .then(d => {
                if(d.status === 'expired') window.location.href = 'expired.php';
                else if(d.status === 'frozen' && !isPaused) location.reload();
                else if(d.status === 'active') {
                    timeReg = d.time_reg; timeGam = d.time_gam;
                    if(d.tier !== activeTier) location.reload();
                    updateDisplay();
                }
            }).catch(e=>{});
        }, 5000);

        // Local Countdown
        setInterval(() => {
            if (!isPaused) {
                if (activeTier === 'Regular' && timeReg > 0) timeReg--;
                if (activeTier === 'Gaming' && timeGam > 0) timeGam--;
                if (timeReg <= 0 && activeTier === 'Regular') location.reload();
                if (timeGam <= 0 && activeTier === 'Gaming') location.reload();
            }
            updateDisplay();
        }, 1000);

        function openVoucher() { document.getElementById('m-voucher').style.display = 'flex'; }
        function openRates() { document.getElementById('m-rates').style.display = 'flex'; }
        function closeM(id) { let modal = document.getElementById(id); if (modal) modal.style.display = 'none'; }

        // Internet Checker
        var isInternetOnline = true;
        var badgeOriginalText = "";
        var badgeOriginalColor = "";
        
        function checkServerInternet() {
            var badge = document.getElementById('sys-status-label');
            if (badge && !badgeOriginalText && !badge.innerText.includes('INTERNET')) {
                badgeOriginalText = badge.innerHTML;
                badgeOriginalColor = badge.style.color;
            }

            fetch('?ping_check=1&t=' + new Date().getTime())
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    isInternetOnline = data.internet;
                    var btns = document.querySelectorAll('.btn');
                    
                    if (!isInternetOnline) {
                        if (badge) {
                            badge.innerHTML = '● NO INTERNET... PLEASE TRY AGAIN LATER';
                            badge.style.color = 'var(--danger)';
                            badge.classList.add('offline-pulse');
                        }
                        btns.forEach(function(btn) { btn.classList.add('offline-disabled'); });
                    } else {
                        if (badge && badgeOriginalText) {
                            badge.innerHTML = badgeOriginalText;
                            badge.style.color = badgeOriginalColor;
                            badge.classList.remove('offline-pulse');
                        }
                        btns.forEach(function(btn) { btn.classList.remove('offline-disabled'); });
                    }
                }).catch(function(e) {});
            setTimeout(checkServerInternet, 4000);
        }
        setTimeout(checkServerInternet, 1000);

        <?php if($error_message): ?>
            document.getElementById('m-alert').style.display = 'flex';
        <?php endif; ?>
    </script>
    
    <?php include 'coin_core.php'; ?>
    
    <?php if (!$is_lite): ?>
        <?php include 'chat_widget.php'; ?>
        <?php include 'lgb.php'; ?> 
    <?php endif; ?>

</body>
</html>