<?php
// admin/logout.php - Secure Session Terminator (Ubuntu Edition)

// 1. MUST LOAD CORE FIRST so it finds the exact SSD session to destroy
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { 
    session_start(); 
}

// 2. Annihilate all session data
$_SESSION = array();
session_destroy();

// 3. Redirect back to the standalone login screen
header("Location: login.php");
exit;
?>