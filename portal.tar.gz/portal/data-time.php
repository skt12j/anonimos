<!-- portal/data-time.php - OPENWRT RAM-DISK EDITION -->
<div id="display-time-mode" style="display:block;">
    <div class="timer <?php echo ($status === 'paused') ? 'paused' : ''; ?>" id="main-timer" 
         style="transition: color 0.5s, text-shadow 0.5s, font-size 0.3s ease-in-out; font-variant-numeric: tabular-nums; white-space: nowrap;">
         00H:00M:00S
    </div>
</div>

<div style="font-family: 'Orbitron'; font-size: 1.1rem; color: var(--theme-color); margin-bottom: 20px;">
    SELECTED NODE: <span id="node-label"><?php echo strtoupper($active_tier); ?></span>
</div>