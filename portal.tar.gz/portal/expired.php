<?php
// portal/expired.php - OPENWRT RAM-DISK EDITION (Time Mode Only)
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }

// 🔥 LITE MODE TOGGLE ENGINE 🔥
if (isset($_GET['mode'])) {
    $new_mode = ($_GET['mode'] === 'lite') ? 'lite' : 'advance';
    setcookie('vault_mode', $new_mode, time() + (86400 * 30), "/"); 
    header("Location: expired.php");
    exit;
}
$vault_mode = $_COOKIE['vault_mode'] ?? 'advance';
$is_lite = ($vault_mode === 'lite');

$client_ip = $_SERVER['REMOTE_ADDR'];
$client_mac = getClientMac($client_ip);

$blocked_file = DB_DIR . 'blocked.json';
if (file_exists($blocked_file)) {
    $blocked = json_decode(file_get_contents($blocked_file), true);
    if (isset($blocked[$client_mac])) { header("Location: /portal/banned.php"); exit; }
}

$sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
$current_time = time();

if (isset($sessions[$client_mac]) && ($sessions[$client_mac]['status'] ?? '') === 'active') {
    header("Location: /portal/status.php"); exit;
}

$active_tier = $sessions[$client_mac]['tier'] ?? 'Regular';

$error_message = '';
$activation_success = false;
$bought_voucher_code = '';
$bought_voucher_val = 0;
$bought_voucher_price = 0;

$rates = json_decode(pullFromVault('rates.json'), true) ?: [];
$rates_json = json_encode($rates); 
$config = json_decode(pullFromVault('ads_config.json'), true) ?: ["orientation" => "portrait"];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    if (isset($_SESSION['last_post_time']) && (time() - $_SESSION['last_post_time']) < 5) {
        $error_message = "ANTI-SPAM: PLEASE DO NOT REFRESH THE PAGE DURING TRANSACTIONS.";
        $action = 'blocked_by_shield';
    } else {
        $_SESSION['last_post_time'] = time();
    }

    // --- 🔥 THE WIPE & LOBBY PROTOCOL ---
    if ($action === 'acknowledge_expired' || $action === 'wipe_and_lobby') {
        $sessions[$client_mac]['status'] = 'inactive';
        $sessions[$client_mac]['expires'] = 0;
        $sessions[$client_mac]['time_left'] = 0;
        $sessions[$client_mac]['bank_Regular'] = 0;
        $sessions[$client_mac]['bank_Gaming'] = 0;
        
        pushToVault('sessions.json', json_encode($sessions)); 
        fw_drop($client_mac, $client_ip);
        header("Location: /portal/index.php"); exit;
    }

    // --- 🔄 SWITCH TIER LOGIC ---
    elseif ($action === 'switch_tier') {
        $target = $_POST['target_tier'];
        if ($target !== $active_tier) {
            $sessions[$client_mac]['tier'] = $target;
            
            $new_time = $sessions[$client_mac]["bank_$target"] ?? 0;
            $sessions[$client_mac]["bank_$target"] = 0; 

            if ($new_time > 0) {
                $sessions[$client_mac]['expires'] = $current_time + $new_time;
                $sessions[$client_mac]['status'] = 'active'; 
                $sessions[$client_mac]['time_left'] = 0;
                $sessions[$client_mac]['ignore_late_payload'] = true; 
                pushToVault('sessions.json', json_encode($sessions)); 
                
                fw_drop($client_mac, $client_ip); 
                fw_allow($client_mac, $client_ip, $target); 
                header("Location: /portal/status.php?screen=resynced"); exit; 
            }
        }
    }

    // --- 🛒 ADD COIN / BUY VOUCHER / REDEEM ---
    elseif (in_array($action, ['buy_voucher', 'add_coin', 'redeem_voucher'])) {
        $logs = json_decode(pullFromVault('logs.json'), true) ?: [];
        $sales_raw = pullFromVault('sales.txt');
        $total_sales = is_numeric($sales_raw) ? (float)$sales_raw : 0.00;

        $safe_rates = [
            'Regular' => $rates['Time']['Regular'] ?? ($rates['Regular'] ?? ['1' => 10, '5' => 60, '10' => 130]),
            'Gaming' => $rates['Time']['Gaming'] ?? ($rates['Gaming'] ?? ['1' => 10, '5' => 60, '10' => 130])
        ];

        $promo_applied = false;

        if ($action === 'buy_voucher' && isset($_POST['coins']) && (int)$_POST['coins'] > 0) {
            $inserted_coins = (int)$_POST['coins']; 
            $target_tier = $_POST['tier'] ?? 'Regular';
            
            $tier_rates = $safe_rates[$target_tier] ?? []; 
            $val_added = 0; $remaining_coins = $inserted_coins;
            
            if(!empty($tier_rates)) {
                $available_denoms = array_keys($tier_rates); rsort($available_denoms, SORT_NUMERIC); 
                foreach ($available_denoms as $denom) {
                    $denom_int = (int)$denom; if ($denom_int <= 0) continue;
                    $count = floor($remaining_coins / $denom_int);
                    if ($count > 0) { $val_added += ($count * (float)$tier_rates[$denom]); $remaining_coins -= ($count * $denom_int); }
                }
            }

            $promo = json_decode(pullFromVault('promo.json'), true);
            $coin_history_str = $_POST['coin_history'] ?? '';
            $coin_history_arr = $coin_history_str !== '' ? explode(',', $coin_history_str) : [$inserted_coins];

            if ($promo && isset($promo['status']) && $promo['status'] === 'on') {
                if (in_array((string)$promo['target_amount'], $coin_history_arr)) {
                    $val_added += (int)$promo['bonus_minutes'];
                    $promo_applied = true;
                }
            }

            if ($val_added > 0) {
                $vouchers = json_decode(pullFromVault('vouchers.json'), true) ?: [];
                $new_code = "RJ-" . substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 6);
                
                $vouchers[$new_code] = [ 
                    'mode' => 'Time', 'value' => (float)$val_added, 'tier' => $target_tier, 'price' => (float)$inserted_coins, 
                    'status' => 'unused', 'created_date' => date('Y-m-d H:i:s'), 'creator_mac' => $client_mac, 'used_by' => null, 'used_date' => null
                ];
                
                $total_sales += $inserted_coins;
                $details = "Added {$val_added}m" . ($promo_applied ? " [🔥 20 PHP PROMO APPLIED]" : "");
                $logs[] = ['date' => date('Y-m-d H:i:s'), 'mac' => $client_mac, 'event' => 'VOUCHER_BOUGHT', 'tier' => $target_tier, 'details' => "Bought: $new_code | ₱$inserted_coins ($details)", 'revenue' => (float)$inserted_coins];
                
                pushToVault('vouchers.json', json_encode($vouchers)); pushToVault('logs.json', json_encode($logs)); pushToVault('sales.txt', (string)$total_sales);
                
                $bought_voucher_code = $new_code; $bought_voucher_val = $val_added; $bought_voucher_price = $inserted_coins;
            } else { $error_message = "SYSTEM ERROR: No valid rates configured for " . strtoupper($target_tier) . " TIME."; }
        }
        elseif (($action === 'add_coin' || $action === 'redeem_voucher') && (isset($_POST['coins']) || !empty($_POST['voucher']))) {
            $val_added = 0; $price = 0; $target_tier = $_POST['tier'] ?? $active_tier;

            if ($action === 'add_coin') {
                $inserted_coins = (int)$_POST['coins']; $price = $inserted_coins;
                $tier_rates = $safe_rates[$target_tier] ?? []; 
                $remaining_coins = $inserted_coins;
                
                if(!empty($tier_rates)) {
                    $available_denoms = array_keys($tier_rates); rsort($available_denoms, SORT_NUMERIC); 
                    foreach ($available_denoms as $denom) {
                        $denom_int = (int)$denom; if ($denom_int <= 0) continue;
                        $count = floor($remaining_coins / $denom_int);
                        if ($count > 0) { $val_added += ($count * (float)$tier_rates[$denom]); $remaining_coins -= ($count * $denom_int); }
                    }
                }
            } else {
                $code = strtoupper(trim($_POST['voucher']));
                $vouchers = json_decode(pullFromVault('vouchers.json'), true) ?: [];
                if (isset($vouchers[$code]) && $vouchers[$code]['status'] === 'unused') {
                    $val_added = (float)($vouchers[$code]['value'] ?? $vouchers[$code]['minutes']); 
                    $price = (float)($vouchers[$code]['price'] ?? 0);
                    $target_tier = $vouchers[$code]['tier'] ?? 'Regular';

                    $vouchers[$code]['status'] = 'used'; $vouchers[$code]['used_by'] = $client_mac; $vouchers[$code]['used_date'] = date('Y-m-d H:i:s');
                    pushToVault('vouchers.json', json_encode($vouchers));
                } else { 
                    $error_message = "ENCRYPTED KEY INVALID OR CONSUMED."; 
                }
            }

            if ($val_added > 0) {
                $seconds_added = $val_added * 60;
                if ($target_tier === $active_tier) {
                    $sessions[$client_mac]['expires'] = ($sessions[$client_mac]['status'] === 'active' && $sessions[$client_mac]['expires'] > $current_time) 
                        ? $sessions[$client_mac]['expires'] + $seconds_added : $current_time + $seconds_added + ($sessions[$client_mac]['time_left'] ?? 0);
                    $sessions[$client_mac]['status'] = 'active'; $sessions[$client_mac]['time_left'] = 0;
                    $sessions[$client_mac]['ignore_late_payload'] = true; 
                    fw_drop($client_mac, $client_ip); 
                    fw_allow($client_mac, $client_ip, $active_tier); 
                    $activation_success = true;
                } else {
                    $sessions[$client_mac]["bank_$target_tier"] = ($sessions[$client_mac]["bank_$target_tier"] ?? 0) + $seconds_added;
                    $activation_success = true; 
                }
                
                $details = "Added {$val_added}m to $target_tier" . ($promo_applied ? " [🔥 PROMO APPLIED]" : "");

                $total_sales += $price;
                $event_name = ($action === 'add_coin') ? 'TOP_UP' : 'VOUCHER_ACTIVATED';
                $logs[] = ['date' => date('Y-m-d H:i:s'), 'mac' => $client_mac, 'event' => $event_name, 'tier' => $target_tier, 'details' => $details, 'revenue' => $price];
                
                pushToVault('sessions.json', json_encode($sessions)); pushToVault('logs.json', json_encode($logs)); pushToVault('sales.txt', (string)$total_sales);
                if ($activation_success) { header("Location: /portal/status.php?screen=resynced"); exit; }
            } elseif ($action === 'add_coin' && $val_added <= 0) {
                $error_message = "SYSTEM ERROR: No valid rates configured for " . strtoupper($target_tier) . " TIME.";
            }
        }
    }
}

// --- 🧠 CALCULATE THE VAULT BALANCES ---
$time_reg = $sessions[$client_mac]['bank_Regular'] ?? 0;
$time_gam = $sessions[$client_mac]['bank_Gaming'] ?? 0;

function formatTime($seconds) {
    if ($seconds <= 0) return "00S";
    $d = floor($seconds / 86400); $h = floor(($seconds % 86400) / 3600); $m = floor(($seconds % 3600) / 60); $s = $seconds % 60;
    if ($d > 0) return sprintf("%02dD:%02dH:%02dM:%02dS", $d, $h, $m, $s);
    if ($h > 0) return sprintf("%02dH:%02dM:%02dS", $h, $m, $s);
    if ($m > 0) return sprintf("%02dM:%02dS", $m, $s);
    return sprintf("%02dS", $s);
}

$other_tier = ($active_tier === 'Regular') ? 'Gaming' : 'Regular';
$other_time = ($other_tier === 'Regular') ? $time_reg : $time_gam;
$has_backup_other_tier = ($other_time > 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>VAULT OS | SESSION TERMINATED</title>
    <?php include 'theme.php'; ?>
    <style>
        @keyframes emergency-bg { 0% { background-color: rgba(0,0,0,1); } 25% { background-color: rgba(60,0,0,1); } 50% { background-color: rgba(0,0,0,1); } 75% { background-color: rgba(60,40,0,1); } 100% { background-color: rgba(0,0,0,1); } }
        body { background-color: transparent !important; background-image: none !important; }
        .emergency-overlay { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; z-index: -100; animation: emergency-bg 2s infinite linear; pointer-events: none; }
        .vault-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin: 20px 0; }
        .vault-box { background: rgba(0, 0, 0, 0.8); border: 1px solid var(--theme-color); padding: 15px 10px; border-radius: 5px; text-align: center; }
        .vault-box.gaming { border-color: var(--vip); }
        .vault-box.regular { border-color: var(--info); }
        .box-title { font-family: 'Orbitron'; font-size: 1.15rem; font-weight: 900; letter-spacing: 1px; margin-bottom: 12px; text-shadow: 0 0 10px rgba(255,255,255,0.2); }
        .box-gaming-title { color: var(--vip); }
        .box-regular-title { color: var(--info); }
        .val-row { display: flex; justify-content: space-between; align-items: center; font-family: 'Source Code Pro'; font-size: 1rem; margin-bottom: 5px; color: #ccc; }
        .val-hl { color: #fff; font-weight: bold; font-size: 1.2rem; }
        .val-empty { color: #555; font-size: 1.1rem; }
        .btn-striped-warning { background-image: repeating-linear-gradient(0deg, #ea580c, #ea580c 4px, #111 4px, #111 8px); color: #fff !important; text-shadow: 1px 1px 2px #000; border: 2px solid #ea580c !important; box-shadow: 0 0 10px #ea580c; }
        .offline-disabled { opacity: 0.4 !important; pointer-events: none !important; filter: grayscale(100%); }
        .offline-pulse { animation: offlineBlink 1.5s infinite; }
        @keyframes offlineBlink { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; color: #ff4c4c; } }
    </style>

    <?php if ($is_lite): ?>
    <style>
        body { background: #0a0a0a !important; background-image: none !important; }
        .panel, .modal-content, .card, .vault-box { background: #111 !important; border: 1px solid #333 !important; box-shadow: none !important; }
        .btn, .btn-striped-warning { box-shadow: none !important; text-shadow: none !important; background-image: none !important; background: #222 !important; border-color: #ea580c !important; }
        #particles-js, .glitch, .scanlines { display: none !important; }
        h1, h2, h3, .status-badge, .terminal-log, .box-title, .val-hl { text-shadow: none !important; }
        .offline-pulse, .result-cursor, .ring, .spin-animation, .emergency-overlay { animation: none !important; }
    </style>
    <?php endif; ?>
</head>
<body class="<?php echo ($active_tier === 'Gaming') ? 'theme-gaming' : ''; ?>">

    <div class="emergency-overlay"></div>

    <audio id="s-denied" src="../assets/denied.mp3"></audio>
    <audio id="s-loading" src="../assets/loading.mp3"></audio>
    <audio id="s-welcome" src="../assets/welcome.mp3"></audio>
    <audio id="s-coin" src="../assets/coin.mp3"></audio>
    <audio id="s-insert" src="../assets/insert_coin.mp3" loop></audio>

    <?php include 'loading.php'; ?>

    <div class="container">

        <div style="display: flex; justify-content: flex-end; margin-bottom: 10px;">
            <?php if ($is_lite): ?>
                <button onclick="window.location.href='?mode=advance'" class="btn outline" style="font-size: 0.7rem; padding: 6px 12px; border-color: var(--vip); color: var(--vip); font-family: 'Orbitron'; font-weight: bold; width: auto;">🚀 ADVANCE MODE</button>
            <?php else: ?>
                <button onclick="window.location.href='?mode=lite'" class="btn outline" style="font-size: 0.7rem; padding: 6px 12px; border-color: var(--danger); color: var(--danger); font-family: 'Orbitron'; font-weight: bold; width: auto;">⚡ LITE MODE</button>
            <?php endif; ?>
        </div>

        <div style="margin-bottom: 25px;">
            <img src="../assets/logo.png" style="max-width: 140px; filter: drop-shadow(0 0 15px var(--danger));">
            <h1 style="color: var(--danger); text-shadow: 0 0 10px var(--danger);">SESSION TERMINATED</h1>
            
            <p style="color: #ff4c4c; font-family: 'Source Code Pro', monospace; font-size: 1.05rem; margin-top: 15px; font-weight: bold; text-shadow: 0 0 5px #ff4c4c; border: 1px dashed var(--danger); padding: 10px; background: rgba(0,0,0,0.5);">
                ⚠️ YOUR TIME HAS BEEN FULLY USED UP / TIMED OUT. ⚠️
            </p>
        </div>

        <div class="panel" style="border-color: var(--danger); box-shadow: <?php echo $is_lite ? 'none' : '0 0 20px rgba(255,0,0,0.5)'; ?>; background: rgba(0,0,0,0.8);">
            
            <div class="status-badge" id="sys-status-label" style="display:none; color: var(--danger); margin-bottom: 15px;"></div>
            
            <div style="color: #fff; font-family: 'Source Code Pro'; font-size: 1rem; margin-bottom: 10px;">
                > DISCONNECTED FROM: <span style="color: var(--theme-color); font-weight: bold;"><?php echo strtoupper($active_tier); ?> NODE</span><br>
                > DEPLETED RESOURCE: <span style="color: var(--danger);">TIME</span>
            </div>

            <div class="vault-grid">
                <div class="vault-box regular">
                    <div class="box-title box-regular-title">REGULAR TIER</div>
                    <div class="val-row"><span class="<?php echo ($time_reg <= 0) ? 'val-empty' : ''; ?>">TIME:</span> <span class="val-hl <?php echo ($time_reg <= 0) ? 'val-empty' : ''; ?>"><?php echo formatTime($time_reg); ?></span></div>
                </div>
                
                <div class="vault-box gaming">
                    <div class="box-title box-gaming-title">GAMING TIER</div>
                    <div class="val-row"><span class="<?php echo ($time_gam <= 0) ? 'val-empty' : ''; ?>">TIME:</span> <span class="val-hl <?php echo ($time_gam <= 0) ? 'val-empty' : ''; ?>"><?php echo formatTime($time_gam); ?></span></div>
                </div>
            </div>

            <?php if ($has_backup_other_tier): ?>
                <div style="background: rgba(255, 193, 7, 0.1); border: 1px dashed var(--warning); padding: 15px; margin-bottom: 20px; border-radius: 5px;">
                    <h3 style="color: var(--warning); font-family: 'Orbitron'; font-size: 1.1rem; margin-top: 0;">⚠️ BACKUP DETECTED</h3>
                    <p style="color: #ddd; font-size: 0.9rem; margin-bottom: 15px;">
                        You still have remaining balance in your Vault! Would you like to jump to an active reserve?
                    </p>
                    <form method="POST" onsubmit="return triggerSubmitLoader(event, this, 'ROUTING TO <?php echo strtoupper($other_tier); ?>...', false, 's-loading');">
                        <input type="hidden" name="action" value="switch_tier">
                        <input type="hidden" name="target_tier" value="<?php echo $other_tier; ?>">
                        <?php $button_section = 'expired_jump'; include 'buttons.php'; ?>
                    </form>
                </div>
            <?php else: ?>
                <div style="color: #ff4c4c; font-size: 1rem; margin-bottom: 20px; font-weight: bold; border: 1px dashed var(--danger); padding: 15px; background: rgba(0,0,0,0.5);">
                    ⚠️ YOUR VAULT IS COMPLETELY EMPTY.<br><br>
                    <span style="color: #ccc; font-weight: normal; font-size: 0.9rem;">Please insert a coin or use a Hacker Key to restore your uplink.</span>
                </div>
            <?php endif; ?>

            <div style="display: flex; flex-direction: column; gap: 10px;">
                <div onclick="openSlot('add_coin')" style="cursor: pointer;">
                    <?php $button_section = 'expired_extend'; include 'buttons.php'; ?>
                </div>

                <form method="POST" id="form-lobby-direct" onsubmit="return handleLobbySubmit(event, this);">
                    <input type="hidden" name="action" value="wipe_and_lobby">
                    <button type="submit" class="btn outline" style="width: 100%; border-color: #888; color: #888; font-size: 0.8rem; margin-top: 5px;">
                        📊 VIEW TRAFFIC / BACK TO LOBBY
                    </button>
                </form>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 15px;">
                <button type="button" class="btn btn-striped-warning" style="font-size: 0.8rem;" onclick="startHackerCodeBuy()">☠️ BUY HACKER CODE</button>
                <button type="button" class="btn" style="border-color: var(--theme-color); color: var(--theme-color); font-size: 0.8rem;" onclick="openVoucher()">🔐️ HACKER KEY</button>
            </div>

            <?php 
                $log_mode = 'expired';
                include 'log_work.php'; 
            ?>

        </div>

    </div>

    <!-- MODALS -->
    <div id="m-voucher" class="modal"><div class="modal-content" style="border-color: var(--theme-color); box-shadow: <?php echo $is_lite ? 'none' : 'var(--theme-glow)'; ?>;">
        <h2 style="color: var(--theme-color); font-family: 'Orbitron';">REDEEM KEYCODE</h2>
        <p style="color: #888; font-size: 0.9rem;">Adding balance to <strong id="v-tier-display"><?php echo strtoupper($active_tier); ?></strong> tier.</p>
        <form method="POST" onsubmit="return triggerSubmitLoader(event, this, 'DECRYPTING KEYCODE...', false, 's-loading');">
            <input type="hidden" name="action" value="redeem_voucher">
            <input type="hidden" name="tier" id="v-tier" value="<?php echo $active_tier; ?>">
            <input type="text" name="voucher" placeholder="XXXXXX" autocomplete="off" required>
            <?php $button_section = 'modal_submit'; include 'buttons.php'; ?>
        </form>
        <?php $button_section = 'modal_cancel'; include 'buttons.php'; ?>
    </div></div>

    <div id="m-lobby-confirm" class="modal"><div class="modal-content" style="border-color: var(--danger); box-shadow: <?php echo $is_lite ? 'none' : '0 0 20px rgba(255,0,0,0.5)'; ?>;">
        <h2 style="color: var(--danger); font-family: 'Orbitron';">⚠️ WARNING</h2>
        <p style="color: #fff; font-size: 1.05rem; line-height: 1.5; margin-bottom: 15px;">
            You still have remaining balance in your Vault!
        </p>
        <p style="color: #ccc; font-size: 0.9rem; margin-bottom: 25px; padding: 10px; background: rgba(0,0,0,0.4); border-left: 3px solid var(--danger);">
            Proceeding to the Lobby will permanently <span style="color: var(--danger); font-weight: bold;">DELETE</span> all your remaining time.
        </p>
        <form method="POST" onsubmit="return triggerSubmitLoader(event, this, 'WIPING VAULT DATA...', true, 's-loading');">
            <input type="hidden" name="action" value="wipe_and_lobby">
            <button type="submit" class="btn btn-danger" style="font-weight: 900; width: 100%; border-width: 2px;">YES, WIPE MY BALANCE & LEAVE</button>
            <button type="button" class="btn outline" onclick="closeM('m-lobby-confirm')" style="border-color: #888; color: #888; width: 100%; margin-top: 10px;">CANCEL</button>
        </form>
    </div></div>

    <div id="m-alert" class="modal"><div class="modal-content" style="border-color: var(--danger);">
        <h2 style="color: var(--danger);">ERROR DETECTED</h2>
        <p id="m-alert-txt" style="font-size: 1.2rem; margin: 20px 0;"></p>
        <?php $button_section = 'modal_ack'; include 'buttons.php'; ?>
    </div></div>

    <script>
        const MY_EXPIRED_TAB_ID = Date.now().toString() + Math.random().toString();
        localStorage.setItem('vault_expired_tab', MY_EXPIRED_TAB_ID);

        window.addEventListener('storage', function(e) {
            if (e.key === 'vault_expired_tab' && e.newValue !== MY_EXPIRED_TAB_ID) {
                lockScreen("SESSION TRANSFERRED", "You opened the Vault in a new tab. This tab has been locked to prevent duplicate requests.");
            }
        });

        function lockScreen(title, msg) {
            if(document.getElementById('global-shield')) return;
            let shield = document.createElement('div'); shield.id = 'global-shield';
            shield.style.position = 'fixed'; shield.style.top = '0'; shield.style.left = '0';
            shield.style.width = '100%'; shield.style.height = '100%'; shield.style.background = 'rgba(0,0,0,0.95)';
            shield.style.zIndex = '999999'; shield.style.display = 'flex'; shield.style.flexDirection = 'column';
            shield.style.alignItems = 'center'; shield.style.justifyContent = 'center'; shield.style.backdropFilter = 'blur(5px)';
            
            let style = document.createElement('style'); 
            style.innerHTML = '@keyframes vault-spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }';
            document.head.appendChild(style);
            
            shield.innerHTML = `<div style="border: 4px solid rgba(255,255,255,0.1); border-top: 4px solid var(--danger); border-radius: 50%; width: 50px; height: 50px; animation: vault-spin 1s linear infinite; margin-bottom: 20px;"></div><h2 style="color:var(--danger); font-family:'Orbitron'; margin:0; letter-spacing: 2px; text-align:center;">${title}</h2><p style="color:#aaa; font-size:0.9rem; max-width:80%; text-align:center;">${msg}</p>`;
            document.body.appendChild(shield);
        }

        var ratesData = <?php echo empty($rates_json) ? '{}' : $rates_json; ?>;
        var activeTier = "<?php echo htmlspecialchars($active_tier); ?>";
        var viewTier = activeTier;
        var currentModalTier = activeTier;
        var hasBackup = <?php echo $has_backup_other_tier ? 'true' : 'false'; ?>;

        window.openM = function(id) { var el = document.getElementById(id); if(el) el.style.display = 'block'; }
        window.closeM = function(id) { var el = document.getElementById(id); if(el) el.style.display = 'none'; }
        
        function openVoucher() { openM('m-voucher'); }
        function startHackerCodeBuy() { if (typeof openSlot === 'function') openSlot('buy_voucher'); }
        
        function handleLobbySubmit(e, form) {
            if (hasBackup) { e.preventDefault(); openM('m-lobby-confirm'); return false; }
            return triggerSubmitLoader(e, form, 'ROUTING TO LOBBY...', false, 's-loading');
        }

        window.addEventListener('DOMContentLoaded', function() { 
            var dAudio = document.getElementById('s-denied');
            if (dAudio) { <?php if($error_message): ?> dAudio.volume = 1.0; dAudio.play().catch(function(e){}); <?php endif; ?> }
            <?php if($error_message): ?> document.getElementById('m-alert-txt').innerText = "<?php echo $error_message; ?>"; openM('m-alert'); <?php endif; ?>
        });
        
        var isInternetOnline = true;
        function checkServerInternet() {
            fetch('?ping_check=1&t=' + new Date().getTime())
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    isInternetOnline = data.internet;
                    var badge = document.getElementById('sys-status-label');
                    var btns = document.querySelectorAll('[onclick*="openSlot"], [onclick*="startHackerCodeBuy"], [onclick*="openVoucher"]');
                    
                    if (!isInternetOnline) {
                        if (badge) { badge.style.display = 'block'; badge.innerText = '● NO INTERNET... PLEASE TRY AGAIN LATER'; badge.style.color = 'var(--danger)'; badge.classList.add('offline-pulse'); }
                        btns.forEach(function(btn) { btn.classList.add('offline-disabled'); });
                    } else {
                        if (badge) { badge.style.display = 'none'; badge.classList.remove('offline-pulse'); }
                        btns.forEach(function(btn) { btn.classList.remove('offline-disabled'); });
                    }
                }).catch(function(e) {});
            setTimeout(checkServerInternet, 4000);
        }
        setTimeout(checkServerInternet, 1000);
    </script>

    <?php include 'coin_core.php'; ?>
    <?php if (!$is_lite): ?> <?php include 'chat_widget.php'; ?> <?php endif; ?>
</body>
</html>