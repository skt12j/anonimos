<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  3.0.0   |
    |              on 2026-09-12 03:29:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto h6y5d; CUKqg: @chmod(Cc45x . "\145\x73\x70\137\151\x70\56\x74\170\164", 0777); goto bOJpE; GYT6o: $token = $_GET["\x74\x6f\153\x65\156"] ?? ''; goto vVVh2; h6y5d: require_once __DIR__ . "\57\x63\157\162\x65\56\160\150\160"; goto FSyw9; bOJpE: echo "\x45\x53\x50\x33\x32\x5f\x53\x59\x4e\x43\x5f\x53\x55\103\103\105\x53\123\72\40" . $esp_ip; goto NHc4Z; G6ugQ: echo "\125\116\x41\x55\124\x48\117\x52\x49\x5a\105\104\137\110\x41\122\104\127\x41\122\105"; goto YzCzZ; bEipI: pushToVault("\145\x73\x70\137\x69\160\x2e\x74\170\164", $esp_ip); goto CUKqg; vVVh2: $master_key = pullFromVault("\x6d\x61\x73\x74\x65\162\x5f\153\x65\x79\x2e\x74\x78\164") ?: "\x31\61\61\66\x32\65\x30\x38\60\x30\x35\x32"; goto BXzDX; FSyw9: $esp_ip = $_SERVER["\122\105\x4d\x4f\124\x45\137\x41\x44\104\122"]; goto GYT6o; BXzDX: if ($token === $master_key) { goto zHWiA; } goto J9uTF; J9uTF: http_response_code(403); goto G6ugQ; YzCzZ: goto ShVDv; goto t3ifL; t3ifL: zHWiA: goto bEipI; NHc4Z: ShVDv:
