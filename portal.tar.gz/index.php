<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  3.0.0   |
    |              on 2026-09-12 00:45:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 header("\114\157\143\x61\x74\x69\157\156\72\x20\x2f\x70\x6f\162\x74\141\x6c\x2f"); exit;
