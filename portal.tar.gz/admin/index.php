<?php
// admin/index.php - OPENWRT RAM-DISK EDITION (Mission Control)
require_once '../core.php';

$current_master_key = pullFromVault('master_key.txt') ?: "111625080052";
$current_esp_ip = pullFromVault('esp_ip.txt') ?: "192.168.1.10";

// ==========================================
// 🛡️ SYSTEM OVERRIDE HANDLER
// ==========================================
$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['system_action'])) {
    $action = $_POST['system_action'];

    if ($action === 'update_hardware') {
        $new_key = trim($_POST['new_key'] ?? '');
        $new_ip = trim($_POST['new_ip'] ?? '');
        
        if (!empty($new_key) && !empty($new_ip)) {
            pushToVault('master_key.txt', $new_key);
            pushToVault('esp_ip.txt', $new_ip);
            
            $current_master_key = $new_key;
            $current_esp_ip = $new_ip;
            $message = "✅ SYSTEM_UPLINK: HARDWARE CONFIGURATION SAVED.";
        } else {
            $message = "❌ ERROR: CRITICAL FIELDS CANNOT BE EMPTY.";
        }
    }

    elseif ($action === 'backup') {
        $backup_file = '/tmp/vault_assets_backup_' . date('Ymd_His') . '.tar.gz';
        exec("tar -czf $backup_file -C /etc/pisowifi/db .");
        
        if (file_exists($backup_file)) {
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($backup_file) . '"');
            header('Content-Length: ' . filesize($backup_file));
            readfile($backup_file);
            unlink($backup_file); 
            exit;
        } else {
            $message = "❌ ERROR: FAILED TO GENERATE BACKUP ARCHIVE.";
        }
    }

    elseif ($action === 'upload_config' && isset($_FILES['config_file'])) {
        $target_dir = "/etc/pisowifi/db/";
        $filename = basename($_FILES["config_file"]["name"]);
        $target_path = $target_dir . $filename;
        
        if (pathinfo($filename, PATHINFO_EXTENSION) === 'json') {
            if (move_uploaded_file($_FILES["config_file"]["tmp_name"], $target_path)) {
                $message = "✅ SYSTEM_UPLINK: $filename INSTALLED SUCCESSFULLY.";
            } else {
                $message = "❌ ERROR: UPLINK FAILED. CHECK PERMISSIONS.";
            }
        } else {
            $message = "❌ ERROR: INVALID ENCRYPTION TYPE (JSON ONLY).";
        }
    }

    elseif ($action === 'wipe_data') {
        $wipe_type = $_POST['wipe_type'] ?? '';
        $targets = $_POST['targets'] ?? [];
        $wiped_list = [];

        $is_all = ($wipe_type === 'all');

        if ($is_all || in_array('sessions', $targets)) {
            pushToVault('sessions.json', json_encode([]));
            $wiped_list[] = "Sessions";
        }
        if ($is_all || in_array('sales', $targets)) {
            pushToVault('transactions.json', json_encode([]));
            pushToVault('sales.txt', "");
            $wiped_list[] = "Sales & Transactions";
        }
        if ($is_all || in_array('vouchers', $targets)) {
            pushToVault('vouchers.json', json_encode([]));
            $wiped_list[] = "Vouchers";
        }
        if ($is_all || in_array('chats', $targets)) {
            pushToVault('chats.json', json_encode([]));
            pushToVault('chat_names.json', json_encode([]));
            $wiped_list[] = "Chat Records";
        }
        if ($is_all || in_array('logs', $targets)) {
            pushToVault('logs.json', json_encode([]));
            $wiped_list[] = "System Logs";
        }
        if ($is_all || in_array('blocked', $targets)) {
            pushToVault('blocked.json', json_encode([]));
            $wiped_list[] = "Blocked MACs";
        }

        if (empty($wiped_list)) {
            $message = "⚠️ NO DATABASES SELECTED. ABORTING WIPE.";
        } else {
            $message = "☢️ SYSTEM WIPED: " . implode(", ", $wiped_list) . " HAVE BEEN PURGED.";
        }
    }

    // OpenWrt does not use sudo to reboot
    elseif ($action === 'reboot') {
        $message = "⚠️ SYSTEM REBOOTING... PLEASE WAIT 60 SECONDS TO RECONNECT.";
        exec("reboot > /dev/null 2>&1 &");
    }
}

require_once 'header.php';
?>

<style>
    #wipeModal { display: none; position: fixed; z-index: 10000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.85); backdrop-filter: blur(8px); justify-content: center; align-items: center; opacity: 0; transition: opacity 0.3s ease; }
    #wipeModal.active { display: flex; opacity: 1; }
    .modal-content { background: #050a15; border: 2px solid var(--danger); padding: 25px; border-radius: 8px; width: 450px; max-width: 90%; box-shadow: 0 0 30px rgba(255,0,0,0.2), inset 0 0 15px rgba(255,0,0,0.1); position: relative; transform: scale(0.9); transition: transform 0.3s ease; }
    #wipeModal.active .modal-content { transform: scale(1); }
    .modal-content h2 { color: var(--danger); font-family: 'Orbitron'; text-align: center; margin-bottom: 20px; text-shadow: 0 0 10px var(--danger); }
    .close-modal { position: absolute; top: 15px; right: 15px; background: none; border: none; color: #888; font-size: 1.5rem; cursor: pointer; transition: 0.2s; }
    .close-modal:hover { color: #fff; transform: scale(1.2); }
    .checkbox-container { display: flex; flex-direction: column; gap: 12px; margin-bottom: 25px; background: rgba(0,0,0,0.5); padding: 15px; border-radius: 5px; border: 1px solid #333; }
    .checkbox-item { display: flex; align-items: center; gap: 10px; cursor: pointer; }
    .checkbox-item input[type="checkbox"] { width: 18px; height: 18px; accent-color: var(--danger); cursor: pointer; }
    .checkbox-item span { color: #ccc; font-family: 'Rajdhani'; font-size: 1.1rem; }
    .checkbox-item .subtext { font-size: 0.8rem; color: #666; font-family: 'Source Code Pro'; margin-left: 5px; }
    .modal-btn-group { display: flex; flex-direction: column; gap: 10px; }
</style>

<div id="wipeModal">
    <div class="modal-content">
        <button class="close-modal" onclick="closeModal()">✖</button>
        <h2>☢️ SELECT DATA TO PURGE</h2>
        
        <form method="POST" id="wipeForm">
            <input type="hidden" name="system_action" value="wipe_data">
            
            <div class="checkbox-container">
                <label class="checkbox-item"><input type="checkbox" name="targets[]" value="sessions"><span>Connected Sessions</span></label>
                <label class="checkbox-item"><input type="checkbox" name="targets[]" value="sales"><span>Sales & Transactions</span></label>
                <label class="checkbox-item"><input type="checkbox" name="targets[]" value="chats"><span>Live Chat Logs</span></label>
                <label class="checkbox-item"><input type="checkbox" name="targets[]" value="vouchers"><span>Generated Vouchers</span></label>
                <label class="checkbox-item"><input type="checkbox" name="targets[]" value="logs"><span>System Event Logs</span></label>
                <label class="checkbox-item"><input type="checkbox" name="targets[]" value="blocked"><span>Blocked Devices</span></label>
            </div>

            <div class="modal-btn-group">
                <button type="submit" name="wipe_type" value="selected" class="btn" style="border: 1px solid var(--warning); color: var(--warning); padding: 12px; font-weight: bold; font-family: 'Orbitron'; background: rgba(245,158,11,0.1);">
                    🧹 WIPE SELECTED FILES
                </button>
                <button type="submit" name="wipe_type" value="all" class="btn btn-danger" style="padding: 15px; font-weight: 900; font-family: 'Orbitron'; font-size: 1.2rem; box-shadow: 0 0 15px var(--danger);" onclick="return confirm('☢️ FINAL WARNING: This will permanently vaporize ALL databases listed above. Are you absolutely certain?');">
                    🔥 NUKE EVERYTHING 🔥
                </button>
            </div>
        </form>
    </div>
</div>

<div class="container">

    <div style="margin-bottom: 30px;">
        <h1 style="color: var(--info); text-shadow: 0 0 10px var(--info);">COMMAND CENTER <span id="sync-pulse" style="font-size:0.5em; color:var(--success);">●</span></h1>
        <p style="color: #888; font-family: 'Source Code Pro';">NODAL_STATUS: ONLINE | SECURITY_LEVEL: ROOT</p>
    </div>

    <!-- Reduced from 4 columns to 3 since Data Transfer was removed -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 30px;">
        
        <div class="card" style="border-color: var(--success); text-align: center;">
            <h3 style="color: #666; font-size: 0.8rem; font-family: 'Orbitron';">TOTAL REVENUE</h3>
            <div id="ajax-revenue" style="font-size: 2.8rem; color: var(--success); font-family: 'Orbitron'; text-shadow: 0 0 15px var(--success); transition: 0.3s;">₱0.00</div>
        </div>

        <div class="card" style="border-color: var(--info); text-align: center; padding: 15px;">
            <h3 style="color: #666; font-size: 0.8rem; font-family: 'Orbitron'; margin-bottom:10px;">NETWORK NODES (<span id="ajax-nodes-total">0</span>)</h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 5px;">
                <div style="background: rgba(0,243,255,0.1); border-radius: 4px; padding: 5px;">
                    <div style="font-size: 0.7rem; color: var(--info);">ACTIVE</div>
                    <div id="ajax-nodes-active" style="font-size: 1.8rem; color: var(--info); font-family: 'Orbitron'; font-weight:bold;">0</div>
                </div>
                <div style="background: rgba(16,185,129,0.1); border-radius: 4px; padding: 5px;">
                    <div style="font-size: 0.7rem; color: var(--success);">PASSIVE</div>
                    <div id="ajax-nodes-passive" style="font-size: 1.8rem; color: var(--success); font-family: 'Orbitron'; font-weight:bold;">0</div>
                </div>
                <div style="background: rgba(255,76,76,0.1); border-radius: 4px; padding: 5px;">
                    <div style="font-size: 0.7rem; color: var(--danger);">PAUSED</div>
                    <div id="ajax-nodes-paused" style="font-size: 1.8rem; color: var(--danger); font-family: 'Orbitron'; font-weight:bold;">0</div>
                </div>
            </div>
        </div>

        <div class="card" style="border-color: var(--vip); text-align: center;">
            <h3 style="color: #666; font-size: 0.8rem; font-family: 'Orbitron';">VOUCHER FLUX</h3>
            <div id="ajax-vouchers" style="font-size: 2.8rem; color: var(--vip); font-family: 'Orbitron'; text-shadow: 0 0 15px var(--vip); transition: 0.3s;">
                0 <span style="font-size: 1rem; color: #444;">/ 0</span>
            </div>
        </div>
    </div>
    
    <div class="card" style="border-color: var(--info); margin-bottom: 30px; background: rgba(0, 243, 255, 0.02); border-left-width: 5px;">
        <h3 style="color: var(--info); font-family: 'Orbitron'; margin-bottom: 15px;">HARDWARE CONFIG</h3>
        
        <form method="POST" style="margin: 0; display: flex; flex-direction: column; gap: 15px;">
            <input type="hidden" name="system_action" value="update_hardware">
            
            <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                <div style="flex-grow: 1; min-width: 200px;">
                    <label style="color: #ccc; font-family: 'Source Code Pro'; font-size: 0.8rem; display: block; margin-bottom: 5px;">ESP32 STATIC IP:</label>
                    <input type="text" name="new_ip" value="<?php echo htmlspecialchars($current_esp_ip); ?>" style="width: 100%; padding: 10px; background: #000; border: 1px solid var(--info); color: #fff; font-family: monospace; font-size: 1rem; text-align: center; letter-spacing: 2px; box-sizing: border-box;" required>
                </div>
                
                <div style="flex-grow: 2; min-width: 200px;">
                    <label style="color: #ccc; font-family: 'Source Code Pro'; font-size: 0.8rem; display: block; margin-bottom: 5px;">API MASTER KEY:</label>
                    <input type="text" name="new_key" value="<?php echo htmlspecialchars($current_master_key); ?>" style="width: 100%; padding: 10px; background: #000; border: 1px solid var(--info); color: #fff; font-family: monospace; font-size: 1rem; text-align: center; letter-spacing: 2px; box-sizing: border-box;" required>
                </div>
            </div>
            
            <button type="submit" class="btn btn-info" style="margin-top: 10px; padding: 12px; width: 100%; font-size: 0.9rem; background: var(--info); color: #000;">UPDATE CONFIGURATIONS</button>
        </form>
    </div>

    <div class="card" style="border-color: var(--danger); margin-bottom: 30px; background: rgba(255, 76, 76, 0.05); border-left-width: 5px;">
        <h3 style="color: var(--danger); font-family: 'Orbitron'; margin-bottom: 15px;">DANGER ZONE & MAINTENANCE</h3>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
            <form method="POST" style="margin: 0;">
                <input type="hidden" name="system_action" value="backup">
                <button type="submit" class="btn btn-success" style="width: 100%; height: 50px;">📥 DOWNLOAD BACKUP</button>
            </form>

            <div style="position: relative; height: 50px;">
                <form method="POST" enctype="multipart/form-data" id="uploadForm">
                    <input type="hidden" name="system_action" value="upload_config">
                    <input type="file" name="config_file" id="configInput" style="display:none;" onchange="this.form.submit()">
                    <button type="button" class="btn" style="width:100%; height: 50px; font-size: 0.8rem; border-style: dashed;" onclick="document.getElementById('configInput').click()">📡 UPLOAD .JSON DB</button>
                </form>
            </div>

            <button type="button" class="btn btn-danger" onclick="openModal()" style="width: 100%; height: 50px; font-weight: bold; font-family: 'Orbitron'; box-shadow: 0 0 10px var(--danger);">🔥 WIPE DATA</button>

            <form method="POST" style="margin: 0;" onsubmit="return confirm('Are you sure you want to reboot the Vault OS Router? The network will go down for roughly 60 seconds.');">
                <input type="hidden" name="system_action" value="reboot">
                <button type="submit" class="btn btn-warning" style="width: 100%; height: 50px; font-weight: bold; color: #000;">🔄 REBOOT SYSTEM</button>
            </form>
        </div>
        
        <?php if($message): ?>
            <p style="color: #fff; font-family: 'Source Code Pro'; font-size: 0.9rem; margin-top: 15px; padding: 10px; background: rgba(0,0,0,0.8); border-left: 3px solid var(--info);">
                <?php echo $message; ?>
            </p>
        <?php endif; ?>
    </div>

    <div class="card">
        <h3 style="color: var(--info); margin-bottom: 15px; font-family: 'Orbitron';">RECENT SYSTEM ACTIVITY</h3>
        <div style="overflow-x: auto;">
            <table>
                <thead>
                    <tr>
                        <th style="text-align: left;">TIMESTAMP</th>
                        <th style="text-align: left;">MAC_ADDRESS</th>
                        <th style="text-align: left;">EVENT_TYPE</th>
                        <th style="text-align: left;">DATA_DETAILS</th>
                    </tr>
                </thead>
                <tbody id="ajax-logs" style="font-family: 'Rajdhani'; font-size: 1.1rem;">
                    <tr><td colspan='4' style='text-align: center; color: #444; padding: 20px;'>SYNCHRONIZING TERMINAL...</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    function openModal() { document.getElementById('wipeModal').classList.add('active'); }
    function closeModal() { document.getElementById('wipeModal').classList.remove('active'); }

    function fetchLiveStats() {
        fetch('api_core.php?action=stats')
            .then(response => response.json())
            .then(data => {
                document.getElementById('ajax-revenue').innerText = "₱" + data.revenue;
                document.getElementById('ajax-nodes-total').innerText = data.nodes.total;
                document.getElementById('ajax-nodes-active').innerText = data.nodes.active;
                document.getElementById('ajax-nodes-passive').innerText = data.nodes.passive;
                document.getElementById('ajax-nodes-paused').innerText = data.nodes.paused;
                document.getElementById('ajax-vouchers').innerHTML = data.used_vouchers + " <span style='font-size: 1rem; color: #444;'>/ " + data.total_vouchers + "</span>";
                
                let logHtml = '';
                if(data.logs.length === 0) {
                    logHtml = "<tr><td colspan='4' style='text-align: center; color: #444; padding: 20px;'>NO LOG DATA DETECTED.</td></tr>";
                } else {
                    data.logs.forEach(log => {
                        let eventColor = log.event.includes('COIN') ? 'var(--success)' : 'var(--vip)';
                        logHtml += `<tr style='border-bottom: 1px solid rgba(255,255,255,0.05);'>
                                        <td style='color: #666; padding: 12px 0;'>${log.date}</td>
                                        <td style='font-family: "Source Code Pro"; font-size: 0.85rem; color: #aaa;'>${log.mac}</td>
                                        <td style='color: ${eventColor}; font-weight: bold;'>${log.event}</td>
                                        <td style='color: #ccc;'>${log.details}</td>
                                    </tr>`;
                    });
                }
                document.getElementById('ajax-logs').innerHTML = logHtml;

                let pulse = document.getElementById('sync-pulse');
                pulse.style.opacity = '1';
                setTimeout(() => pulse.style.opacity = '0.2', 500);
            })
            .catch(err => console.error("SYNC ERROR:", err));
    }

    fetchLiveStats();
    setInterval(fetchLiveStats, 3000);
</script>
</body></html>