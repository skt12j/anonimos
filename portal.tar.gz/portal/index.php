<?php
// portal/index.php - OPENWRT RAM-DISK EDITION (Time Mode Only)
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }

// 🔥 LITE MODE TOGGLE ENGINE 🔥
if (isset($_GET['mode'])) {
    $new_mode = ($_GET['mode'] === 'lite') ? 'lite' : 'advance';
    setcookie('vault_mode', $new_mode, time() + (86400 * 30), "/"); // Save preference for 30 days!
    header("Location: index.php");
    exit;
}
$vault_mode = $_COOKIE['vault_mode'] ?? 'advance';
$is_lite = ($vault_mode === 'lite');

if (isset($_GET['ping_check'])) {
    header('Content-Type: application/json');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    $fp = @fsockopen("1.1.1.1", 53, $errno, $errstr, 1);
    if ($fp) { fclose($fp); echo json_encode(['internet' => true]); } 
    else { echo json_encode(['internet' => false]); }
    exit;
}

$client_ip = $_SERVER['REMOTE_ADDR'];
$client_mac = getClientMac($client_ip);

// =======================================================
// 👑 PHASE 3: WISP SUBSCRIBER INTERCEPTOR 👑
// =======================================================
$subs_db = DB_DIR . 'subscriptions.json';
if (file_exists($subs_db)) {
    $subs_data = json_decode(file_get_contents($subs_db), true) ?: [];
    foreach ($subs_data as $sub) {
        if (($sub['status'] ?? '') === 'active' && in_array($client_mac, $sub['macs'] ?? [])) {
            if (!isset($_GET['force_lobby'])) {
                header("Location: sub_status.php");
                exit;
            }
        }
    }
}

$blocked_file = DB_DIR . 'blocked.json';
if (file_exists($blocked_file)) {
    $blocked = json_decode(file_get_contents($blocked_file), true);
    if (isset($blocked[$client_mac])) { header("Location: /portal/banned.php"); exit; }
}

// =======================================================
// 👑 PHASE 4: PISO WIFI AUTO-HEALER (IP DRIFT FIX) 👑
// =======================================================
$sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
$current_time = time();

if (isset($sessions[$client_mac])) {
    $current_status = $sessions[$client_mac]['status'] ?? '';
    if ($current_status === 'expired') { header("Location: /portal/expired.php"); exit; }
    
    if ($current_status === 'active' || $current_status === 'paused') { 
        
        $saved_ip = $sessions[$client_mac]['ip'] ?? '';
        if ($saved_ip !== '' && $saved_ip !== $client_ip) {
            fw_drop($client_mac, $saved_ip);
            fw_allow($client_mac, $client_ip, $sessions[$client_mac]['tier'] ?? 'Regular');
            
            $sessions[$client_mac]['ip'] = $client_ip;
            pushToVault('sessions.json', json_encode($sessions));
        }

        header("Location: /portal/status.php"); 
        exit; 
    }
}

$error_message = '';
$activation_success = false;
$bought_voucher_code = ''; 
$bought_voucher_val = 0;
$bought_voucher_price = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if (isset($_SESSION['last_post_time']) && (time() - $_SESSION['last_post_time']) < 5) {
        $error_message = "ANTI-SPAM: PLEASE DO NOT REFRESH THE PAGE DURING TRANSACTIONS.";
        $action = 'blocked_by_shield';
    } else {
        $_SESSION['last_post_time'] = time();
    }

    $logs = json_decode(pullFromVault('logs.json'), true) ?: [];
    $sales_raw = pullFromVault('sales.txt');
    $total_sales = is_numeric($sales_raw) ? (float)$sales_raw : 0.00;

    $rates_data = json_decode(pullFromVault('rates.json'), true) ?: [];
    $safe_rates = [
        'Time' => [
            'Regular' => $rates_data['Time']['Regular'] ?? ($rates_data['Regular'] ?? ['1' => 10, '5' => 60, '10' => 130]),
            'Gaming' => $rates_data['Time']['Gaming'] ?? ($rates_data['Gaming'] ?? ['1' => 10, '5' => 60, '10' => 130])
        ]
    ];

    if ($action === 'buy_eload' && isset($_POST['coins']) && (int)$_POST['coins'] > 0) {
        $inserted_coins = (int)$_POST['coins'];
        $el_num = $_POST['eload_num'] ?? '';
        $el_net = $_POST['eload_net'] ?? '';
        $el_code = $_POST['eload_code'] ?? 'REGULAR';
        $el_base = (float)($_POST['eload_base'] ?? 0);

        $queue_file = DB_DIR . 'eload_queue.json';
        $queue = file_exists($queue_file) ? json_decode(file_get_contents($queue_file), true) : [];
        
        $ref_id = "EL-" . strtoupper(substr(uniqid(), -6));
        $queue[$ref_id] = [
            'number' => $el_num,
            'network' => $el_net,
            'code' => $el_code,
            'amount' => $el_base,
            'paid' => $inserted_coins,
            'status' => 'pending',
            'mac' => $client_mac,
            'date' => date('Y-m-d H:i:s')
        ];
        
        pushToVault('eload_queue.json', json_encode($queue));
        
        $total_sales += $inserted_coins;
        $logs[] = ['date' => date('Y-m-d H:i:s'), 'mac' => $client_mac, 'event' => 'ELOAD_PAID', 'tier' => 'E-Load', 'details' => "Paid ₱$inserted_coins for $el_net ($el_num) - $el_code", 'revenue' => (float)$inserted_coins];
        
        pushToVault('logs.json', json_encode($logs)); 
        pushToVault('sales.txt', (string)$total_sales);
        
        $error_message = "✅ PAYMENT SECURED! Your E-Load request ($el_code) for $el_num is now queuing for processing.";
    }
    elseif ($action === 'buy_voucher' && isset($_POST['coins']) && (int)$_POST['coins'] > 0) {
        $inserted_coins = (int)$_POST['coins'];
        $tier = $_POST['tier'] ?? 'Regular';
        
        $tier_rates = $safe_rates['Time'][$tier] ?? [];
        $val_added = 0; $remaining_coins = $inserted_coins;
        
        if(!empty($tier_rates)) {
            $available_denoms = array_keys($tier_rates); rsort($available_denoms, SORT_NUMERIC); 
            foreach ($available_denoms as $denom) {
                $denom_int = (int)$denom; if ($denom_int <= 0) continue;
                $count = floor($remaining_coins / $denom_int);
                if ($count > 0) { $val_added += ($count * (float)$tier_rates[$denom]); $remaining_coins -= ($count * $denom_int); }
            }
        }

        if ($val_added > 0) {
            $vouchers = json_decode(pullFromVault('vouchers.json'), true) ?: [];
            $new_code = "RJ-" . substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 6);
            
            $vouchers[$new_code] = [
                'mode' => 'Time', 'value' => (float)$val_added, 'tier' => (string)$tier, 'price' => (float)$inserted_coins,
                'status' => 'unused', 'created_date' => date('Y-m-d H:i:s'), 'used_by' => null, 'used_date' => null, 'creator_mac' => $client_mac
            ];
            
            $total_sales += $inserted_coins;
            $logs[] = ['date' => date('Y-m-d H:i:s'), 'mac' => $client_mac, 'event' => 'VOUCHER_BOUGHT', 'tier' => $tier, 'details' => "Bought: $new_code | ₱$inserted_coins (Added {$val_added}m)", 'revenue' => (float)$inserted_coins];

            pushToVault('vouchers.json', json_encode($vouchers));
            pushToVault('logs.json', json_encode($logs)); pushToVault('sales.txt', (string)$total_sales);
            
            $bought_voucher_code = $new_code; $bought_voucher_val = $val_added; $bought_voucher_price = $inserted_coins;
        } else { $error_message = "SYSTEM ERROR: No valid rates configured for " . strtoupper($tier) . " TIME."; }
    }
    elseif ($action === 'insert_coin' && isset($_POST['coins']) && (int)$_POST['coins'] > 0) {
        $inserted_coins = (int)$_POST['coins'];
        $tier = $_POST['tier'] ?? 'Regular';
        
        $tier_rates = $safe_rates['Time'][$tier] ?? [];
        $val_added = 0; $remaining_coins = $inserted_coins;
        
        if(!empty($tier_rates)) {
            $available_denoms = array_keys($tier_rates); rsort($available_denoms, SORT_NUMERIC); 
            foreach ($available_denoms as $denom) {
                $denom_int = (int)$denom; if ($denom_int <= 0) continue;
                $count = floor($remaining_coins / $denom_int);
                if ($count > 0) { $val_added += ($count * (float)$tier_rates[$denom]); $remaining_coins -= ($count * $denom_int); }
            }
        }
        
        $promo = json_decode(pullFromVault('promo.json'), true);
        $coin_history_str = $_POST['coin_history'] ?? '';
        $coin_history_arr = $coin_history_str !== '' ? explode(',', $coin_history_str) : [$inserted_coins];
        $promo_applied = false;

        if ($promo && isset($promo['status']) && $promo['status'] === 'on') {
            if (in_array((string)$promo['target_amount'], $coin_history_arr)) {
                $val_added += (int)$promo['bonus_minutes'];
                $promo_applied = true;
            }
        }

        if ($val_added > 0) {
            $existing_data = $sessions[$client_mac] ?? [];
            
            $sessions[$client_mac] = [
                'ip' => $client_ip, 'tier' => $tier, 'status' => 'active', 'active_mode' => 'Time', 'time_left' => 0,
                'bank_Regular' => $existing_data['bank_Regular'] ?? 0,
                'bank_Gaming' => $existing_data['bank_Gaming'] ?? 0 
            ];

            $sessions[$client_mac]['expires'] = $current_time + ($val_added * 60);
            $sessions[$client_mac]['ignore_late_payload'] = true; 
            
            $total_sales += $inserted_coins;
            $details = "Added {$val_added}m" . ($promo_applied ? " [🔥 PROMO APPLIED]" : "");
            $logs[] = ['date' => date('Y-m-d H:i:s'), 'mac' => $client_mac, 'event' => 'COIN_INSERT', 'tier' => $tier, 'details' => "Inserted: ₱$inserted_coins | $details", 'revenue' => (float)$inserted_coins];

            pushToVault('sessions.json', json_encode($sessions));
            pushToVault('logs.json', json_encode($logs)); pushToVault('sales.txt', (string)$total_sales);
            
            fw_drop($client_mac, $client_ip); 
            fw_allow($client_mac, $client_ip, $tier);
            $activation_success = true;
        } else { $error_message = "SYSTEM ERROR: No valid rates configured."; }
    }
    elseif ($action === 'redeem_voucher' && isset($_POST['voucher']) && !empty($_POST['voucher'])) {
        $code = strtoupper(trim($_POST['voucher']));
        $vouchers = json_decode(pullFromVault('vouchers.json'), true) ?: [];
        
        if (isset($vouchers[$code]) && $vouchers[$code]['status'] === 'unused') {
            $val_added = (float)($vouchers[$code]['value'] ?? $vouchers[$code]['minutes']); 
            $price = (float)($vouchers[$code]['price'] ?? 0);
            $tier = $vouchers[$code]['tier'] ?? 'Regular';

            $vouchers[$code]['status'] = 'used'; $vouchers[$code]['used_by'] = $client_mac; $vouchers[$code]['used_date'] = date('Y-m-d H:i:s');
            
            $existing_data = $sessions[$client_mac] ?? [];
            $sessions[$client_mac] = [
                'ip' => $client_ip, 'tier' => $tier, 'status' => 'active', 'active_mode' => 'Time', 'time_left' => 0,
                'bank_Regular' => $existing_data['bank_Regular'] ?? 0,
                'bank_Gaming' => $existing_data['bank_Gaming'] ?? 0
            ];

            $sessions[$client_mac]['expires'] = $current_time + ($val_added * 60);
            $sessions[$client_mac]['ignore_late_payload'] = true; 

            $total_sales += $price;
            $logs[] = ['date' => date('Y-m-d H:i:s'), 'mac' => $client_mac, 'event' => 'VOUCHER_ACTIVATED', 'tier' => $tier, 'details' => "Code: $code | Added {$val_added}m", 'revenue' => $price];

            pushToVault('vouchers.json', json_encode($vouchers)); pushToVault('sessions.json', json_encode($sessions));
            pushToVault('logs.json', json_encode($logs)); pushToVault('sales.txt', (string)$total_sales);
            
            fw_drop($client_mac, $client_ip); 
            fw_allow($client_mac, $client_ip, $tier);
            $activation_success = true;
        } else { $error_message = "ENCRYPTED KEY INVALID OR CONSUMED."; }
    }
}

$rates = json_decode(pullFromVault('rates.json'), true) ?: [];
$rates_json = json_encode($rates); 
$config = json_decode(pullFromVault('ads_config.json'), true) ?: ["orientation" => "portrait"];
$tier = 'Regular';

$all_vouchers = json_decode(pullFromVault('vouchers.json'), true) ?: [];
$my_vouchers = [];
foreach ($all_vouchers as $code => $v) {
    if (($v['creator_mac'] ?? '') === $client_mac && ($v['status'] ?? '') === 'unused') { $my_vouchers[$code] = $v; }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>VAULT OS | PiSO WIFI LOBBY</title>
    <?php include 'theme.php'; ?>
    <style>
        .result-cursor { display: inline-block; width: 8px; height: 15px; animation: blink 1s step-end infinite; vertical-align: middle; margin-left: 2px; margin-top: -2px; }
        @keyframes blink { 50% { opacity: 0; } }
        
        .offline-disabled { opacity: 0.4 !important; pointer-events: none !important; filter: grayscale(100%); }
        .offline-pulse { animation: offlineBlink 1.5s infinite; }
        @keyframes offlineBlink { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; color: #ff4c4c; } }
    </style>

    <?php if ($is_lite): ?>
    <style>
        body { background: #0a0a0a !important; background-image: none !important; }
        * { animation: none !important; transition: none !important; box-shadow: none !important; text-shadow: none !important; }
        .panel, .modal-content, .card { background: #111 !important; border: 1px solid #333 !important; }
        .btn { box-shadow: none !important; border-radius: 4px !important; }
        #particles-js, .glitch, .scanlines { display: none !important; }
    </style>
    <?php endif; ?>
</head>
<body class="">

    <audio id="s-coin" src="../assets/coin.mp3" preload="auto"></audio>
    <audio id="s-loading" src="../assets/loading.mp3" preload="auto"></audio> 
    <audio id="s-granted" src="../assets/granted.mp3" preload="auto"></audio> 
    <audio id="s-denied" src="../assets/denied.mp3" preload="auto"></audio> 
    <audio id="s-error" src="../assets/error.mp3" preload="auto"></audio>
    <audio id="s-insert" src="../assets/insert_coin.mp3" preload="auto" loop></audio>

    <?php if ($bought_voucher_code !== ''): ?>
        <div id="loader" style="display:flex; flex-direction: column; justify-content: center; align-items: center; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: #000; z-index: 10000;">
            <h2 style="color: var(--vip); font-size: 2rem; font-family: 'Orbitron'; text-shadow: <?php echo $is_lite ? 'none' : '0 0 20px var(--vip)'; ?>;">VOUCHER MINTED</h2>
            <div class="terminal-log" style="width: 80%; max-width: 400px; color: #fff; border-color: var(--vip); height: auto; text-align: center; padding: 20px;">
                <p style="color: #888; font-size: 0.9rem; margin-top: 0;">SCREENSHOT OR COPY YOUR CODE:</p>
                <div style="font-size: 2.2rem; font-family: 'Courier New', monospace; font-weight: bold; letter-spacing: 3px; background: #000; padding: 10px; border: 1px dashed var(--vip); color: var(--vip); margin-bottom: 10px;" id="minted-code">
                    <?php echo $bought_voucher_code; ?>
                </div>
                
                <?php 
                    $button_section = 'lobby_minted'; 
                    include 'buttons.php'; 
                ?>
                
                <div style="color: var(--success); font-family: 'Orbitron'; font-size: 0.9rem;">
                    <?php echo "[+] " . floor($bought_voucher_val/60) . "H " . ($bought_voucher_val%60) . "M DURATION"; ?>
                </div>
                <div style="color: var(--info); font-family: 'Orbitron'; font-size: 0.9rem;">[+] ₱<?php echo number_format($bought_voucher_price, 2); ?> PAID</div>
            </div>
        </div>
        <script>
            window.addEventListener('DOMContentLoaded', () => {
                var audio = document.getElementById('s-granted');
                if (audio) { audio.volume = 1.0; audio.play().catch(function(e){}); }
            });

            function copyVoucherCode(code, btnElement) {
                var showCopied = function() {
                    var originalText = btnElement.innerText; var originalBg = btnElement.style.backgroundColor; var originalColor = btnElement.style.color;
                    btnElement.innerText = 'COPIED!'; btnElement.style.backgroundColor = btnElement.style.borderColor; btnElement.style.color = '#000';
                    setTimeout(function() { btnElement.innerText = originalText; btnElement.style.backgroundColor = originalBg; btnElement.style.color = originalColor; }, 2000);
                };
                if (navigator.clipboard && window.isSecureContext) {
                    navigator.clipboard.writeText(code).then(showCopied).catch(function(err) { console.log('Copy failed:', err); });
                } else {
                    var textArea = document.createElement("textarea");
                    textArea.value = code; textArea.style.position = "fixed"; textArea.style.opacity = "0";
                    document.body.appendChild(textArea); textArea.focus(); textArea.select();
                    try { document.execCommand('copy'); showCopied(); } catch (err) {}
                    document.body.removeChild(textArea);
                }
            }
        </script>
    <?php exit; endif; ?>

    <?php if ($activation_success): ?>
        <div id="loader" style="display:flex; flex-direction: column; justify-content: center; align-items: center; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: #000; z-index: 10000;">
            <h2 style="color: var(--success); font-size: 2.5rem; font-family: 'Orbitron'; text-shadow: <?php echo $is_lite ? 'none' : '0 0 20px var(--success)'; ?>;">ACCESS GRANTED</h2>
            <div class="bar-container"><div class="bar-fill" style="width: 100%; transition: none;"></div></div>
            <p style="color: var(--success); font-family: 'Source Code Pro'; font-weight: bold;">UPLINK ESTABLISHED. WELCOME.</p>
            <div class="terminal-log" style="width: 80%; max-width: 400px; color: var(--success); border-color: var(--success); text-align: left;">
                <span id="term-granted"></span><span class="result-cursor" style="background-color: var(--success);"></span>
            </div>
            
            <?php 
                $button_section = 'lobby_success'; 
                include 'buttons.php'; 
            ?>
            
        </div>
        <script>
            window.addEventListener('DOMContentLoaded', () => {
                var audio = document.getElementById('s-granted');
                if (audio) { audio.volume = 1.0; audio.play().catch(function(e){}); }

                var lines = ["> FIREWALL_TUNNEL: SECURED", "> ROUTING_TRAFFIC_TO_CORE..."];
                var el = document.getElementById('term-granted'); var curr = 0;
                function t() { if(curr<lines.length) { el.innerHTML += lines[curr]+"<br>"; curr++; setTimeout(t, <?php echo $is_lite ? '0' : 'Math.random()*200+200'; ?>); } }
                setTimeout(t, 400);
            });
        </script>
    <?php exit; endif; ?>

    <?php include 'loading.php'; ?>

    <div class="container">
        
        <div style="display: flex; justify-content: flex-end; margin-bottom: 10px;">
            <?php if ($is_lite): ?>
                <button onclick="window.location.href='?mode=advance'" class="btn outline" style="font-size: 0.7rem; padding: 6px 12px; border-color: var(--vip); color: var(--vip); font-family: 'Orbitron'; font-weight: bold;">🚀 ADVANCE MODE</button>
            <?php else: ?>
                <button onclick="window.location.href='?mode=lite'" class="btn outline" style="font-size: 0.7rem; padding: 6px 12px; border-color: var(--success); color: var(--success); font-family: 'Orbitron'; font-weight: bold;">⚡ LITE MODE</button>
            <?php endif; ?>
        </div>

        <div style="margin-bottom: 25px;">
            <?php if(!$is_lite): ?>
                <img src="../assets/logo.png" style="max-width: 160px; filter: drop-shadow(var(--theme-glow));">
            <?php endif; ?>
            <h1 style="<?php echo $is_lite ? 'color: var(--theme-color); font-size: 1.8rem;' : ''; ?>">ANONIMO'S VAULT</h1>
        </div>

        <div class="panel" data-node="<?php echo substr($client_mac, -5); ?>">
            <div class="status-badge" id="sys-status-label" style="color: var(--danger);">● UNAUTHENTICATED</div>
            <h2 style="font-size: 1.5rem; margin-bottom: 20px;">NETWORK ACCESS DENIED</h2>

            <?php 
                $button_section = 'lobby_main'; 
                include 'buttons.php'; 
            ?>

            <?php $log_mode = 'lobby'; include 'log_work.php'; ?>

            <?php if (count($my_vouchers) > 0): ?>
            <div style="margin-top: 15px; background: rgba(0,0,0,0.6); border: 1px dashed var(--success); padding: 15px; text-align: left; border-radius: 3px; box-shadow: inset 0 0 10px rgba(16, 185, 129, 0.1);">
                <div style="color: var(--success); font-family: 'Orbitron'; font-size: 0.8rem; margin-bottom: 10px;">> VAULT: YOUR UNUSED KEYS</div>
                <?php foreach($my_vouchers as $v_code => $v_data): 
                    $v_color = ($v_data['tier'] === 'Gaming') ? 'var(--vip)' : 'var(--info)';
                    $v_val = $v_data['value'] ?? ($v_data['minutes'] ?? 0);
                    $display = "{$v_val}m";
                ?>
                    <div style="display: flex; justify-content: space-between; align-items: center; font-family: 'Source Code Pro', monospace; font-size: 0.9rem; padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.05);">
                        <div style="display: flex; flex-direction: column;">
                            <span style="color: #fff; font-weight: bold; letter-spacing: 2px;"><?php echo htmlspecialchars($v_code); ?></span>
                            <span style="color: <?php echo $v_color; ?>; font-size: 0.7rem;">[<?php echo strtoupper($v_data['tier']); ?> | <?php echo $display; ?>]</span>
                        </div>
                        <?php $button_section = 'copy_unused_key'; include 'buttons.php'; ?>
                    </div>
                <?php endforeach; ?>
                <div style="font-size: 0.7rem; color: #888; font-family: 'Rajdhani'; margin-top: 10px; text-align: center;">Click REDEEM KEY above to activate these codes.</div>
            </div>
            <?php endif; ?>

        </div>
        
    </div>

    <div id="m-voucher" class="modal"><div class="modal-content" style="border-color: var(--theme-color); box-shadow: <?php echo $is_lite ? 'none' : 'var(--theme-glow)'; ?>;">
        <h2 style="color: var(--theme-color); font-family: 'Orbitron';">REDEEM KEYCODE</h2>
        <form method="POST" onsubmit="return triggerSubmitLoader(event, this, 'DECRYPTING KEYCODE...', false, 's-loading');">
            <input type="hidden" name="action" value="redeem_voucher">
            <input type="text" name="voucher" placeholder="XXXXXX" autocomplete="off" required>
            <?php $button_section = 'modal_submit'; include 'buttons.php'; ?>
        </form>
        <?php $button_section = 'modal_cancel'; include 'buttons.php'; ?>
    </div></div>

    <div id="m-alert" class="modal" <?php if($error_message) echo 'style="display:flex;"'; ?>><div class="modal-content" style="border-color: <?php echo strpos($error_message, '✅') !== false ? 'var(--success)' : 'var(--danger)'; ?>;">
        <h2 style="color: <?php echo strpos($error_message, '✅') !== false ? 'var(--success)' : 'var(--danger)'; ?>;">
            <?php echo strpos($error_message, '✅') !== false ? 'SUCCESS!' : 'ERROR DETECTED'; ?>
        </h2>
        <p id="m-alert-txt" style="font-size: 1.2rem; margin: 20px 0;"><?php echo $error_message; ?></p>
        <?php $button_section = 'modal_ack'; include 'buttons.php'; ?>
    </div></div>

    <?php include 'rates_modal.php'; ?>

    <script>
        var ratesData = <?php echo empty($rates_json) ? '{}' : $rates_json; ?>;
        var currentLobbyTier = 'Regular';
        var currentModalTier = 'Regular'; 

        const MY_LOBBY_TAB_ID = Date.now().toString() + Math.random().toString();
        localStorage.setItem('vault_lobby_tab', MY_LOBBY_TAB_ID);

        window.addEventListener('storage', function(e) {
            if (e.key === 'vault_lobby_tab' && e.newValue !== MY_LOBBY_TAB_ID) {
                lockScreen("SESSION TRANSFERRED", "You opened the Vault Lobby in a new tab. This tab has been locked to prevent duplicate transactions.");
            }
        });

        function lockScreen(title, msg) {
            if(document.getElementById('global-shield')) return;
            let shield = document.createElement('div'); shield.id = 'global-shield';
            shield.style.position = 'fixed'; shield.style.top = '0'; shield.style.left = '0';
            shield.style.width = '100%'; shield.style.height = '100%'; shield.style.background = 'rgba(0,0,0,0.95)';
            shield.style.zIndex = '999999'; shield.style.display = 'flex'; shield.style.flexDirection = 'column';
            shield.style.alignItems = 'center'; shield.style.justifyContent = 'center'; shield.style.backdropFilter = 'blur(5px)';
            
            let style = document.createElement('style'); 
            style.innerHTML = '@keyframes vault-spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }';
            document.head.appendChild(style);
            
            shield.innerHTML = `<div style="border: 4px solid rgba(255,255,255,0.1); border-top: 4px solid var(--danger); border-radius: 50%; width: 50px; height: 50px; animation: vault-spin 1s linear infinite; margin-bottom: 20px;"></div><h2 style="color:var(--danger); font-family:'Orbitron'; margin:0; letter-spacing: 2px; text-align:center;">${title}</h2><p style="color:#aaa; font-size:0.9rem; max-width:80%; text-align:center;">${msg}</p>`;
            document.body.appendChild(shield);
        }

        window.openM = function(id) { var el = document.getElementById(id); if(el) el.style.display = 'flex'; };
        window.closeM = function(id) { var el = document.getElementById(id); if(el) el.style.display = 'none'; };

        function setLobbyTier(t) {
            currentLobbyTier = t; 
            currentModalTier = t; 
            if(t==='Gaming'){ 
                document.body.classList.add('theme-gaming'); document.getElementById('tg').classList.add('active-tier'); document.getElementById('tr').classList.remove('active-tier'); 
            } else { 
                document.body.classList.remove('theme-gaming'); document.getElementById('tr').classList.add('active-tier'); document.getElementById('tg').classList.remove('active-tier'); 
            }
        }

        function openRates() { document.getElementById('m-rates').style.display = 'flex'; }
        function openVoucher() { document.getElementById('m-voucher').style.display = 'flex'; }

        window.addEventListener('DOMContentLoaded', function() { 
            var eAudio = document.getElementById('s-denied');
            if (eAudio) {
                <?php if($error_message && strpos($error_message, '✅') === false): ?>
                    eAudio.play().catch(function(e){}); 
                <?php endif; ?>
            }
        });
        
        var isInternetOnline = true;
        var badgeOriginalText = "";
        var badgeOriginalColor = "";
        
        function checkServerInternet() {
            var badge = document.getElementById('sys-status-label');
            if (badge && !badgeOriginalText && !badge.innerText.includes('INTERNET')) {
                badgeOriginalText = badge.innerHTML;
                badgeOriginalColor = badge.style.color;
            }

            fetch('?ping_check=1&t=' + new Date().getTime())
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    isInternetOnline = data.internet;
                    var btns = document.querySelectorAll('[onclick*="openSlot"], [onclick*="openVoucher"], [onclick*="openM"]');
                    
                    if (!isInternetOnline) {
                        if (badge) {
                            badge.innerHTML = '● NO INTERNET... PLEASE TRY AGAIN LATER';
                            badge.style.color = 'var(--danger)';
                            badge.classList.add('offline-pulse');
                        }
                        btns.forEach(function(btn) { btn.classList.add('offline-disabled'); });
                    } else {
                        if (badge && badgeOriginalText) {
                            badge.innerHTML = badgeOriginalText;
                            badge.style.color = badgeOriginalColor;
                            badge.classList.remove('offline-pulse');
                        }
                        btns.forEach(function(btn) { btn.classList.remove('offline-disabled'); });
                    }
                }).catch(function(e) {});
            setTimeout(checkServerInternet, 4000);
        }
        setTimeout(checkServerInternet, 1000);
    </script>
    
    <?php include 'coin_core.php'; ?>
    
    <?php if (!$is_lite): ?>
        <?php include 'chat_widget.php'; ?>
    <?php endif; ?>

</body>
</html>