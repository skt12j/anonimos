<?php
// core.php - OPENWRT NFTABLES EDITION (RAM-Disk Optimized)

define('DB_DIR', '/etc/pisowifi/db/');
define('ASSETS_DIR', '/tmp/html/assets/');

if (session_status() == PHP_SESSION_NONE) {
    if (!file_exists(DB_DIR . 'sessions_tmp')) { @mkdir(DB_DIR . 'sessions_tmp', 0777, true); }
    @ini_set('session.gc_maxlifetime', 2592000); 
    @ini_set('session.cookie_lifetime', 2592000);
    session_save_path(DB_DIR . 'sessions_tmp');
    session_start();
}

function getClientMac($ip) {
    if (empty($ip)) return 'UNKNOWN';
    if ($ip === '127.0.0.1' || $ip === '10.0.0.1') return 'SERVER';
    $arp = @file('/proc/net/arp');
    if ($arp) {
        foreach($arp as $line){
            $cols = preg_split('/\s+/', $line);
            if(isset($cols[0]) && $cols[0] === $ip){ 
                $mac = strtolower(trim($cols[3]));
                if (!empty($mac) && $mac !== '00:00:00:00:00:00') return $mac;
            }
        }
    }
    return 'UNKNOWN';
}

function isWispSubscriber($mac) {
    if (empty($mac) || $mac === 'UNKNOWN') return false;
    $mac = strtolower($mac);
    $subs = json_decode(pullFromVault('subscriptions.json'), true);
    if (!is_array($subs)) return false;
    foreach($subs as $s) {
        if (isset($s['status']) && $s['status'] === 'active' && isset($s['macs']) && is_array($s['macs'])) {
            $macs_lower = array_map('strtolower', $s['macs']);
            if (in_array($mac, $macs_lower)) return true;
        }
    }
    return false;
}

function fw_allow($mac, $ip = '', $tier = 'Regular') {
    $mac = strtolower(trim((string)$mac));
    if (empty($mac) || $mac === 'unknown' || $mac === '00:00:00:00:00:00') return false;

    $blocked = json_decode(pullFromVault('blocked.json'), true);
    if (is_array($blocked) && isset($blocked[strtoupper($mac)])) return false; 
    if (isWispSubscriber($mac)) return true;

    // Add MAC to the OpenWrt nftables allowed set (No sudo needed)
    exec("nft add element inet pisowifi authenticated_macs { $mac } 2>/dev/null");

    // Clear existing connections so the device instantly reconnects with internet access
    if (!empty($ip)) {
        $safe_ip = escapeshellarg($ip);
        exec("conntrack -D -s $safe_ip 2>/dev/null");
        exec("conntrack -D -d $safe_ip 2>/dev/null");
    }
    return true;
}

function fw_drop($mac, $ip = '') {
    $mac = strtolower(trim((string)$mac));
    if (empty($mac) || $mac === 'unknown') return false;
    if (isWispSubscriber($mac)) return true;

    // Remove MAC from OpenWrt nftables allowed set
    exec("nft delete element inet pisowifi authenticated_macs { $mac } 2>/dev/null");

    // Clear existing connections to instantly drop their internet
    if (!empty($ip)) {
        $safe_ip = escapeshellarg($ip);
        exec("conntrack -D -s $safe_ip 2>/dev/null");
        exec("conntrack -D -d $safe_ip 2>/dev/null");
    } else {
        // Failsafe: Find IP in OpenWrt DHCP leases if not provided
        $safe_mac = escapeshellarg($mac);
        $arp_ip = trim(shell_exec("cat /tmp/dhcp.leases | grep -i $safe_mac | awk '{print $3}'"));
        if (!empty($arp_ip)) {
            $safe_arp_ip = escapeshellarg($arp_ip);
            exec("conntrack -D -s $safe_arp_ip 2>/dev/null");
            exec("conntrack -D -d $safe_arp_ip 2>/dev/null");
        }
    }
    return true;
}

function fw_ban($mac, $ip = '') {
    fw_drop($mac, $ip); 
}

function fw_unban($mac) {
    // Handled naturally by ban.php deleting it from blocked.json
}

function pullFromVault($filename) {
    $local_file = (strpos($filename, 'assets/') === 0) ? '/tmp/html/' . $filename : DB_DIR . $filename;
    if (file_exists($local_file)) return file_get_contents($local_file);
    return '';
}

function pushToVault($filename, $content) {
    $local_file = (strpos($filename, 'assets/') === 0) ? '/tmp/html/' . $filename : DB_DIR . $filename;
    $file_dir = dirname($local_file);
    if (!file_exists($file_dir)) @mkdir($file_dir, 0777, true);
    @file_put_contents($local_file, $content);
}
?>
