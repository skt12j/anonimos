<?php
// portal/stat/core.php - OPENWRT RAM-DISK EDITION (Time-Mode Brain)
require_once '../core.php';

$client_ip = $_SERVER['REMOTE_ADDR'];
$client_mac = getClientMac($client_ip);

$blocked_file = DB_DIR . 'blocked.json';
if (file_exists($blocked_file)) {
    $blocked = json_decode(file_get_contents($blocked_file), true);
    if (isset($blocked[$client_mac])) { header("Location: /portal/banned.php"); exit; }
}

$sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
$current_time = time();

if (isset($_GET['ping_check'])) {
    header('Content-Type: application/json');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    $fp = @fsockopen("1.1.1.1", 53, $errno, $errstr, 1);
    if ($fp) { fclose($fp); echo json_encode(['internet' => true]); } 
    else { echo json_encode(['internet' => false]); }
    exit;
}

if (isset($_GET['ajax_data'])) {
    header('Content-Type: application/json');
    header('Cache-Control: no-cache, no-store, must-revalidate');

    if (!isset($sessions[$client_mac])) {
        echo json_encode(['status' => 'expired']); exit;
    }

    $data = $sessions[$client_mac];
    if ($data['status'] === 'expired') {
        echo json_encode(['status' => 'expired']); exit;
    }

    $active_tier = $data['tier'] ?? 'Regular';
    $time_left = max(0, ($data['expires'] ?? 0) - $current_time);

    // If time depleted, automatically freeze the session so daemon picks it up
    if ($time_left <= 0 && $data['status'] === 'active') {
        $bank_other = ($active_tier === 'Regular') ? ($data['bank_Gaming'] ?? 0) : ($data['bank_Regular'] ?? 0);
        if ($bank_other > 0) {
            $sessions[$client_mac]['status'] = 'paused';
            $sessions[$client_mac]['time_left'] = 0;
            $sessions[$client_mac]['last_paused_at'] = $current_time;
            fw_drop($client_mac, $client_ip);
            pushToVault('sessions.json', json_encode($sessions));
            echo json_encode(['status' => 'frozen']); exit;
        } else {
            echo json_encode(['status' => 'expired']); exit;
        }
    }

    if ($data['status'] === 'paused') {
        echo json_encode(['status' => 'frozen']); exit;
    }

    $time_reg = ($active_tier === 'Regular') ? $time_left : ($data['bank_Regular'] ?? 0);
    $time_gam = ($active_tier === 'Gaming') ? $time_left : ($data['bank_Gaming'] ?? 0);

    echo json_encode([
        'status' => 'active',
        'tier' => $active_tier,
        'time_reg' => $time_reg,
        'time_gam' => $time_gam
    ]);
    exit;
}

if (!isset($sessions[$client_mac]) || $sessions[$client_mac]['status'] === 'expired') {
    header("Location: index.php");
    exit;
}

$user_data = $sessions[$client_mac];
$active_tier = $user_data['tier'] ?? 'Regular';
$active_time_left = max(0, ($user_data['expires'] ?? 0) - $current_time);
$bank_reg = $user_data['bank_Regular'] ?? 0;
$bank_gam = $user_data['bank_Gaming'] ?? 0;

$error_message = '';
$voucher_conflict = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action === 'switch_tier') {
        $target_tier = $_POST['target_tier'] ?? 'Regular';
        
        if ($target_tier !== $active_tier) {
            $current_bank_key = "bank_" . $active_tier;
            $sessions[$client_mac][$current_bank_key] = $active_time_left;
            
            $target_bank_key = "bank_" . $target_tier;
            $new_time = $sessions[$client_mac][$target_bank_key] ?? 0;
            
            $sessions[$client_mac]['tier'] = $target_tier;
            $sessions[$client_mac]['expires'] = $current_time + $new_time;
            $sessions[$client_mac][$target_bank_key] = 0;
            
            $sessions[$client_mac]['status'] = 'active';
            $sessions[$client_mac]['ignore_late_payload'] = true; 
            unset($sessions[$client_mac]['last_paused_at']);
            
            fw_drop($client_mac, $client_ip);
            fw_allow($client_mac, $client_ip, $target_tier);
            
            pushToVault('sessions.json', json_encode($sessions));
            header("Location: status.php"); exit;
        }
    }

    elseif ($action === 'pause_session') {
        if ($user_data['status'] === 'active') {
            $sessions[$client_mac]['status'] = 'paused';
            $sessions[$client_mac]['time_left'] = $active_time_left;
            $sessions[$client_mac]['last_paused_at'] = $current_time;
            
            fw_drop($client_mac, $client_ip);
            pushToVault('sessions.json', json_encode($sessions));
            header("Location: status.php"); exit;
        }
    }

    elseif ($action === 'resume_session') {
        if ($user_data['status'] === 'paused') {
            $sessions[$client_mac]['status'] = 'active';
            $sessions[$client_mac]['expires'] = $current_time + ($user_data['time_left'] ?? 0);
            $sessions[$client_mac]['time_left'] = 0;
            unset($sessions[$client_mac]['last_paused_at']);
            
            fw_allow($client_mac, $client_ip, $active_tier);
            pushToVault('sessions.json', json_encode($sessions));
            header("Location: status.php"); exit;
        }
    }

    elseif ($action === 'add_coin' || $action === 'insert_coin' || $action === 'redeem_voucher') {
        $logs = json_decode(pullFromVault('logs.json'), true) ?: [];
        $sales_raw = pullFromVault('sales.txt');
        $total_sales = is_numeric($sales_raw) ? (float)$sales_raw : 0.00;

        $target_tier = $_POST['tier'] ?? $active_tier;
        $val_added = 0; $price = 0; $details = "";

        if ($action === 'redeem_voucher') {
            $code = strtoupper(trim($_POST['voucher']));
            $vouchers = json_decode(pullFromVault('vouchers.json'), true) ?: [];
            
            if (isset($vouchers[$code]) && $vouchers[$code]['status'] === 'unused') {
                $val_added = (float)($vouchers[$code]['value'] ?? $vouchers[$code]['minutes']);
                $price = (float)($vouchers[$code]['price'] ?? 0);
                $target_tier = $vouchers[$code]['tier'] ?? 'Regular';

                $vouchers[$code]['status'] = 'used'; 
                $vouchers[$code]['used_by'] = $client_mac; 
                $vouchers[$code]['used_date'] = date('Y-m-d H:i:s');
                pushToVault('vouchers.json', json_encode($vouchers));
                
                $details = "Code: $code | Added {$val_added}m";
            } else {
                $error_message = "ENCRYPTED KEY INVALID OR CONSUMED.";
            }
        } else {
            $inserted_coins = (int)$_POST['coins'];
            $rates_data = json_decode(pullFromVault('rates.json'), true) ?: [];
            $tier_rates = $rates_data['Time'][$target_tier] ?? [];
            
            $remaining_coins = $inserted_coins; $price = $inserted_coins;
            if(!empty($tier_rates)) {
                $available_denoms = array_keys($tier_rates); rsort($available_denoms, SORT_NUMERIC); 
                foreach ($available_denoms as $denom) {
                    $denom_int = (int)$denom; if ($denom_int <= 0) continue;
                    $count = floor($remaining_coins / $denom_int);
                    if ($count > 0) { $val_added += ($count * (float)$tier_rates[$denom]); $remaining_coins -= ($count * $denom_int); }
                }
            }
            // 🔥 FIXED PHP ENCODING GLITCH HERE:
            $details = "Inserted ₱$price | Added {$val_added}m";
        }

        if ($val_added > 0) {
            $is_frozen = ($sessions[$client_mac]['status'] === 'paused');
            
            if ($target_tier === $active_tier && !$is_frozen) {
                $sessions[$client_mac]['expires'] += ($val_added * 60);
            } else {
                $bank_key = "bank_" . $target_tier;
                if ($is_frozen && $target_tier === $active_tier) {
                    $sessions[$client_mac]['time_left'] += ($val_added * 60);
                } else {
                    $sessions[$client_mac][$bank_key] += ($val_added * 60);
                }
            }

            $total_sales += $price;
            $event_name = ($action === 'redeem_voucher') ? 'VOUCHER_ACTIVATED' : 'TOP_UP';
            $logs[] = ['date' => date('Y-m-d H:i:s'), 'mac' => $client_mac, 'event' => $event_name, 'tier' => $target_tier, 'details' => $details, 'revenue' => $price];
            
            pushToVault('sessions.json', json_encode($sessions)); 
            pushToVault('logs.json', json_encode($logs)); 
            pushToVault('sales.txt', (string)$total_sales);
            
            header("Location: status.php"); exit;
        } elseif ($action !== 'redeem_voucher') {
            $error_message = "SYSTEM ERROR: No valid rates configured for " . strtoupper($target_tier) . ".";
        }
    }
}

$rates = json_decode(pullFromVault('rates.json'), true) ?: [];
$rates_json = json_encode($rates); 

$time_reg = ($active_tier === 'Regular') ? $active_time_left : $bank_reg;
$time_gam = ($active_tier === 'Gaming') ? $active_time_left : $bank_gam;
if ($user_data['status'] === 'paused') {
    $time_reg = ($active_tier === 'Regular') ? ($user_data['time_left'] ?? 0) : $bank_reg;
    $time_gam = ($active_tier === 'Gaming') ? ($user_data['time_left'] ?? 0) : $bank_gam;
}
?>