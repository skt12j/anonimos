<?php
// core.php - OPENWRT NFTABLES EDITION (True RAM-Disk + Subnet Shield)

define('DB_DIR', '/tmp/html/db/');
define('ASSETS_DIR', '/tmp/html/assets/');

// 🔥 IMPENETRABLE ADMIN SUBNET SHIELD 🔥
// Only users on the Private LAN (192.168.1.*) can access the /admin/ folder!
$current_uri = $_SERVER['SCRIPT_NAME'] ?? '';
if (strpos($current_uri, '/admin/') !== false) {
    $my_ip = $_SERVER['REMOTE_ADDR'] ?? '';
    
    // Let the router's internal background scripts pass freely
    if ($my_ip !== '127.0.0.1' && $my_ip !== '10.0.0.1' && $my_ip !== '::1') {
        // If the user's IP does NOT start with 192.168.1. (Meaning they are on 10.0.0.* Piso WiFi)
        if (strpos($my_ip, '192.168.1.') !== 0) {
            header("Location: /portal/index.php"); // Kick them to the lobby!
            exit;
        }
    }
}

if (session_status() == PHP_SESSION_NONE) {
    $session_dir = '/tmp/php_sessions';
    if (!file_exists($session_dir)) { @mkdir($session_dir, 0777, true); }
    
    @ini_set('session.gc_maxlifetime', 2592000); 
    @ini_set('session.cookie_lifetime', 2592000);
    session_save_path($session_dir);
    session_start();
}

function getClientMac($ip) {
    if (empty($ip)) return 'UNKNOWN';
    if ($ip === '127.0.0.1' || $ip === '10.0.0.1') return 'SERVER';
    $arp = @file('/proc/net/arp');
    if ($arp) {
        foreach($arp as $line){
            $cols = preg_split('/\s+/', $line);
            if(isset($cols[0]) && $cols[0] === $ip){ 
                $mac = strtolower(trim($cols[3]));
                if (!empty($mac) && $mac !== '00:00:00:00:00:00') return $mac;
            }
        }
    }
    return 'UNKNOWN';
}

function isWispSubscriber($mac) {
    if (empty($mac) || $mac === 'UNKNOWN') return false;
    $mac = strtolower($mac);
    $subs = json_decode(pullFromVault('subscriptions.json'), true);
    if (!is_array($subs)) return false;
    foreach($subs as $s) {
        if (isset($s['status']) && $s['status'] === 'active' && isset($s['macs']) && is_array($s['macs'])) {
            $macs_lower = array_map('strtolower', $s['macs']);
            if (in_array($mac, $macs_lower)) return true;
        }
    }
    return false;
}

function fw_allow($mac, $ip = '', $tier = 'Regular') {
    $mac = strtolower(trim((string)$mac));
    if (empty($mac) || $mac === 'unknown' || $mac === '00:00:00:00:00:00') return false;

    $blocked = json_decode(pullFromVault('blocked.json'), true);
    if (is_array($blocked) && isset($blocked[strtoupper($mac)])) return false; 
    if (isWispSubscriber($mac)) return true;

    exec("nft add element inet pisowifi authenticated_macs { $mac } 2>/dev/null");

    if (!empty($ip)) {
        $safe_ip = escapeshellarg($ip);
        exec("conntrack -D -s $safe_ip 2>/dev/null");
        exec("conntrack -D -d $safe_ip 2>/dev/null");
    }
    return true;
}

function fw_drop($mac, $ip = '') {
    $mac = strtolower(trim((string)$mac));
    if (empty($mac) || $mac === 'unknown') return false;
    if (isWispSubscriber($mac)) return true;

    exec("nft delete element inet pisowifi authenticated_macs { $mac } 2>/dev/null");

    if (!empty($ip)) {
        $safe_ip = escapeshellarg($ip);
        exec("conntrack -D -s $safe_ip 2>/dev/null");
        exec("conntrack -D -d $safe_ip 2>/dev/null");
    } else {
        $safe_mac = escapeshellarg($mac);
        $arp_ip = trim(shell_exec("cat /tmp/dhcp.leases | grep -i $safe_mac | awk '{print $3}'"));
        if (!empty($arp_ip)) {
            $safe_arp_ip = escapeshellarg($arp_ip);
            exec("conntrack -D -s $safe_arp_ip 2>/dev/null");
            exec("conntrack -D -d $safe_arp_ip 2>/dev/null");
        }
    }
    return true;
}

function fw_ban($mac, $ip = '') {
    fw_drop($mac, $ip); 
}

function fw_unban($mac) {
}

function pullFromVault($filename) {
    $local_file = (strpos($filename, 'assets/') === 0) ? '/tmp/html/' . $filename : DB_DIR . $filename;
    
    if (file_exists($local_file)) return file_get_contents($local_file);
    
    if (strpos($filename, 'assets/') !== 0) {
        $backup_file = '/root/vault_backup/' . $filename;
        if (file_exists($backup_file)) return file_get_contents($backup_file);
    }
    
    return '';
}

function pushToVault($filename, $content) {
    $local_file = (strpos($filename, 'assets/') === 0) ? '/tmp/html/' . $filename : DB_DIR . $filename;
    $file_dir = dirname($local_file);
    if (!file_exists($file_dir)) @mkdir($file_dir, 0777, true);
    
    @file_put_contents($local_file, $content);
    
    if (strpos($filename, 'assets/') !== 0) {
        $backup_dir = '/root/vault_backup/';
        if (!file_exists($backup_dir)) @mkdir($backup_dir, 0777, true);
        @file_put_contents($backup_dir . $filename, $content);
    }
}
?>
