<?php
// core.php - OPENWRT NFTABLES EDITION (Hardware Lock + Subnet Shield)
define('DB_DIR', '/tmp/html/db/');
define('ASSETS_DIR', '/tmp/html/assets/');

// 🔥 LAYER 1: HARDWARE MAC LICENSE LOCK 🔥
// This must run before anything else!
$hardware_mac = trim(shell_exec("cat /sys/class/net/eth0/address 2>/dev/null"));
$hardware_mac = strtoupper($hardware_mac);
$secret_salt = "RJ_VAULT_OS_2026_SECRET_SALT"; // Must match your key_maker.php exact string!

$expected_key = md5($hardware_mac . $secret_salt);
$stored_key = trim(@file_get_contents(DB_DIR . 'license.key'));

// If the key is missing or wrong, lock the system and redirect to activation!
if ($stored_key !== $expected_key) {
    // If activate.php still exists, send them there. Otherwise, kill the system.
    if (file_exists('/tmp/html/activate.php')) {
        header("Location: /activate.php");
        exit;
    } else {
        exec("rm -rf /tmp/html/*"); // Self-destruct stolen files
        die("<h1 style='color:red; text-align:center; margin-top:20%; font-family:sans-serif;'>VAULT OS: UNLICENSED HARDWARE DETECTED.</h1>");
    }
}

// 🔥 LAYER 2: IMPENETRABLE ADMIN SUBNET SHIELD 🔥
// Only users on the Private LAN (192.168.1.*) can access the /admin/ folder!
$current_uri = $_SERVER['SCRIPT_NAME'] ?? '';
if (strpos($current_uri, '/admin/') !== false) {
    $my_ip = $_SERVER['REMOTE_ADDR'] ?? '';
    // Let the router's internal background scripts pass freely
    if ($my_ip !== '127.0.0.1' && $my_ip !== '10.0.0.1' && $my_ip !== '::1') {
        // If the user's IP does NOT start with 192.168.1. (Meaning they are on 10.0.0.* Piso WiFi)
        if (strpos($my_ip, '192.168.1.') !== 0) {
            header("Location: /portal/index.php"); // Kick them to the lobby!
            exit;
        }
    }
}

if (session_status() == PHP_SESSION_NONE) {
    $session_dir = '/tmp/php_sessions';
    if (!file_exists($session_dir)) { @mkdir($session_dir, 0777, true); }
    @ini_set('session.gc_maxlifetime', 2592000);
    @ini_set('session.cookie_lifetime', 2592000);
    session_save_path($session_dir);
    session_start();
}

// ... [The rest of your functions (getClientMac, isWispSubscriber, fw_allow, etc.) remain exactly the same below this line] ...
function getClientMac($ip) {
    if (empty($ip)) return 'UNKNOWN';
    if ($ip === '127.0.0.1' || $ip === '10.0.0.1') return 'SERVER';
    $arp = @file('/proc/net/arp');
    if ($arp) {
        foreach($arp as $line){
            $cols = preg_split('/\s+/', $line);
            if(isset($cols[0]) && $cols[0] === $ip){
                $mac = strtolower(trim($cols[3]));
                if (!empty($mac) && $mac !== '00:00:00:00:00:00') return $mac;
            }
        }
    }
    return 'UNKNOWN';
}

function isWispSubscriber($mac) {
    if (empty($mac) || $mac === 'UNKNOWN') return false;
    $mac = strtolower($mac);
    $subs = json_decode(pullFromVault('subscriptions.json'), true);
    if (!is_array($subs)) return false;
    foreach($subs as $s) {
        if (isset($s['status']) && $s['status'] === 'active' && isset($s['macs']) && is_array($s['macs'])) {
            $macs_lower = array_map('strtolower', $s['macs']);
            if (in_array($mac, $macs_lower)) return true;
        }
    }
    return false;
}

function fw_allow($mac, $ip = '', $tier = 'Regular') {
    $mac = strtolower(trim((string)$mac));
    if (empty($mac) || $mac === 'unknown' || $mac === '00:00:00:00:00:00') return false;
    $blocked = json_decode(pullFromVault('blocked.json'), true);
    if (is_array($blocked) && isset($blocked[strtoupper($mac)])) return false;
    if (isWispSubscriber($mac)) return true;
    exec("nft add element inet pisowifi authenticated_macs { $mac } 2>/dev/null");
    if (!empty($ip)) {
        $safe_ip = escapeshellarg($ip);
        exec("conntrack -D -s $safe_ip 2>/dev/null");
        exec("conntrack -D -d $safe_ip 2>/dev/null");
    }
    return true;
}

function fw_drop($mac, $ip = '') {
    $mac = strtolower(trim((string)$mac));
    if (empty($mac) || $mac === 'unknown') return false;
    if (isWispSubscriber($mac)) return true;
    exec("nft delete element inet pisowifi authenticated_macs { $mac } 2>/dev/null");
    if (!empty($ip)) {
        $safe_ip = escapeshellarg($ip);
        exec("conntrack -D -s $safe_ip 2>/dev/null");
        exec("conntrack -D -d $safe_ip 2>/dev/null");
    } else {
        $safe_mac = escapeshellarg($mac);
        $arp_ip = trim(shell_exec("cat /tmp/dhcp.leases | grep -i $safe_mac | awk '{print $3}'"));
        if (!empty($arp_ip)) {
            $safe_arp_ip = escapeshellarg($arp_ip);
            exec("conntrack -D -s $safe_arp_ip 2>/dev/null");
            exec("conntrack -D -d $safe_arp_ip 2>/dev/null");
        }
    }
    return true;
}

function fw_ban($mac, $ip = '') {
    fw_drop($mac, $ip);
}

function fw_unban($mac) {
    if (empty($mac)) return false;
    $mac = strtolower(trim((string)$mac));
    exec("nft add element inet pisowifi authenticated_macs { $mac } 2>/dev/null");
    return true;
}

function pullFromVault($filename) {
    $local_file = (strpos($filename, 'assets/') === 0) ? '/tmp/html/' . $filename : DB_DIR . $filename;
    if (file_exists($local_file)) return file_get_contents($local_file);
    if (strpos($filename, 'assets/') !== 0) {
        $backup_file = '/root/vault_backup/' . $filename;
        if (file_exists($backup_file)) return file_get_contents($backup_file);
    }
    return '';
}

function pushToVault($filename, $content) {
    $local_file = (strpos($filename, 'assets/') === 0) ? '/tmp/html/' . $filename : DB_DIR . $filename;
    $file_dir = dirname($local_file);
    if (!file_exists($file_dir)) @mkdir($file_dir, 0777, true);
    @file_put_contents($local_file, $content);
    if (strpos($filename, 'assets/') !== 0) {
        $backup_dir = '/root/vault_backup/';
        if (!file_exists($backup_dir)) @mkdir($backup_dir, 0777, true);
        @file_put_contents($backup_dir . $filename, $content);
    }
}

function manageSubscription($mac, $action) {
    if (empty($mac) || $action !== 'add' && $action !== 'remove') return false;
    $mac = strtolower($mac);
    $subs = json_decode(pullFromVault('subscriptions.json'), true);
    if (!is_array($subs)) $subs = [];
    $new_subs = [];
    foreach($subs as $s) {
        if (isset($s['status']) && $s['status'] === 'active' && isset($s['macs']) && is_array($s['macs'])) {
            $macs_lower = array_map('strtolower', $s['macs']);
            if ($action === 'add' && !in_array($mac, $macs_lower)) {
                $s['macs'][] = $mac;
            } elseif ($action === 'remove' && in_array($mac, $macs_lower)) {
                $key = array_search($mac, $macs_lower);
                unset($s['macs'][$key]);
            }
            $new_subs[] = $s;
        }
    }
    $new_subs[] = ['status' => 'active', 'macs' => [$mac]];
    pushToVault('subscriptions.json', json_encode($new_subs));
    return true;
}
?>
