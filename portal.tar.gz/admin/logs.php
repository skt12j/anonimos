<?php
// admin/logs.php - Master Transaction Ledger & Analytics (Bulletproof Math Edition)

// 1. DO THE BRAIN WORK FIRST
require_once '../core.php';

// Auth Check & Security
if (session_status() == PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

$message = '';

// Process Purge Command
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'clear_logs') {
    pushToVault('logs.json', json_encode([]));
    header("Location: logs.php?cleared=1"); // Redirect to break loop
    exit;
}

if (isset($_GET['cleared'])) {
    $message = "<div style='color: var(--danger); margin-bottom: 20px; font-weight: bold;'>SYSTEM LOGS PURGED.</div>";
}

require_once 'header.php';
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="color: var(--success); text-shadow: 0 0 10px var(--success); margin: 0;">SYSTEM LOGS <span id="sync-pulse" style="font-size:0.5em; color:var(--success); opacity: 0.2; transition: 0.3s;">●</span></h1>
        <p style="color: #888; margin-top: 5px;">Live portal history and real-time device tracking.</p>
    </div>
    
    <div style="display: flex; gap: 10px; align-items: center;">
        <a href="export_logs.php" class="btn" style="border-color: var(--info); color: var(--info); padding: 8px 15px; font-size: 0.8rem; text-decoration: none;">⬇️ EXPORT CSV</a>
        
        <form method="POST" onsubmit="return confirm('CRITICAL: This will permanently delete all transaction history. Proceed?');" style="margin: 0;">
            <input type="hidden" name="action" value="clear_logs">
            <button type="submit" class="btn btn-danger" style="padding: 8px 15px; font-size: 0.8rem;">PURGE NOW</button>
        </form>
    </div>
</div>

<?php echo $message; ?>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 30px;">
    <div class="card" style="text-align: center; border-color: var(--success);">
        <h4 style="color: #888; margin: 0 0 10px 0;">TOTAL REVENUE</h4>
        <div id="ajax-rev" style="font-size: 2.5rem; color: var(--success); font-family: 'Orbitron'; text-shadow: 0 0 10px var(--success); transition: 0.3s;">₱0.00</div>
    </div>
    <div class="card" style="text-align: center; border-color: var(--info);">
        <h4 style="color: #888; margin: 0 0 10px 0;">TOTAL TIME SOLD</h4>
        <div id="ajax-time" style="font-size: 2.5rem; color: var(--info); font-family: 'Orbitron'; text-shadow: 0 0 10px var(--info); transition: 0.3s;">0 <span style="font-size: 1rem;">MINS</span></div>
    </div>
    <div class="card" style="text-align: center; border-color: var(--theme-color);">
        <h4 style="color: #888; margin: 0 0 10px 0;">TOTAL DATA SOLD</h4>
        <div id="ajax-data" style="font-size: 2.5rem; color: var(--theme-color); font-family: 'Orbitron'; text-shadow: 0 0 10px var(--theme-color); transition: 0.3s;">0 <span style="font-size: 1rem;">MB</span></div>
    </div>
    <div class="card" style="text-align: center; border-color: var(--vip);">
        <h4 style="color: #888; margin: 0 0 10px 0;">NETWORK TRAFFIC</h4>
        <div id="ajax-conn" style="font-size: 2.5rem; color: var(--vip); font-family: 'Orbitron'; text-shadow: 0 0 10px var(--vip); transition: 0.3s;">0 <span style="font-size: 1rem;">HITS</span></div>
    </div>
</div>

<div class="card" style="border-color: var(--warning); margin-bottom: 30px; background: rgba(245, 158, 11, 0.02);">
    <h3 style="color: var(--warning); font-family: 'Orbitron'; margin-bottom: 10px;">📱 LIVE DEVICE TRACKER</h3>
    <p style="color: #888; font-size: 0.85rem; margin-bottom: 20px;">Click a MAC Address to view their real-time portal timeline.</p>
    
    <div id="mac-list" style="display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 20px;">
        <span style="color:#555; font-size: 0.9rem;">Awaiting log scan...</span>
    </div>
    
    <div id="mac-timeline" style="display: none; background: rgba(0,0,0,0.6); padding: 20px; border-radius: 6px; border: 1px solid #333; max-height: 400px; overflow-y: auto; position: relative;">
        <button onclick="closeTimeline()" style="position: absolute; top: 15px; right: 15px; background: none; border: none; color: #888; font-size: 1.2rem; cursor: pointer;">✖</button>
        <h4 id="timeline-title" style="color: #fff; margin: 0 0 15px 0; font-family: 'Orbitron'; border-bottom: 1px dashed #444; padding-bottom: 10px; width: 90%;"></h4>
        <div id="timeline-content" style="display: flex; flex-direction: column; gap: 15px;"></div>
    </div>
</div>

<div class="card">
    <h3 style="color: var(--info); font-family: 'Orbitron'; margin-bottom: 15px;">MASTER EVENT LEDGER</h3>
    <div style="overflow-x: auto;">
        <table>
            <thead>
                <tr>
                    <th>TIMESTAMP</th>
                    <th>EVENT TYPE</th>
                    <th>MAC ADDRESS</th>
                    <th>TIER</th>
                    <th>MODE</th>
                    <th>REVENUE</th>
                    <th>DETAILS</th>
                </tr>
            </thead>
            <tbody id="ajax-logs">
                <tr><td colspan='7' style='text-align: center; color: #555; padding: 40px;'>SCANNING LOGS...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<script>
    // Global variable to store logs for the Device Tracker
    let masterLogs = [];
    let currentlyViewingMac = null;

    function fetchLiveLogs() {
        // Trigger pulse animation
        let pulse = document.getElementById('sync-pulse');
        pulse.style.opacity = '1';
        
        // 🔥 ANTI-CACHE FIX 🔥
        fetch('api_core.php?action=logs&t=' + new Date().getTime(), {
            method: 'GET',
            headers: {
                'Cache-Control': 'no-cache',
                'Pragma': 'no-cache'
            }
        })
            .then(response => response.json())
            .then(data => {
                masterLogs = data.logs || []; 
                
                // 🔥 BULLETPROOF MATH ENGINE 🔥
                // Ignores api_core totals and manually calculates everything from the raw logs!
                let totalDataMB = 0;
                let totalMinutes = 0;
                let totalRevenue = 0;
                let totalHits = masterLogs.length; // Total logs = Total Hits
                
                masterLogs.forEach(log => {
                    let details = log.details || '';
                    
                    // Extract Revenue
                    totalRevenue += parseFloat(log.revenue || 0);
                    
                    // Extract Time (e.g., "Added 60m")
                    let timeMatch = details.match(/Added\s*([\d\.]+)\s*m/i);
                    if (timeMatch) totalMinutes += parseFloat(timeMatch[1]);
                    
                    // Extract MB (e.g., "Added 500MB")
                    let mbMatch = details.match(/Added\s*([\d\.]+)\s*MB/i);
                    if (mbMatch) totalDataMB += parseFloat(mbMatch[1]);
                    
                    // Extract GB (e.g., "Added 1GB")
                    let gbMatch = details.match(/Added\s*([\d\.]+)\s*GB/i);
                    if (gbMatch) totalDataMB += (parseFloat(gbMatch[1]) * 1024);
                });
                
                let displayData = totalDataMB;
                let displayUnit = "MB";
                if (totalDataMB >= 1024) {
                    displayData = (totalDataMB / 1024).toFixed(2);
                    displayUnit = "GB";
                }

                // Update Top Stats using the manual calculations!
                document.getElementById('ajax-rev').innerText = "₱" + totalRevenue.toFixed(2);
                document.getElementById('ajax-time').innerHTML = totalMinutes + " <span style='font-size: 1rem;'>MINS</span>";
                document.getElementById('ajax-data').innerHTML = displayData + " <span style='font-size: 1rem;'>" + displayUnit + "</span>";
                document.getElementById('ajax-conn').innerHTML = totalHits + " <span style='font-size: 1rem;'>HITS</span>";

                // Update Master Table
                let logHtml = '';
                if(masterLogs.length === 0) {
                    logHtml = "<tr><td colspan='7' style='text-align: center; color: #555; padding: 40px;'>NO LOGS FOUND. AWAITING DATA...</td></tr>";
                } else {
                    masterLogs.forEach(log => {
                        let eventColor = "#fff";
                        if (log.event.includes('VOUCHER')) eventColor = "var(--vip)";
                        if (log.event.includes('COIN')) eventColor = "var(--success)";
                        if (log.event.includes('TOP_UP')) eventColor = "var(--success)";
                        if (log.event.includes('CONNECTING')) eventColor = "#f59e0b";
                        if (log.event.includes('STABLE')) eventColor = "var(--info)";
                        if (log.event.includes('DISCONNECTED')) eventColor = "var(--danger)";
                        
                        let modeTag = '<span style="color:#555;">N/A</span>';
                        if (log.details.includes('Mode: Data')) modeTag = '<span style="color:var(--warning); font-family:Orbitron; font-weight:bold;">DATA</span>';
                        if (log.details.includes('Mode: Time')) modeTag = '<span style="color:var(--success); font-family:Orbitron; font-weight:bold;">TIME</span>';

                        logHtml += `<tr style='border-bottom: 1px solid #222;'>
                            <td style='font-size: 0.9rem; color: #888;'>${log.date || 'N/A'}</td>
                            <td style='color: ${eventColor}; font-weight: bold;'>${log.event || 'UNKNOWN'}</td>
                            <td style='font-family: "Orbitron", sans-serif; font-size: 0.9rem;'>${log.mac || 'SYSTEM'}</td>
                            <td>${log.tier || '-'}</td>
                            <td>${modeTag}</td>
                            <td style='color: var(--success); font-weight: bold;'>₱${parseFloat(log.revenue || 0).toFixed(2)}</td>
                            <td style='font-size: 0.9rem; color: #aaa;'>${log.details || '-'}</td>
                        </tr>`;
                    });
                }
                document.getElementById('ajax-logs').innerHTML = logHtml;
                
                // 🧠 Process the Device Tracker
                processDeviceTracker();

                // Fade out pulse
                setTimeout(() => pulse.style.opacity = '0.2', 500);

            }).catch(err => console.error("SYNC ERROR:", err));
    }
    
    // 🧠 LIVE DEVICE TRACKER LOGIC
    function processDeviceTracker() {
        let macMap = {};
        
        // Group logs by MAC
        masterLogs.forEach(log => {
            let m = log.mac || 'SYSTEM';
            if (m === 'SYSTEM' || m === 'UNKNOWN' || m === '') return;
            if (!macMap[m]) macMap[m] = [];
            macMap[m].push(log);
        });

        let listHtml = '';
        for (let m in macMap) {
            let count = macMap[m].length;
            // 🟢 Highlight the currently selected MAC
            let btnStyle = (m === currentlyViewingMac) 
                ? 'background: var(--info); color: #000; border-color: var(--info);' 
                : 'background: #111; color: var(--info); border-color: #444;';
                
            let badgeStyle = (m === currentlyViewingMac)
                ? 'background: rgba(0,0,0,0.5); color: #fff;'
                : 'background: rgba(0,243,255,0.2); color: var(--info);';

            listHtml += `<button class="btn" style="font-family: monospace; font-size: 0.9rem; padding: 8px 12px; transition: 0.2s; border: 1px solid; ${btnStyle}" onclick="showTimeline('${m}')">
                📱 ${m} <span style="padding: 2px 6px; border-radius: 10px; margin-left: 5px; font-size: 0.75rem; font-weight: bold; ${badgeStyle}">${count}</span>
            </button>`;
        }
        
        if (listHtml === '') listHtml = '<span style="color:#555; font-size: 0.9rem;">No device tracking data available yet.</span>';
        document.getElementById('mac-list').innerHTML = listHtml;
        
        // 🟢 Live Update the Timeline if it's currently open
        if (currentlyViewingMac && macMap[currentlyViewingMac]) {
            showTimeline(currentlyViewingMac, true); // true = silent update (no scroll reset)
        } else if (currentlyViewingMac && !macMap[currentlyViewingMac]) {
            closeTimeline(); // MAC was purged
        }
    }

    function showTimeline(mac, isSilentUpdate = false) {
        currentlyViewingMac = mac;
        let timelineEl = document.getElementById('mac-timeline');
        timelineEl.style.display = 'block';
        document.getElementById('timeline-title').innerText = `TIMELINE FOR: ${mac}`;
        
        // Re-process the buttons so the clicked one lights up immediately
        if (!isSilentUpdate) processDeviceTracker(); 
        
        let logsForMac = masterLogs.filter(l => l.mac === mac);
        let contentHtml = '';
        
        if (logsForMac.length === 0) {
            contentHtml = '<div style="color:#555;">No records found.</div>';
        } else {
            logsForMac.forEach(log => {
                let eventColor = "#aaa";
                if (log.event.includes('VOUCHER') || log.event.includes('COIN') || log.event.includes('TOP_UP')) eventColor = "var(--success)";
                if (log.event.includes('STABLE') || log.event.includes('CONNECTING')) eventColor = "var(--info)";
                if (log.event.includes('DISCONNECTED')) eventColor = "var(--danger)";
                
                contentHtml += `
                <div style="border-left: 3px solid ${eventColor}; padding-left: 15px; margin-bottom: 5px; background: rgba(255,255,255,0.02); padding-top: 10px; padding-bottom: 10px; border-radius: 0 4px 4px 0;">
                    <div style="font-size: 0.75rem; color: #888; font-family: 'Source Code Pro'; margin-bottom: 3px;">${log.date}</div>
                    <div style="color: ${eventColor}; font-weight: bold; font-size: 1rem; font-family: 'Rajdhani';">${log.event}</div>
                    <div style="color: #ccc; font-size: 0.9rem; margin-top: 3px;">${log.details || ''}</div>
                </div>`;
            });
        }
        
        document.getElementById('timeline-content').innerHTML = contentHtml;
    }
    
    function closeTimeline() {
        currentlyViewingMac = null;
        document.getElementById('mac-timeline').style.display = 'none';
        processDeviceTracker(); // Re-render to remove button highlight
    }

    // Run immediately on load, then every 3 seconds seamlessly!
    fetchLiveLogs();
    setInterval(fetchLiveLogs, 3000); 
</script>

</div> 
</body>
</html>