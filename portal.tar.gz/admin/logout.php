<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  3.0.0   |
    |              on 2026-09-12 00:45:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto kMA00; MXtWY: header("\114\157\x63\x61\164\151\x6f\156\x3a\x20\x6c\x6f\x67\151\x6e\x2e\x70\150\x70"); goto STdTa; hW4dR: LbD2p: goto msCST; msCST: $_SESSION = array(); goto Zg14U; XeDOP: session_start(); goto hW4dR; K1MAZ: if (!(session_status() == PHP_SESSION_NONE)) { goto LbD2p; } goto XeDOP; Zg14U: session_destroy(); goto MXtWY; kMA00: require_once "\56\x2e\57\x63\x6f\162\145\56\160\x68\x70"; goto K1MAZ; STdTa: exit;
